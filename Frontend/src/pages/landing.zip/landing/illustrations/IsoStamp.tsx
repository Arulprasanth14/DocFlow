import React from 'react';
import { type IsoIllustrationProps } from './IsoDocStack';

/**
 * IsoStamp — Procedural 3D Isometric Validation Stamp
 * Features a turned precision handle, metallic brass rim, and a crisp
 * embossed ink impression stamped on an isometric surface.
 */
export const IsoStamp: React.FC<IsoIllustrationProps> = ({
  size = 240,
  className = '',
  animated = true,
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 320 320"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none overflow-visible ${className}`}
      aria-label="Isometric Validation Stamp"
      role="img"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        {/* Floor Shadow */}
        <radialGradient id="ist-floor-shadow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="var(--success)" stopOpacity="0.3" />
          <stop offset="100%" stopColor="var(--success)" stopOpacity="0" />
        </radialGradient>

        {/* Handle Gradient (Turned Dark Walnut / Indigo) */}
        <linearGradient id="ist-handle-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.9" />
          <stop offset="45%" stopColor="var(--primary)" stopOpacity="1" />
          <stop offset="70%" stopColor="var(--card)" stopOpacity="0.8" />
          <stop offset="100%" stopColor="var(--primary)" stopOpacity="0.7" />
        </linearGradient>

        {/* Brass Collar Gradient */}
        <linearGradient id="ist-brass-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="var(--accent-amber)" />
          <stop offset="40%" stopColor="var(--card-solid)" />
          <stop offset="80%" stopColor="var(--warning)" />
          <stop offset="100%" stopColor="var(--warning)" />
        </linearGradient>

        {/* Stamp Ink Seal Gradient */}
        <radialGradient id="ist-seal-glow" cx="50%" cy="50%" r="50%">
          <stop offset="60%" stopColor="var(--success)" stopOpacity="0.18" />
          <stop offset="100%" stopColor="var(--success)" stopOpacity="0" />
        </radialGradient>
      </defs>

      {/* ── Floor Shadow ── */}
      <ellipse
        cx="160"
        cy="245"
        rx="95"
        ry="36"
        fill="url(#ist-floor-shadow)"
      />

      {/* ── Stamped Paper Ground Plane ── */}
      <g transform="translate(160, 235)">
        {/* Base Sheet Diamond */}
        <path
          d="M 0 -35 L 90 12 L 0 58 L -90 12 Z"
          fill="var(--card)"
          stroke="var(--border)"
          strokeWidth="1.2"
          className="opacity-90"
        />

        {/* Ink Seal Ring (Concentric) */}
        <ellipse
          cx="0"
          cy="12"
          rx="52"
          ry="25"
          fill="url(#ist-seal-glow)"
          stroke="var(--success)"
          strokeWidth="1.8"
          strokeDasharray="4 2"
        />
        <ellipse
          cx="0"
          cy="12"
          rx="44"
          ry="20"
          stroke="var(--success)"
          strokeWidth="1"
          strokeOpacity="0.7"
        />

        {/* Star Badges */}
        <circle cx="-32" cy="12" r="2.5" fill="var(--success)" />
        <circle cx="32" cy="12" r="2.5" fill="var(--success)" />

        {/* Central Embossed "VERIFIED" Lettering */}
{/* Stamped Checkmark Emblem */}
        <path
          d="M -9 8 L -2 14 L 11 3"
          stroke="var(--success)"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>

      {/* ── Floating 3D Stamp Body ── */}
      <g
        className={animated ? 'transition-transform duration-500 ease-out hover:-translate-y-3' : ''}
        transform="translate(160, 115)"
      >
        {/* Stamp Round Base Plate (Cylinder) */}
        {/* Cylinder Bottom Rim */}
        <ellipse cx="0" cy="50" rx="42" ry="18" fill="var(--warning)" />
        {/* Cylinder Body */}
        <path
          d="M -42 50 L -42 40 C -42 32 42 32 42 40 L 42 50 C 42 58 -42 58 -42 50 Z"
          fill="url(#ist-brass-grad)"
          stroke="var(--warning)"
          strokeWidth="0.8"
        />
        {/* Cylinder Top Rim */}
        <ellipse
          cx="0"
          cy="40"
          rx="42"
          ry="18"
          fill="url(#ist-brass-grad)"
          stroke="var(--card-solid)"
          strokeWidth="1"
        />

        {/* Stamp Neck Ring */}
        <path
          d="M -16 40 L -16 28 C -16 23 16 23 16 28 L 16 40 C 16 45 -16 45 -16 40 Z"
          fill="url(#ist-brass-grad)"
        />

        {/* Stamp Turned Handle Stem */}
        <path
          d="M -12 28 C -18 -10 -22 -40 -20 -60 C -18 -80 18 -80 20 -60 C 22 -40 18 -10 12 28 C 12 33 -12 33 -12 28 Z"
          fill="url(#ist-handle-grad)"
          stroke="var(--primary)"
          strokeWidth="1.2"
        />

        {/* Stamp Handle Knob (Spherical Top) */}
        <ellipse
          cx="0"
          cy="-66"
          rx="22"
          ry="20"
          fill="url(#ist-handle-grad)"
          stroke="var(--primary)"
          strokeWidth="1.2"
        />
        {/* Knob Glint */}
        <ellipse
          cx="-6"
          cy="-72"
          rx="7"
          ry="4"
          fill="var(--card-solid)"
          fillOpacity="0.45"
          transform="rotate(-20, -6, -72)"
        />

        {/* Ambient Seal Sparkles */}
        <g className={animated ? 'animate-pulse' : ''}>
          <polygon points="52,25 55,32 62,35 55,38 52,45 49,38 42,35 49,32" fill="var(--accent-amber)" />
          <polygon points="-50,30 -48,34 -44,36 -48,38 -50,42 -52,38 -56,36 -52,34" fill="var(--success)" />
        </g>
      </g>
    </svg>
  );
};

