import React from 'react';
import { type IsoIllustrationProps } from './IsoDocStack';

/**
 * IsoChatBubbles — Procedural Isometric Discussion Cards
 * Depicts in-context comment evidence, reviewer tagging, and ACID audit logs
 * anchored to approval requests.
 */
export const IsoChatBubbles: React.FC<IsoIllustrationProps> = ({
  size = 240,
  className = '',
  animated = true,
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 320 320"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none overflow-visible ${className}`}
      aria-label="Isometric Collaborative Discussion Cards"
      role="img"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        {/* Soft floor shadow */}
        <radialGradient id="icb-floor-shadow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.25" />
          <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
        </radialGradient>

        {/* Card 1 Gradient (Manager) */}
        <linearGradient id="icb-card1-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--card)" stopOpacity="0.98" />
          <stop offset="100%" stopColor="var(--secondary)" stopOpacity="0.9" />
        </linearGradient>

        {/* Card 2 Gradient (Submitter) */}
        <linearGradient id="icb-card2-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--card)" stopOpacity="0.98" />
          <stop offset="100%" stopColor="var(--background)" stopOpacity="0.9" />
        </linearGradient>
      </defs>

      {/* ── Floor Shadow ── */}
      <ellipse
        cx="160"
        cy="255"
        rx="105"
        ry="38"
        fill="url(#icb-floor-shadow)"
      />

      {/* ── Connecting Conversation Thread Line ── */}
      <path
        d="M 120 120 L 120 180 L 180 180"
        stroke="var(--primary)"
        strokeOpacity="0.4"
        strokeWidth="1.8"
        strokeDasharray="4 3"
        fill="none"
      />

      {/* ── Card 1: Reviewer Query (Top Floating Isometric Slab) ── */}
      <g
        className={animated ? 'transition-transform duration-700 ease-out hover:-translate-y-2' : ''}
        transform="translate(130, 110)"
      >
        {/* Slab Top Face */}
        <polygon
          points="0,-36 80,6 0,48 -80,6"
          fill="url(#icb-card1-grad)"
          stroke="var(--primary)"
          strokeOpacity="0.6"
          strokeWidth="1.5"
        />
        {/* Slab Thickness */}
        <polygon points="-80,6 0,48 0,56 -80,14" fill="var(--secondary)" stroke="var(--border)" strokeWidth="0.8" />
        <polygon points="0,48 80,6 80,14 0,56" fill="var(--card)" stroke="var(--border)" strokeWidth="0.8" />

        {/* Avatar Pip */}
        <circle cx="-50" cy="8" r="10" fill="var(--primary)" fillOpacity="0.2" stroke="var(--primary)" strokeWidth="1.5" />
{/* Simulated Text Lines (Manager Query) */}
        <line x1="-32" y1="2" x2="45" y2="-12" stroke="var(--foreground)" strokeOpacity="0.6" strokeWidth="2.5" strokeLinecap="round" />
        <line x1="-32" y1="14" x2="30" y2="4" stroke="var(--foreground)" strokeOpacity="0.4" strokeWidth="2" strokeLinecap="round" />
        <line x1="-32" y1="26" x2="10" y2="18" stroke="var(--foreground)" strokeOpacity="0.3" strokeWidth="2" strokeLinecap="round" />

        {/* Tag Pill "@priya" */}
        <polygon points="40,2 65,-2 65,-10 40,-6" fill="var(--primary)" fillOpacity="0.15" stroke="var(--primary)" strokeWidth="0.8" />
      </g>

      {/* ── Card 2: Submitter Response (Lower Forward Slab) ── */}
      <g
        className={animated ? 'transition-transform duration-700 ease-out hover:-translate-y-1' : ''}
        transform="translate(180, 190)"
      >
        {/* Slab Top Face */}
        <polygon
          points="0,-36 80,6 0,48 -80,6"
          fill="url(#icb-card2-grad)"
          stroke="var(--success)"
          strokeOpacity="0.7"
          strokeWidth="1.5"
        />
        {/* Slab Thickness */}
        <polygon points="-80,6 0,48 0,56 -80,14" fill="var(--secondary)" stroke="var(--border)" strokeWidth="0.8" />
        <polygon points="0,48 80,6 80,14 0,56" fill="var(--card)" stroke="var(--border)" strokeWidth="0.8" />

        {/* Avatar Pip */}
        <circle cx="-50" cy="8" r="10" fill="var(--success)" fillOpacity="0.2" stroke="var(--success)" strokeWidth="1.5" />
{/* Simulated Text Lines (Submitter Answer) */}
        <line x1="-32" y1="4" x2="52" y2="-12" stroke="var(--foreground)" strokeOpacity="0.6" strokeWidth="2.5" strokeLinecap="round" />
        <line x1="-32" y1="16" x2="35" y2="5" stroke="var(--foreground)" strokeOpacity="0.4" strokeWidth="2" strokeLinecap="round" />

        {/* Green Checkmark Badge */}
        <circle cx="55" cy="0" r="8" fill="var(--success)" fillOpacity="0.15" stroke="var(--success)" strokeWidth="1" />
        <path d="M 52 -1 L 54 2 L 58 -3" stroke="var(--success)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      </g>

      {/* ── Audit Stamped Ribbon ── */}
      <g transform="translate(245, 125)">
        <polygon points="0,-10 32,-2 32,8 0,0" fill="var(--success)" fillOpacity="0.2" stroke="var(--success)" strokeWidth="0.8" />
</g>
    </svg>
  );
};

