import React from 'react';
import { type IsoIllustrationProps } from './IsoDocStack';

/**
 * IsoSignature — Procedural Isometric Signing Tablet
 * Features a high-res glass tablet screen, self-rendered signature flourish,
 * and a hovering precision cryptographic stylus.
 */
export const IsoSignature: React.FC<IsoIllustrationProps> = ({
  size = 240,
  className = '',
  animated = true,
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 320 320"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none overflow-visible ${className}`}
      aria-label="Isometric Digital Signing Tablet"
      role="img"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        {/* Floor Shadow */}
        <radialGradient id="isig-floor-shadow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.28" />
          <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
        </radialGradient>

        {/* Tablet Chassis Facet */}
        <linearGradient id="isig-tablet-top" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--card)" stopOpacity="0.98" />
          <stop offset="100%" stopColor="var(--secondary)" stopOpacity="0.9" />
        </linearGradient>

        {/* Screen Glass Surface */}
        <linearGradient id="isig-screen-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--background)" stopOpacity="0.95" />
          <stop offset="100%" stopColor="var(--card)" stopOpacity="0.85" />
        </linearGradient>

        {/* Stylus Gradient */}
        <linearGradient id="isig-stylus-grad" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="var(--primary)" />
          <stop offset="60%" stopColor="var(--ring)" />
          <stop offset="100%" stopColor="var(--primary)" />
        </linearGradient>
      </defs>

      {/* ── Floor Shadow ── */}
      <ellipse
        cx="160"
        cy="255"
        rx="110"
        ry="42"
        fill="url(#isig-floor-shadow)"
      />

      {/* ── Isometric Tablet Device ── */}
      <g transform="translate(160, 175)">
        {/* Tablet Outer Rim (Slab Top) */}
        <polygon
          points="0,-60 100,-8 0,44 -100,-8"
          fill="url(#isig-tablet-top)"
          stroke="var(--border)"
          strokeWidth="1.5"
        />

        {/* Tablet Chassis Thickness */}
        <polygon points="-100,-8 0,44 0,54 -100,2" fill="var(--secondary)" stroke="var(--border)" strokeWidth="1" />
        <polygon points="0,44 100,-8 100,2 0,54" fill="var(--card)" stroke="var(--border)" strokeWidth="1" />

        {/* Inset Screen Glass */}
        <polygon
          points="0,-48 84,-5 0,38 -84,-5"
          fill="url(#isig-screen-grad)"
          stroke="var(--primary)"
          strokeOpacity="0.4"
          strokeWidth="1.2"
        />

        {/* Document Header Text on Screen */}
        <line x1="-60" y1="-12" x2="-20" y2="-28" stroke="var(--foreground)" strokeOpacity="0.5" strokeWidth="2.5" strokeLinecap="round" />
        <line x1="-60" y1="-2" x2="20" y2="-32" stroke="var(--foreground)" strokeOpacity="0.3" strokeWidth="1.8" strokeLinecap="round" />
        <line x1="-55" y1="8" x2="40" y2="-26" stroke="var(--foreground)" strokeOpacity="0.3" strokeWidth="1.8" strokeLinecap="round" />

        {/* Signature Line Area (Dashed Baseline) */}
        <line
          x1="-45"
          y1="22"
          x2="45"
          y2="-12"
          stroke="var(--primary)"
          strokeOpacity="0.5"
          strokeWidth="1.5"
          strokeDasharray="4 3"
        />

        {/* Handwritten Vector Signature Flourish */}
        <path
          d="M -35 15 C -25 8 -20 22 -15 12 C -10 2 0 16 10 5 C 18 -4 28 8 36 -6"
          stroke="var(--primary)"
          strokeWidth="2.4"
          strokeLinecap="round"
          strokeLinejoin="round"
          fill="none"
          className={animated ? 'animate-pulse' : ''}
        />

        {/* Green Cryptographic Hash Verification Pill */}
        <g transform="translate(48, -25)">
          <rect x="-18" y="-7" width="36" height="14" rx="7" fill="var(--success)" fillOpacity="0.15" stroke="var(--success)" strokeWidth="0.8" />
</g>
      </g>

      {/* ── Hovering Cryptographic Stylus Pen ── */}
      <g
        className={animated ? 'transition-transform duration-700 ease-out hover:-translate-y-3' : ''}
        transform="translate(195, 125) rotate(-25)"
      >
        {/* Pen Shaft */}
        <rect
          x="-5"
          y="-60"
          width="10"
          height="65"
          rx="5"
          fill="url(#isig-stylus-grad)"
          stroke="var(--primary)"
          strokeWidth="1.2"
        />

        {/* Stylus Nib / Tip */}
        <polygon points="-4,5 4,5 0,16" fill="var(--primary-hover)" />
        <circle cx="0" cy="16" r="2.5" fill="var(--primary)" className={animated ? 'animate-ping' : ''} />
        <circle cx="0" cy="16" r="2.5" fill="var(--primary)" />

        {/* Grip Rings */}
        <line x1="-5" y1="-8" x2="5" y2="-8" stroke="var(--card-solid)" strokeOpacity="0.5" strokeWidth="1" />
        <line x1="-5" y1="-14" x2="5" y2="-14" stroke="var(--card-solid)" strokeOpacity="0.5" strokeWidth="1" />
      </g>
    </svg>
  );
};

