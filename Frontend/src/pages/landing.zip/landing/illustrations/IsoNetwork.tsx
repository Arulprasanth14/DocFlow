import React from 'react';
import { type IsoIllustrationProps } from './IsoDocStack';

/**
 * IsoNetwork — Procedural Isometric Routing Mesh
 * Illustrates peer-to-peer document workflow routing, multi-tier approvals,
 * and dynamic handoffs across organizational roles.
 */
export const IsoNetwork: React.FC<IsoIllustrationProps> = ({
  size = 240,
  className = '',
  animated = true,
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 320 320"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none overflow-visible ${className}`}
      aria-label="Isometric Peer-to-Peer Routing Mesh"
      role="img"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        {/* Soft floor shadow */}
        <radialGradient id="in-floor-shadow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.25" />
          <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
        </radialGradient>

        {/* Conduit Glow */}
        <linearGradient id="in-conduit-grad1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--success)" />
          <stop offset="50%" stopColor="var(--primary)" />
          <stop offset="100%" stopColor="var(--accent-violet)" />
        </linearGradient>

        {/* Node Facet Gradients */}
        <linearGradient id="in-node-top" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--card)" stopOpacity="0.95" />
          <stop offset="100%" stopColor="var(--secondary)" stopOpacity="0.8" />
        </linearGradient>
      </defs>

      {/* ── Floor Shadow ── */}
      <ellipse
        cx="160"
        cy="255"
        rx="115"
        ry="42"
        fill="url(#in-floor-shadow)"
      />

      {/* ── Connecting Conduit Bus Lines ── */}
      <g>
        {/* Path: Node 1 (Employee, left) -> Node 2 (Reviewer, center-low) */}
        <path
          d="M 85 170 L 160 215"
          stroke="url(#in-conduit-grad1)"
          strokeWidth="2.5"
          strokeDasharray="6 4"
          className={animated ? 'animate-pulse' : ''}
        />

        {/* Path: Node 2 (Reviewer) -> Node 3 (Manager, right) */}
        <path
          d="M 160 215 L 235 170"
          stroke="url(#in-conduit-grad1)"
          strokeWidth="2.5"
          strokeDasharray="6 4"
          className={animated ? 'animate-pulse' : ''}
        />

        {/* Path: Node 2 (Reviewer) -> Node 4 (Executive / Top Hub) */}
        <path
          d="M 160 215 L 160 115"
          stroke="var(--primary)"
          strokeOpacity="0.7"
          strokeWidth="2"
        />

        {/* Path: Node 1 -> Node 4 */}
        <path
          d="M 85 170 L 160 115"
          stroke="var(--primary)"
          strokeOpacity="0.4"
          strokeWidth="1.5"
          strokeDasharray="4 3"
        />

        {/* Path: Node 3 -> Node 4 */}
        <path
          d="M 235 170 L 160 115"
          stroke="var(--primary)"
          strokeOpacity="0.4"
          strokeWidth="1.5"
          strokeDasharray="4 3"
        />

        {/* Traveling Data Packet (Animated Circle) */}
        {animated && (
          <circle cx="122" cy="192" r="4" fill="var(--ring)" className="animate-ping" />
        )}
      </g>

      {/* ── Node 1: Submitter / Author (Left) ── */}
      <g transform="translate(85, 170)">
        {/* Isometric Pedestal */}
        <polygon points="0,-18 32,0 0,18 -32,0" fill="url(#in-node-top)" stroke="var(--border)" strokeWidth="1" />
        <polygon points="-32,0 0,18 0,28 -32,10" fill="var(--secondary)" stroke="var(--border)" strokeWidth="0.8" />
        <polygon points="0,18 32,0 32,10 0,28" fill="var(--card)" stroke="var(--border)" strokeWidth="0.8" />

        {/* Avatar Pin */}
        <circle cx="0" cy="-22" r="14" fill="var(--success)" fillOpacity="0.15" stroke="var(--success)" strokeWidth="1.5" />
<rect x="-24" y="-2" width="48" height="14" rx="7" fill="var(--card)" stroke="var(--border)" strokeWidth="0.8" />
</g>

      {/* ── Node 2: Reviewer / Dispatch (Center Low) ── */}
      <g transform="translate(160, 215)">
        <polygon points="0,-22 40,0 0,22 -40,0" fill="url(#in-node-top)" stroke="var(--primary)" strokeWidth="1.5" />
        <polygon points="-40,0 0,22 0,34 -40,12" fill="var(--secondary)" stroke="var(--border)" strokeWidth="0.8" />
        <polygon points="0,22 40,0 40,12 0,34" fill="var(--card)" stroke="var(--border)" strokeWidth="0.8" />

        <circle cx="0" cy="-26" r="16" fill="var(--primary)" fillOpacity="0.2" stroke="var(--primary)" strokeWidth="2" />
<rect x="-30" y="-4" width="60" height="16" rx="8" fill="var(--card)" stroke="var(--primary)" strokeWidth="1" />
</g>

      {/* ── Node 3: HR / Finance Finalizer (Right) ── */}
      <g transform="translate(235, 170)">
        <polygon points="0,-18 32,0 0,18 -32,0" fill="url(#in-node-top)" stroke="var(--border)" strokeWidth="1" />
        <polygon points="-32,0 0,18 0,28 -32,10" fill="var(--secondary)" stroke="var(--border)" strokeWidth="0.8" />
        <polygon points="0,18 32,0 32,10 0,28" fill="var(--card)" stroke="var(--border)" strokeWidth="0.8" />

        <circle cx="0" cy="-22" r="14" fill="var(--accent-violet)" fillOpacity="0.15" stroke="var(--accent-violet)" strokeWidth="1.5" />
<rect x="-24" y="-2" width="48" height="14" rx="7" fill="var(--card)" stroke="var(--border)" strokeWidth="0.8" />
</g>

      {/* ── Node 4: Policy & Automation Engine (Top Hub) ── */}
      <g
        className={animated ? 'transition-transform duration-700 ease-out hover:-translate-y-2' : ''}
        transform="translate(160, 110)"
      >
        {/* Floating Diamond Platform */}
        <polygon points="0,-24 45,0 0,24 -45,0" fill="url(#in-node-top)" stroke="var(--primary)" strokeWidth="1.5" />
        <polygon points="-45,0 0,24 0,36 -45,12" fill="var(--secondary)" stroke="var(--border)" strokeWidth="1" />
        <polygon points="0,24 45,0 45,12 0,36" fill="var(--card)" stroke="var(--border)" strokeWidth="1" />

        {/* Central Dynamic Routing Engine Icon */}
        <g transform="translate(0, -18)">
          <circle cx="0" cy="0" r="18" fill="var(--primary)" fillOpacity="0.15" stroke="var(--primary)" strokeWidth="1.8" />
          <path
            d="M -7 -4 L 0 5 L 8 -5"
            stroke="var(--primary)"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>
        <rect x="-35" y="4" width="70" height="16" rx="8" fill="var(--card)" stroke="var(--primary)" strokeWidth="1" />
</g>
    </svg>
  );
};

