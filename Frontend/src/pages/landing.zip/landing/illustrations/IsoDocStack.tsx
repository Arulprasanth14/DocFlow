import React from 'react';

export interface IsoIllustrationProps {
  size?: number;
  className?: string;
  animated?: boolean;
}

/**
 * IsoDocStack — Procedural Isometric Document Stack
 * Features fanned multi-layer sheets, dynamic grid lines, folded corner,
 * and floating metadata version badge.
 */
export const IsoDocStack: React.FC<IsoIllustrationProps> = ({
  size = 240,
  className = '',
  animated = true,
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 320 320"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none overflow-visible ${className}`}
      aria-label="Isometric Document Stack"
      role="img"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        {/* Soft floor shadow */}
        <radialGradient id="ids-floor-shadow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.25" />
          <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
        </radialGradient>

        {/* Sheet 1 (Bottom) Gradient */}
        <linearGradient id="ids-sheet1-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--card)" stopOpacity="0.8" />
          <stop offset="100%" stopColor="var(--background)" stopOpacity="0.9" />
        </linearGradient>

        {/* Sheet 2 (Middle) Gradient */}
        <linearGradient id="ids-sheet2-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.15" />
          <stop offset="100%" stopColor="var(--card)" stopOpacity="0.9" />
        </linearGradient>

        {/* Sheet 3 (Top) Gradient */}
        <linearGradient id="ids-sheet3-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--card)" stopOpacity="0.98" />
          <stop offset="100%" stopColor="var(--secondary)" stopOpacity="0.85" />
        </linearGradient>

        {/* Corner Fold Gradient */}
        <linearGradient id="ids-fold-grad" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.3" />
          <stop offset="100%" stopColor="var(--primary)" stopOpacity="0.05" />
        </linearGradient>
      </defs>

      {/* ── Floor Shadow ── */}
      <ellipse
        cx="160"
        cy="245"
        rx="105"
        ry="38"
        fill="url(#ids-floor-shadow)"
        className="opacity-70 dark:opacity-90"
      />

      {/* ── Layer 1: Bottom Sheet (Tilted Left) ── */}
      <g transform="translate(145, 175) rotate(-6)">
        {/* Paper Body */}
        <path
          d="M -75 -45 L 45 -115 L 115 -75 L -5 -5 Z"
          fill="url(#ids-sheet1-grad)"
          stroke="var(--border)"
          strokeWidth="1.2"
          strokeLinejoin="round"
          className="opacity-60"
        />
        {/* Thickness Edge */}
        <path
          d="M -75 -45 L -5 -5 L -5 -1 L -75 -41 Z"
          fill="var(--border)"
          className="opacity-40"
        />
      </g>

      {/* ── Layer 2: Middle Sheet (Tilted Right) ── */}
      <g transform="translate(152, 160) rotate(4)">
        <path
          d="M -75 -45 L 45 -115 L 115 -75 L -5 -5 Z"
          fill="url(#ids-sheet2-grad)"
          stroke="var(--primary)"
          strokeOpacity="0.35"
          strokeWidth="1.2"
          strokeLinejoin="round"
          className="opacity-80"
        />
        <path
          d="M -75 -45 L -5 -5 L -5 -1 L -75 -41 Z"
          fill="var(--primary)"
          className="opacity-30"
        />
      </g>

      {/* ── Layer 3: Top Hero Sheet (True Isometric) ── */}
      <g
        className={animated ? 'transition-transform duration-700 ease-out hover:-translate-y-2' : ''}
        transform="translate(160, 142)"
      >
        {/* Main Sheet Body (with top corner cut for fold) */}
        <path
          d="M -80 -46 L 25 -107 L 50 -92 L 120 -52 L 15 15 Z"
          fill="url(#ids-sheet3-grad)"
          stroke="var(--primary)"
          strokeOpacity="0.45"
          strokeWidth="1.5"
          strokeLinejoin="round"
        />

        {/* Paper Thickness / Drop Rim */}
        <path
          d="M -80 -46 L 15 15 L 120 -52 L 120 -48 L 15 19 L -80 -42 Z"
          fill="var(--border)"
          stroke="var(--border)"
          strokeWidth="0.8"
        />

        {/* Folded Corner Triangle */}
        <path
          d="M 25 -107 L 50 -92 L 65 -101 Z"
          fill="url(#ids-fold-grad)"
          stroke="var(--primary)"
          strokeOpacity="0.6"
          strokeWidth="1.2"
          strokeLinejoin="round"
        />

        {/* Document Header Bar */}
        <path
          d="M -60 -48 L -20 -71 L -8 -64 L -48 -41 Z"
          fill="var(--primary)"
          fillOpacity="0.3"
        />

        {/* Document Grid Content Lines */}
        <path
          d="M -40 -37 L 20 -72"
          stroke="var(--foreground)"
          strokeOpacity="0.35"
          strokeWidth="2"
          strokeLinecap="round"
        />
        <path
          d="M -55 -21 L 45 -79"
          stroke="var(--foreground)"
          strokeOpacity="0.25"
          strokeWidth="2"
          strokeLinecap="round"
        />
        <path
          d="M -48 -10 L 60 -72"
          stroke="var(--foreground)"
          strokeOpacity="0.25"
          strokeWidth="2"
          strokeLinecap="round"
        />
        <path
          d="M -35 2 L 40 -41"
          stroke="var(--foreground)"
          strokeOpacity="0.25"
          strokeWidth="2"
          strokeLinecap="round"
        />

        {/* Dynamic Blank / Fill Chip */}
        <path
          d="M 5 -16 L 35 -33 L 70 -13 L 40 4 Z"
          fill="var(--primary)"
          fillOpacity="0.12"
          stroke="var(--primary)"
          strokeOpacity="0.5"
          strokeWidth="1"
          strokeDasharray="3 2"
        />

        {/* Checkmark in Blank */}
        <path
          d="M 25 -18 L 34 -11 L 48 -23"
          stroke="var(--primary)"
          strokeWidth="1.8"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>

      {/* ── Floating Metadata Version Badge ── */}
      <g
        className={animated ? 'animate-bounce-subtle' : ''}
        transform="translate(225, 78)"
      >
        <rect
          x="-35"
          y="-14"
          width="70"
          height="28"
          rx="14"
          fill="var(--card)"
          stroke="var(--primary)"
          strokeWidth="1.5"
          className="shadow-md"
        />
        <circle cx="-18" cy="0" r="4" fill="var(--success)" />
</g>
    </svg>
  );
};

