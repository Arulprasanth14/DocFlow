import React from 'react';
import { type IsoIllustrationProps } from './IsoDocStack';

/**
 * IsoVault — Procedural Isometric Security Vault
 * Represents tenant isolation, encrypted document retention, and tamper-proof storage
 * with a heavy beveled vault door, cryptographic spoke tumbler, and glowing data shelves.
 */
export const IsoVault: React.FC<IsoIllustrationProps> = ({
  size = 240,
  className = '',
  animated = true,
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 320 320"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none overflow-visible ${className}`}
      aria-label="Isometric Tenant Security Vault"
      role="img"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        {/* Soft floor shadow */}
        <radialGradient id="iv-floor-shadow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.3" />
          <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
        </radialGradient>

        {/* Top Facet (Lightest) */}
        <linearGradient id="iv-top-facet" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--card)" stopOpacity="0.9" />
          <stop offset="100%" stopColor="var(--secondary)" stopOpacity="0.8" />
        </linearGradient>

        {/* Left Facet (Medium) */}
        <linearGradient id="iv-left-facet" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="var(--secondary)" stopOpacity="0.9" />
          <stop offset="100%" stopColor="var(--card)" stopOpacity="0.7" />
        </linearGradient>

        {/* Right Facet (Dark/Interior Chamber) */}
        <linearGradient id="iv-right-facet" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="var(--background)" stopOpacity="0.95" />
          <stop offset="100%" stopColor="var(--card)" stopOpacity="0.6" />
        </linearGradient>

        {/* Vault Door Metallic Sheen */}
        <linearGradient id="iv-door-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--card)" />
          <stop offset="50%" stopColor="var(--primary)" stopOpacity="0.25" />
          <stop offset="100%" stopColor="var(--card)" />
        </linearGradient>

        {/* Glowing Data Beam */}
        <linearGradient id="iv-beam-grad" x1="50%" y1="100%" x2="50%" y2="0%">
          <stop offset="0%" stopColor="var(--ring)" stopOpacity="0.4" />
          <stop offset="100%" stopColor="var(--ring)" stopOpacity="0" />
        </linearGradient>
      </defs>

      {/* ── Floor Shadow ── */}
      <ellipse
        cx="160"
        cy="255"
        rx="105"
        ry="42"
        fill="url(#iv-floor-shadow)"
      />

      {/* ── Vertical Upward Telemetry Beam ── */}
      <polygon
        points="110,180 210,180 235,50 85,50"
        fill="url(#iv-beam-grad)"
        className={animated ? 'animate-pulse opacity-60' : 'opacity-40'}
      />

      {/* ── Isometric Safe Body ── */}
      <g transform="translate(160, 160)">
        {/* Top Face (Rhombus) */}
        <polygon
          points="0,-75 85,-26 0,22 -85,-26"
          fill="url(#iv-top-facet)"
          stroke="var(--border)"
          strokeWidth="1.2"
        />

        {/* Left Face (Isometric Left) */}
        <polygon
          points="-85,-26 0,22 0,118 -85,70"
          fill="url(#iv-left-facet)"
          stroke="var(--border)"
          strokeWidth="1.2"
        />

        {/* Right Face / Interior Chamber Aperture (Isometric Right) */}
        <polygon
          points="0,22 85,-26 85,70 0,118"
          fill="url(#iv-right-facet)"
          stroke="var(--primary)"
          strokeOpacity="0.5"
          strokeWidth="1.2"
        />

        {/* Interior Glowing Data Shelves */}
        <g transform="translate(15, 20)">
          {/* Shelf 1 */}
          <polygon
            points="5,-6 55,-35 60,-32 10,-3"
            fill="var(--ring)"
            fillOpacity="0.3"
            stroke="var(--ring)"
            strokeWidth="0.8"
          />
          {/* Encrypted Document Ledger Blocks */}
          <polygon points="12,-5 22,-11 22,-20 12,-14" fill="var(--accent-violet)" fillOpacity="0.7" />
          <polygon points="25,-12 35,-18 35,-27 25,-21" fill="var(--ring)" fillOpacity="0.8" />
          <polygon points="38,-20 48,-26 48,-35 38,-29" fill="var(--success)" fillOpacity="0.7" />

          {/* Shelf 2 */}
          <polygon
            points="5,22 55,-7 60,-4 10,25"
            fill="var(--ring)"
            fillOpacity="0.3"
            stroke="var(--ring)"
            strokeWidth="0.8"
          />
          <polygon points="12,23 24,16 24,7 12,14" fill="var(--accent-violet)" fillOpacity="0.7" />
          <polygon points="27,14 39,7 39,-2 27,5" fill="var(--primary)" fillOpacity="0.8" />
        </g>

        {/* ── Heavy Vault Door (Swung open at 35 degrees) ── */}
        <g
          className={animated ? 'transition-transform duration-700 ease-out hover:rotate-6' : ''}
          transform="translate(85, 20)"
        >
          {/* Vault Door Slab */}
          <polygon
            points="0,-46 45,-20 45,76 0,50"
            fill="url(#iv-door-grad)"
            stroke="var(--primary)"
            strokeWidth="1.5"
          />
          <polygon
            points="45,-20 52,-24 52,72 45,76"
            fill="var(--secondary)"
            stroke="var(--border)"
            strokeWidth="1"
          />

          {/* Heavy Locking Bolts (Prongs extending from door edge) */}
          <rect x="-4" y="-20" width="8" height="6" rx="2" fill="var(--warning)" />
          <rect x="-4" y="0" width="8" height="6" rx="2" fill="var(--warning)" />
          <rect x="-4" y="20" width="8" height="6" rx="2" fill="var(--warning)" />

          {/* Cryptographic Tumbler Lock (Centered on door face) */}
          <g transform="translate(22, 14)">
            {/* Outer Tumbler Ring */}
            <ellipse
              cx="0"
              cy="0"
              rx="16"
              ry="22"
              fill="var(--card)"
              stroke="var(--primary)"
              strokeWidth="1.8"
            />
            {/* Spokes Wheel */}
            <line x1="-12" y1="-16" x2="12" y2="16" stroke="var(--primary)" strokeWidth="1.5" />
            <line x1="-14" y1="12" x2="14" y2="-12" stroke="var(--primary)" strokeWidth="1.5" />
            <line x1="0" y1="-20" x2="0" y2="20" stroke="var(--primary)" strokeWidth="1.5" />
            {/* Center Dial Hub */}
            <circle cx="0" cy="0" r="5" fill="var(--ring)" stroke="var(--primary)" strokeWidth="1" />
          </g>
        </g>

        {/* ── Floating Tenant Isolation Chip ── */}
        <g transform="translate(-50, -45)">
          <rect
            x="-35"
            y="-12"
            width="72"
            height="24"
            rx="12"
            fill="var(--card)"
            stroke="var(--ring)"
            strokeWidth="1.2"
          />
          <circle cx="-22" cy="0" r="3.5" fill="var(--ring)" className="animate-ping" />
          <circle cx="-22" cy="0" r="3.5" fill="var(--ring)" />
</g>
      </g>
    </svg>
  );
};

