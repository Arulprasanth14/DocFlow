import React from 'react';
import { type IsoIllustrationProps } from './IsoDocStack';

/**
 * IsoShieldBuilding — Procedural Isometric Enterprise Building with Shield
 * Represents organization infrastructure, role-based boundary defense,
 * and tenant compartmentalization.
 */
export const IsoShieldBuilding: React.FC<IsoIllustrationProps> = ({
  size = 240,
  className = '',
  animated = true,
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 320 320"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none overflow-visible ${className}`}
      aria-label="Isometric Enterprise Shield Building"
      role="img"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        {/* Soft floor shadow */}
        <radialGradient id="isb-floor-shadow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.28" />
          <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
        </radialGradient>

        {/* Shield Hex Glow */}
        <linearGradient id="isb-shield-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.35" />
          <stop offset="50%" stopColor="var(--accent-violet)" stopOpacity="0.15" />
          <stop offset="100%" stopColor="var(--ring)" stopOpacity="0.05" />
        </linearGradient>

        {/* Building Facets */}
        <linearGradient id="isb-roof-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--card)" stopOpacity="0.95" />
          <stop offset="100%" stopColor="var(--secondary)" stopOpacity="0.8" />
        </linearGradient>
        <linearGradient id="isb-left-facade" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="var(--secondary)" stopOpacity="0.9" />
          <stop offset="100%" stopColor="var(--card)" stopOpacity="0.75" />
        </linearGradient>
        <linearGradient id="isb-right-facade" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="var(--background)" stopOpacity="0.95" />
          <stop offset="100%" stopColor="var(--secondary)" stopOpacity="0.7" />
        </linearGradient>
      </defs>

      {/* ── Floor Shadow ── */}
      <ellipse
        cx="160"
        cy="255"
        rx="110"
        ry="42"
        fill="url(#isb-floor-shadow)"
      />

      {/* ── Translucent Security Forcefield Dome ── */}
      <path
        d="M 60 215 C 60 110 260 110 260 215 C 260 250 60 250 60 215 Z"
        fill="url(#isb-shield-grad)"
        stroke="var(--primary)"
        strokeOpacity="0.6"
        strokeWidth="1.5"
        strokeDasharray="6 3"
        className={animated ? 'animate-pulse' : ''}
      />

      {/* ── Isometric Corporate Tower ── */}
      <g transform="translate(160, 160)">
        {/* Tier 1 (Base Tower) */}
        {/* Roof */}
        <polygon points="0,-48 64,-12 0,24 -64,-12" fill="url(#isb-roof-grad)" stroke="var(--border)" strokeWidth="1" />
        {/* Left Wall */}
        <polygon points="-64,-12 0,24 0,98 -64,62" fill="url(#isb-left-facade)" stroke="var(--border)" strokeWidth="1" />
        {/* Right Wall */}
        <polygon points="0,24 64,-12 64,62 0,98" fill="url(#isb-right-facade)" stroke="var(--border)" strokeWidth="1" />

        {/* Windows Grid (Left Facade) */}
        <g stroke="var(--primary)" strokeOpacity="0.4" strokeWidth="1.2">
          <line x1="-48" y1="6" x2="-16" y2="24" />
          <line x1="-48" y1="24" x2="-16" y2="42" />
          <line x1="-48" y1="42" x2="-16" y2="60" />
          <line x1="-32" y1="-3" x2="-32" y2="70" />
        </g>

        {/* Windows Grid (Right Facade) */}
        <g stroke="var(--primary)" strokeOpacity="0.45" strokeWidth="1.2">
          <line x1="16" y1="24" x2="48" y2="6" />
          <line x1="16" y1="42" x2="48" y2="24" />
          <line x1="16" y1="60" x2="48" y2="42" />
          <line x1="32" y1="-3" x2="32" y2="70" />
        </g>

        {/* Tier 2 (Penthouse Spire) */}
        <g transform="translate(0, -38)">
          <polygon points="0,-32 36,-10 0,12 -36,-10" fill="url(#isb-roof-grad)" stroke="var(--primary)" strokeWidth="1.2" />
          <polygon points="-36,-10 0,12 0,40 -36,18" fill="url(#isb-left-facade)" stroke="var(--border)" strokeWidth="0.8" />
          <polygon points="0,12 36,-10 36,18 0,40" fill="url(#isb-right-facade)" stroke="var(--border)" strokeWidth="0.8" />
        </g>

        {/* Tier 3 (Spire Antenna) */}
        <line x1="0" y1="-70" x2="0" y2="-98" stroke="var(--primary)" strokeWidth="2.5" strokeLinecap="round" />
        <circle cx="0" cy="-98" r="4" fill="var(--primary)" className={animated ? 'animate-ping' : ''} />
        <circle cx="0" cy="-98" r="4" fill="var(--primary)" />
      </g>

      {/* ── Floating Security Shield Emblem ── */}
      <g
        className={animated ? 'transition-transform duration-700 ease-out hover:-translate-y-2' : ''}
        transform="translate(160, 60)"
      >
        <path
          d="M 0 -18 L 18 -10 C 18 10 0 22 0 22 C 0 22 -18 10 -18 -10 Z"
          fill="var(--card)"
          stroke="var(--primary)"
          strokeWidth="2"
        />
        <path
          d="M -6 -2 L -1 3 L 7 -5"
          stroke="var(--success)"
          strokeWidth="2.2"
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      </g>
    </svg>
  );
};

