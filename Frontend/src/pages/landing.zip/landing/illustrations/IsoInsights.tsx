import React from 'react';
import { type IsoIllustrationProps } from './IsoDocStack';

/**
 * IsoInsights — Procedural Isometric Analytics & Telemetry Console
 * Depicts approval turnaround velocity, departmental volume throughput,
 * and SLA metrics with 3D isometric bar pillars and rising trend spline.
 */
export const IsoInsights: React.FC<IsoIllustrationProps> = ({
  size = 240,
  className = '',
  animated = true,
}) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 320 320"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`select-none overflow-visible ${className}`}
      aria-label="Isometric Analytics and Insights Console"
      role="img"
      aria-hidden="true"
      focusable="false"
    >
      <defs>
        {/* Floor Shadow */}
        <radialGradient id="ii-floor-shadow" cx="50%" cy="50%" r="50%">
          <stop offset="0%" stopColor="var(--primary)" stopOpacity="0.28" />
          <stop offset="100%" stopColor="var(--primary)" stopOpacity="0" />
        </radialGradient>

        {/* Bar Pillar Facets */}
        <linearGradient id="ii-pillar-top1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--primary)" />
          <stop offset="100%" stopColor="var(--primary)" stopOpacity="0.8" />
        </linearGradient>
        <linearGradient id="ii-pillar-top2" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--accent-violet)" />
          <stop offset="100%" stopColor="var(--accent-violet)" stopOpacity="0.8" />
        </linearGradient>
        <linearGradient id="ii-pillar-top3" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--success)" />
          <stop offset="100%" stopColor="var(--success)" stopOpacity="0.8" />
        </linearGradient>

        {/* Base Grid Gradient */}
        <linearGradient id="ii-grid-grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="var(--card)" stopOpacity="0.9" />
          <stop offset="100%" stopColor="var(--secondary)" stopOpacity="0.75" />
        </linearGradient>
      </defs>

      {/* ── Floor Shadow ── */}
      <ellipse
        cx="160"
        cy="255"
        rx="115"
        ry="42"
        fill="url(#ii-floor-shadow)"
      />

      {/* ── Isometric Base Grid Platform ── */}
      <g transform="translate(160, 210)">
        <polygon
          points="0,-50 95,-2 0,46 -95,-2"
          fill="url(#ii-grid-grad)"
          stroke="var(--border)"
          strokeWidth="1.2"
        />
        {/* Isometric Grid Lines */}
        <line x1="-47" y1="-26" x2="48" y2="22" stroke="var(--primary)" strokeOpacity="0.15" strokeWidth="1" />
        <line x1="-47" y1="22" x2="48" y2="-26" stroke="var(--primary)" strokeOpacity="0.15" strokeWidth="1" />
      </g>

      {/* ── 3D Isometric Bar Columns ── */}
      {/* Pillar 1 (Q1, Left, Height 45px) */}
      <g transform="translate(105, 185)">
        {/* Top */}
        <polygon points="0,-10 18,0 0,10 -18,0" fill="url(#ii-pillar-top1)" stroke="var(--primary)" strokeWidth="0.8" />
        {/* Left */}
        <polygon points="-18,0 0,10 0,55 -18,45" fill="var(--primary)" fillOpacity="0.7" />
        {/* Right */}
        <polygon points="0,10 18,0 18,45 0,55" fill="var(--primary)" fillOpacity="0.9" />
      </g>

      {/* Pillar 2 (Q2, Center-Left, Height 75px) */}
      <g transform="translate(142, 172)">
        <polygon points="0,-10 18,0 0,10 -18,0" fill="url(#ii-pillar-top2)" stroke="var(--accent-violet)" strokeWidth="0.8" />
        <polygon points="-18,0 0,10 0,85 -18,75" fill="var(--accent-violet)" fillOpacity="0.7" />
        <polygon points="0,10 18,0 18,75 0,85" fill="var(--accent-violet)" fillOpacity="0.9" />
      </g>

      {/* Pillar 3 (Q3, Center-Right, Height 105px) */}
      <g transform="translate(178, 160)">
        <polygon points="0,-10 18,0 0,10 -18,0" fill="url(#ii-pillar-top3)" stroke="var(--success)" strokeWidth="0.8" />
        <polygon points="-18,0 0,10 0,115 -18,105" fill="var(--success)" fillOpacity="0.7" />
        <polygon points="0,10 18,0 18,105 0,115" fill="var(--success)" fillOpacity="0.9" />
      </g>

      {/* Pillar 4 (Q4, Right, Height 85px) */}
      <g transform="translate(214, 178)">
        <polygon points="0,-10 18,0 0,10 -18,0" fill="url(#ii-pillar-top1)" stroke="var(--primary)" strokeWidth="0.8" />
        <polygon points="-18,0 0,10 0,95 -18,85" fill="var(--primary)" fillOpacity="0.7" />
        <polygon points="0,10 18,0 18,85 0,95" fill="var(--primary)" fillOpacity="0.9" />
      </g>

      {/* ── Rising Trend Spline Ribbon ── */}
      <path
        d="M 105 175 Q 142 120 178 115 T 214 135"
        stroke="var(--ring)"
        strokeWidth="3"
        strokeLinecap="round"
        fill="none"
        className={animated ? 'animate-pulse' : ''}
      />
      {/* Spline Keyframe Vertex Nodes */}
      <circle cx="105" cy="175" r="4" fill="var(--primary)" stroke="var(--card)" strokeWidth="1.5" />
      <circle cx="142" cy="138" r="4" fill="var(--accent-violet)" stroke="var(--card)" strokeWidth="1.5" />
      <circle cx="178" cy="115" r="5" fill="var(--success)" stroke="var(--card)" strokeWidth="1.5" />
      <circle cx="214" cy="135" r="4" fill="var(--primary)" stroke="var(--card)" strokeWidth="1.5" />

      {/* ── Floating Metric Pill Card ── */}
      <g
        className={animated ? 'transition-transform duration-700 ease-out hover:-translate-y-2' : ''}
        transform="translate(195, 80)"
      >
        <rect
          x="-45"
          y="-14"
          width="90"
          height="28"
          rx="14"
          fill="var(--card)"
          stroke="var(--success)"
          strokeWidth="1.5"
          className="shadow-lg"
        />
</g>
    </svg>
  );
};

