import React from 'react';

interface AuroraGlowProps {
  className?: string;
  intensity?: 'subtle' | 'medium' | 'vibrant';
}

export const AuroraGlow: React.FC<AuroraGlowProps> = ({
  className = '',
  intensity = 'medium',
}) => {
  const opacities = {
    subtle: 'opacity-40',
    medium: 'opacity-65',
    vibrant: 'opacity-90',
  };

  return (
    <div
      className={`pointer-events-none absolute inset-0 overflow-hidden select-none -z-10 ${opacities[intensity]} ${className}`}
      aria-hidden="true"
    >
      <div
        className="absolute -top-[20%] left-1/2 -translate-x-1/2 w-[65vw] max-w-[850px] h-[480px] rounded-full blur-[100px]"
        style={{
          background:
            'radial-gradient(ellipse at center, var(--lp-aurora-primary) 0%, var(--lp-aurora-secondary) 50%, transparent 75%)',
        }}
      />
      <div
        className="absolute top-[30%] -left-[10%] w-[35vw] max-w-[420px] h-[360px] rounded-full blur-[90px]"
        style={{
          background: 'radial-gradient(circle, var(--lp-aurora-secondary) 0%, transparent 70%)',
        }}
      />
    </div>
  );
};

export default AuroraGlow;

