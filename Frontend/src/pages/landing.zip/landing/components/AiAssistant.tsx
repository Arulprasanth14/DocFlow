import React, { useState, useEffect } from 'react';
import {
  Bot,
  FileText,
  Shield,
  ArrowRight,
  Database,
  Lock,
  Cpu,
  Sparkles,
} from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { StatusChip } from './StatusChip';
import { Container } from './Container';
import { Docky } from './Docky';
import { TornDivider } from './TornDivider';
import { IsoChatBubbles } from '../illustrations';
import { prefersReducedMotion } from '@/lib/motion';

const MOCK_CONVERSATIONS = [
  {
    tabLabel: 'Policy Q&A',
    question: 'How many casual leaves do I have left this quarter?',
    fullAnswer:
      'According to Section 4.2 of your company’s 2026 Engineering Leave Policy: You have 6 casual leave days remaining for Q4. Leave requests above 3 continuous days require Department Head sign-off.',
    sources: ['Policy_Handbook_v3.pdf', 'Leave_Rules_2026.docx'],
  },
  {
    tabLabel: 'Contract Review',
    question: 'Summarize the indemnity clause in the vendor agreement.',
    fullAnswer:
      'Clause 14.1 of Vendor Agreement #MSA-9042 stipulates reciprocal indemnity capped at 12 months of total service fees. Mutual liability exclusions apply to standard gross negligence terms.',
    sources: ['CloudPeak_MSA_Final.pdf', 'Legal_Review_Note.txt'],
  },
  {
    tabLabel: 'Draft Expense',
    question: 'Draft a standard travel reimbursement request for Bangalore visit.',
    fullAnswer:
      'I have generated a draft reimbursement request matching your organization’s standard Finance template. Line items include flight tickets and accommodation per the internal tier-2 city ceiling.',
    sources: ['Travel_Policy_FY26.pdf', 'Expense_Per_Diem.xlsx'],
  },
];

export const AiAssistant: React.FC = () => {
  const [selectedPromptIdx, setSelectedPromptIdx] = useState(0);
  const [displayedAnswer, setDisplayedAnswer] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  // Typing simulation effect on tab change
  useEffect(() => {
    const fullText = MOCK_CONVERSATIONS[selectedPromptIdx].fullAnswer;
    if (prefersReducedMotion()) {
      setDisplayedAnswer(fullText);
      setIsTyping(false);
      return;
    }

    setIsTyping(true);
    setDisplayedAnswer('');
    let currentIdx = 0;
    const interval = setInterval(() => {
      currentIdx += 3;
      if (currentIdx >= fullText.length) {
        setDisplayedAnswer(fullText);
        setIsTyping(false);
        clearInterval(interval);
      } else {
        setDisplayedAnswer(fullText.slice(0, currentIdx));
      }
    }, 18);

    return () => clearInterval(interval);
  }, [selectedPromptIdx]);

  return (
    <section id="ai" aria-labelledby="ai-heading" className="relative lp-section-rhythm bg-background overflow-x-clip">
      <Container data-qa="container">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-2 mb-3">
            <span className="lp-eyebrow px-3 py-1 rounded-full bg-accent-violet/10 border border-accent-violet/25 text-accent-violet">
              {LANDING_CONTENT.aiAssistant.eyebrow}
            </span>
            <StatusChip status={LANDING_CONTENT.aiAssistant.status} size="sm" />
          </div>
          <h2 id="ai-heading" className="lp-h2 text-foreground mt-2">
            {LANDING_CONTENT.aiAssistant.heading}
          </h2>
          <p className="lp-body text-muted-foreground mt-4">
            {LANDING_CONTENT.aiAssistant.subheading}
          </p>

          {/* Grounding Truth Banner */}
          <div className="mt-6 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent-violet/10 border border-accent-violet/25 text-[0.8125rem] font-bold text-accent-violet">
            <Lock size={14} />
            <span>{LANDING_CONTENT.aiAssistant.keyTruth}</span>
          </div>
        </div>

        {/* Main Grid: Left Chat Mockup / Right Architecture Diagram */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Chat Window Simulation (7 cols) */}
          <div
            data-cursor="card" data-qa="card"
            className="lg:col-span-7 lp-glass rounded-3xl border border-border shadow-xl overflow-hidden flex flex-col justify-between min-h-[500px]"
          >
            {/* Chat Window Header */}
            <div className="p-5 border-b border-border bg-card/60 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-accent-violet/15 text-accent-violet flex items-center justify-center p-1 border border-accent-violet/30">
                  <Docky size={32} expression="happy" accessory="glasses" animated={false} />
                </div>
                <div>
                  <div className="font-heading font-bold text-[0.9375rem] text-foreground flex items-center gap-2">
                    <span>Docky Assistant</span>
                    <span className="text-[0.8125rem] font-semibold text-success bg-success/10 border border-success/20 px-2 py-0.5 rounded-full">
                      Tenant Grounded
                    </span>
                  </div>
                  <div className="text-[0.8125rem] text-muted-foreground">
                    Private context: Only your organization’s uploaded documents
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Prompt Selector Tabs */}
            <div className="px-5 py-3 border-b border-border/70 flex items-center gap-2 overflow-x-auto no-scrollbar text-[0.8125rem] bg-muted/30">
              <span className="text-[0.8125rem] text-muted-foreground font-semibold shrink-0">Try asking:</span>
              {MOCK_CONVERSATIONS.map((c, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setSelectedPromptIdx(i)}
                  className={`px-3.5 py-1.5 rounded-full text-[0.8125rem] font-medium transition-all cursor-pointer ${
                    selectedPromptIdx === i
                      ? 'bg-accent-violet/20 text-accent-violet ring-1 ring-accent-violet/50'
                      : 'bg-card text-muted-foreground border border-border hover:text-foreground'
                  }`}
                >
                  {c.tabLabel}
                </button>
              ))}
            </div>

            {/* Message Thread Body */}
            <div className="p-6 space-y-6 flex-1 font-sans text-[0.8125rem] sm:text-[0.9375rem]">
              {/* User Prompt Message */}
              <div className="flex items-start gap-3 justify-end">
                <div className="bg-primary text-primary-foreground p-4 rounded-2xl rounded-tr-sm max-w-md shadow-xs leading-relaxed text-[13px] sm:text-[0.9375rem]">
                  {MOCK_CONVERSATIONS[selectedPromptIdx].question}
                </div>
                <div className="w-8 h-8 rounded-full bg-gradient-brand text-primary-foreground flex items-center justify-center shrink-0 font-bold text-[0.8125rem] mt-1">
                  U
                </div>
              </div>

              {/* Docky Assistant Response */}
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-accent-violet/15 text-accent-violet flex items-center justify-center shrink-0 font-bold text-[0.8125rem] mt-1 border border-accent-violet/30">
                  <Bot size={16} />
                </div>
                <div className="space-y-3 max-w-lg">
                  <div className="lp-glass p-4 sm:p-5 rounded-2xl rounded-tl-sm border border-border shadow-xs text-foreground leading-relaxed text-[13px] sm:text-[0.9375rem]">
                    {displayedAnswer}
                    {isTyping && (
                      <span className="inline-block w-1.5 h-4 ml-1 bg-accent-violet animate-pulse align-middle" />
                    )}
                  </div>

                  {/* Grounded Source Citations */}
                  <div className="flex flex-wrap items-center gap-2 text-[0.8125rem] text-muted-foreground pt-1">
                    <span className="font-semibold text-accent-violet flex items-center gap-1">
                      <Sparkles size={12} />
                      Grounded Sources:
                    </span>
                    {MOCK_CONVERSATIONS[selectedPromptIdx].sources.map((src) => (
                      <span
                        key={src}
                        className="font-mono bg-muted/80 px-2 py-0.5 rounded border border-border text-[0.8125rem] text-foreground"
                      >
                        {src}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Styled App Input Bar (No browser defaults) */}
            <div className="p-4 border-t border-border bg-card/50 flex items-center gap-3">
              <div className="relative flex-1">
                <input
                  type="text"
                  readOnly
                  value="Ask questions from company policies, documents, or contracts..."
                  className="w-full bg-card border border-border rounded-xl px-4 py-2.5 text-[0.8125rem] text-muted-foreground select-none focus:outline-none"
                />
              </div>
              <button
                data-cursor="link" type="button"
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-accent-violet/15 text-accent-violet ring-1 ring-accent-violet/40 text-[0.9375rem] font-semibold hover:bg-accent-violet/25 transition-colors cursor-default"
              >
                <span>Ask</span>
                <ArrowRight size={13} />
              </button>
            </div>
          </div>

          {/* Right: Isolation Architecture & Resiliency (5 cols) */}
          <div className="lg:col-span-5 space-y-6">
            {/* 3D Isometric Discussion Cards */}
            <div
              data-cursor="card" data-qa="card"
              className="lp-glass p-5 rounded-3xl border border-accent-violet/25 flex flex-col items-center text-center overflow-hidden"
            >
              <div className="-my-2">
                <IsoChatBubbles size={175} animated={true} />
              </div>
              <div className="text-[0.8125rem] font-bold text-accent-violet uppercase tracking-wider">
                In-Context Discussion Evidence
              </div>
              <p className="text-[0.8125rem] text-muted-foreground mt-1 max-w-xs">
                Contextual @mentions and clarification dialogues are preserved as verifiable audit history.
              </p>
            </div>

            {/* Privacy Architecture Diagram */}
            <div
              data-cursor="card" data-qa="card"
              className="lp-glass p-6 sm:p-7 rounded-3xl border border-border shadow-md space-y-5"
            >
              <div className="flex items-center gap-2.5">
                <Database size={20} className="text-accent-violet" />
                <h3 className="font-heading font-bold text-base text-foreground">
                  Tenant-Isolated Knowledge Architecture
                </h3>
              </div>
              <p className="text-[0.8125rem] text-muted-foreground leading-relaxed">
                Docky operates within your organization’s private partition. No public internet data blending or external model training on your internal documents:
              </p>

              {/* 3 Flow Steps with Connecting Connectors */}
              <div className="space-y-3 pt-2 relative">
                <div className="p-3.5 rounded-xl bg-card border border-border flex items-center gap-3 text-[0.8125rem] shadow-xs">
                  <div className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
                    <FileText size={16} />
                  </div>
                  <div>
                    <div className="text-foreground font-semibold">1. Uploaded Company Documents</div>
                    <div className="text-[0.8125rem] text-muted-foreground">Handbooks, NDAs, and approved templates</div>
                  </div>
                </div>

                <div className="flex justify-center -my-1 text-muted-foreground/60">
                  <div className="w-0.5 h-3 bg-border" />
                </div>

                <div className="p-3.5 rounded-xl bg-card border border-accent-violet/30 flex items-center gap-3 text-[0.8125rem] shadow-xs">
                  <div className="w-8 h-8 rounded-lg bg-accent-violet/15 text-accent-violet flex items-center justify-center shrink-0">
                    <Database size={16} />
                  </div>
                  <div>
                    <div className="text-foreground font-semibold">2. Private Org Knowledge Base</div>
                    <div className="text-[0.8125rem] text-muted-foreground">Encrypted embeddings within tenant boundary</div>
                  </div>
                </div>

                <div className="flex justify-center -my-1 text-muted-foreground/60">
                  <div className="w-0.5 h-3 bg-border" />
                </div>

                <div className="p-3.5 rounded-xl bg-card border border-border flex items-center gap-3 text-[0.8125rem] shadow-xs">
                  <div className="w-8 h-8 rounded-lg bg-success/10 text-success flex items-center justify-center shrink-0">
                    <Bot size={16} />
                  </div>
                  <div>
                    <div className="text-foreground font-semibold">3. Docky Assistant Q&A</div>
                    <div className="text-[0.8125rem] text-muted-foreground">Synthesizes answers with citation links</div>
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-accent-violet/5 border border-accent-violet/20 flex items-center gap-2.5 text-[0.8125rem] text-accent-violet font-medium">
                <Shield size={16} className="shrink-0" />
                <span>Organizational knowledge stays strictly isolated to your tenant.</span>
              </div>
            </div>

            {/* Decoupled Resiliency Note */}
            <div
              data-cursor="card" data-qa="card"
              className="lp-glass p-5 rounded-2xl border border-border text-[0.8125rem] text-muted-foreground space-y-2"
            >
              <div className="flex items-center gap-2 font-bold text-foreground">
                <Cpu size={16} className="text-primary" />
                <span>AI is an optional modular layer</span>
              </div>
              <p className="leading-relaxed">
                {LANDING_CONTENT.aiAssistant.safetyNote}
              </p>
            </div>
          </div>
        </div>
      </Container>

      {/* Torn Edge Transition to Analytics section */}
      <div className="mt-16 sm:mt-24">
        <TornDivider fillToken="var(--lp-section-deep)" direction="bottom" seed="C" />
      </div>
    </section>
  );
};

export default AiAssistant;
