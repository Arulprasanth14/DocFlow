import React, { useState } from 'react';
import {
  BarChart3,
  TrendingUp,
  Clock,
  ShieldCheck,
  FileText,
  Search,
  Filter,
} from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { StatusChip } from './StatusChip';
import { Container } from './Container';
import { TornDivider } from './TornDivider';
import { IsoInsights } from '../illustrations';

export const Analytics: React.FC = () => {
  const [timeframe, setTimeframe] = useState<'monthly' | 'yearly'>('monthly');

  const monthlyMetrics = [
    { label: 'Documents Processed', value: '1,420+', delta: '+18% vs last month', icon: FileText },
    { label: 'Avg. Approval Turnaround', value: '3.4 hrs', delta: '42% faster than manual routing', icon: Clock },
    { label: 'Active Workflow Instances', value: '86', delta: 'Running across 6 depts', icon: TrendingUp },
    { label: 'Decision Verification Rate', value: 'High', delta: 'Consistently logged audit history', icon: ShieldCheck },
  ];

  const yearlyMetrics = [
    { label: 'Documents Processed', value: '18,650+', delta: '+140% annual throughput', icon: FileText },
    { label: 'Avg. Approval Turnaround', value: '2.8 hrs', delta: 'Steady SLA adherence', icon: Clock },
    { label: 'Active Workflow Instances', value: '124', delta: 'Scaled organization-wide', icon: TrendingUp },
    { label: 'Decision Verification Rate', value: 'High', delta: 'Documented audit coverage', icon: ShieldCheck },
  ];

  const currentMetrics = timeframe === 'monthly' ? monthlyMetrics : yearlyMetrics;

  const monthlyChartBars = [
    { name: 'Mon', h: '45%', count: '142' },
    { name: 'Tue', h: '72%', count: '230' },
    { name: 'Wed', h: '88%', count: '284' },
    { name: 'Thu', h: '64%', count: '205' },
    { name: 'Fri', h: '95%', count: '310' },
    { name: 'Sat', h: '25%', count: '82' },
    { name: 'Sun', h: '18%', count: '58' },
  ];

  const yearlyChartBars = [
    { name: 'Q1', h: '62%', count: '3,840' },
    { name: 'Q2', h: '78%', count: '4,620' },
    { name: 'Q3', h: '85%', count: '5,110' },
    { name: 'Q4', h: '96%', count: '5,880' },
  ];

  const currentBars = timeframe === 'monthly' ? monthlyChartBars : yearlyChartBars;

  return (
    <section id="analytics" aria-labelledby="analytics-heading" className="relative lp-section-rhythm lp-section-deep overflow-x-clip">
      <Container data-qa="container">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-2 mb-3">
            <span className="lp-eyebrow px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary">
              {LANDING_CONTENT.analytics.eyebrow}
            </span>
            <StatusChip status={LANDING_CONTENT.analytics.status} size="sm" />
          </div>
          <h2 id="analytics-heading" className="lp-h2 text-foreground mt-2">
            {LANDING_CONTENT.analytics.heading}
          </h2>
          <p className="lp-body text-muted-foreground mt-4">
            {LANDING_CONTENT.analytics.subheading}
          </p>

          {/* Timeframe Toggle Buttons */}
          <div className="mt-8 inline-flex items-center gap-1.5 p-1.5 rounded-xl bg-card border border-border shadow-xs">
            <button
              data-cursor="link" type="button"
              onClick={() => setTimeframe('monthly')}
              className={`px-4 py-2 rounded-lg text-[0.8125rem] font-bold transition-all cursor-pointer ${
                timeframe === 'monthly'
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Monthly View
            </button>
            <button
              data-cursor="link" type="button"
              onClick={() => setTimeframe('yearly')}
              className={`px-4 py-2 rounded-lg text-[0.8125rem] font-bold transition-all cursor-pointer ${
                timeframe === 'yearly'
                  ? 'bg-primary text-primary-foreground shadow-sm'
                  : 'text-muted-foreground hover:text-foreground'
              }`}
            >
              Yearly View
            </button>
          </div>
        </div>

        {/* 4 Metric KPI Cards with clear "Sample data" labels */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {currentMetrics.map((m) => {
            const Icon = m.icon;
            return (
              <div
                key={m.label}
                data-qa="card"
                className="lp-glass p-6 rounded-2xl border border-border shadow-xs space-y-3 relative overflow-hidden"
              >
                <div className="flex items-center justify-between">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center">
                    <Icon size={18} />
                  </div>
                  {/* Facts compliance: sample data tag */}
                  <span className="text-[0.8125rem] text-muted-foreground bg-muted px-2 py-0.5 rounded uppercase font-semibold">
                    Sample data
                  </span>
                </div>

                <div>
                  <div className="text-2xl sm:text-3xl font-extrabold text-foreground tracking-tight">
                    {m.value}
                  </div>
                  <div className="text-[0.8125rem] font-semibold text-muted-foreground mt-1">
                    {m.label}
                  </div>
                </div>

                <div className="text-[0.8125rem] text-success font-semibold pt-2 border-t border-border flex items-center gap-1">
                  <span>{m.delta}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Dashboard Chart Simulation & Search Discovery Bar */}
        <div
          data-cursor="card" data-qa="card"
          className="mt-10 lp-glass p-6 sm:p-8 rounded-3xl border border-border shadow-xl space-y-6"
        >
          {/* Styled Search and Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pb-6 border-b border-border">
            <div className="relative w-full sm:max-w-md">
              <Search
                size={16}
                className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted-foreground"
              />
              <input
                type="text"
                readOnly
                value="Search full-text indexed documents, decisions, or signers..."
                className="w-full bg-input border border-input-border rounded-xl pl-10 pr-4 py-2.5 text-[0.8125rem] text-muted-foreground select-none focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto text-[0.8125rem] text-muted-foreground">
              <span className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-card border border-border">
                <Filter size={13} className="text-primary" />
                <span>Department: All</span>
              </span>
              <span className="px-3 py-1.5 rounded-lg bg-card border border-border font-medium">
                Status: Completed
              </span>
            </div>
          </div>

          {/* 2-Column Insights Arena */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left (7 cols): Bar Chart Visualization in Accent & Ice Tones */}
            <div className="lg:col-span-7">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <BarChart3 size={18} className="text-primary" />
                  <span className="font-heading font-bold text-[0.9375rem] text-foreground">
                    Workflow Turnaround Velocity ({timeframe === 'monthly' ? 'Last 7 Days' : 'Quarterly Trend'})
                  </span>
                </div>
                <span className="text-[0.8125rem] text-muted-foreground uppercase">
                  Rendered with Ice Tones
                </span>
              </div>

              {/* Disciplined height bar chart: 220px */}
              <div className="h-56 w-full flex items-end justify-between gap-3 sm:gap-6 pt-6 px-2 border-b border-border/60">
                {currentBars.map((bar) => (
                  <div key={bar.name} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                    {/* Hover count bubble */}
                    <span className="text-[0.8125rem] text-muted-foreground opacity-75 group-hover:opacity-100 transition-opacity">
                      {bar.count}
                    </span>
                    <div
                      className="w-full max-w-[48px] rounded-t-lg transition-all duration-500 ease-out hover:brightness-110"
                      style={{
                        height: bar.h,
                        background: 'var(--gradient-brand)',
                        boxShadow: 'var(--lp-shadow-2)',
                      }}
                    />
                    <span className="text-[0.8125rem] font-semibold text-muted-foreground pt-1">
                      {bar.name}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Right (5 cols): 3D Isometric Telemetry Console */}
            <div className="lg:col-span-5 flex flex-col items-center justify-center p-4 rounded-2xl bg-secondary/20 border border-border/80 text-center">
              <div className="-my-2">
                <IsoInsights size={200} animated={true} />
              </div>
              <div className="text-[0.8125rem] font-bold text-primary uppercase tracking-wider">
                SLA Velocity & Throughput
              </div>
              <p className="text-[0.8125rem] text-muted-foreground mt-1 max-w-xs">
                Real-time pipeline metrics tracking turnaround speed and multi-department bottlenecks.
              </p>
            </div>
          </div>
        </div>
      </Container>

      {/* Torn Edge Transition to Tenants section */}
      <div className="mt-16 sm:mt-24">
        <TornDivider fillToken="var(--background)" direction="bottom" seed="A" />
      </div>
    </section>
  );
};

export default Analytics;
