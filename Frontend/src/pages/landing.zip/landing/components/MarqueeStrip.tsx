import React from 'react';
import {
  FileText,
  Receipt,
  FileCheck2,
  FileSignature,
  MailCheck,
  Cpu,
  Layers,
  CheckCircle2,
} from 'lucide-react';

interface MarqueeDocType {
  label: string;
  category: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
}

const DOCUMENT_TYPES: MarqueeDocType[] = [
  { label: 'Leave Requests', category: 'HR & People', icon: FileText },
  { label: 'Purchase Orders', category: 'Procurement', icon: FileCheck2 },
  { label: 'Reimbursement Claims', category: 'Finance', icon: Receipt },
  { label: 'Vendor Contracts', category: 'Legal', icon: FileSignature },
  { label: 'HR & Promotion Letters', category: 'Executive', icon: MailCheck },
  { label: 'Architecture Reviews', category: 'Engineering', icon: Cpu },
  { label: 'Budget Adjustments', category: 'Operations', icon: Layers },
  { label: 'General Approvals', category: 'Departmental', icon: CheckCircle2 },
];

/**
 * MarqueeStrip — slow continuous ribbon of the document types DocFlow routes.
 * Pauses on hover and on keyboard focus; edge fade is a CSS mask so it works
 * over any section background in either theme.
 */
export const MarqueeStrip: React.FC = () => {
  const items = [...DOCUMENT_TYPES, ...DOCUMENT_TYPES];

  return (
    <section
      className="relative w-full py-7 lp-section-deep border-y border-border"
      aria-label="Document workflows DocFlow routes"
    >
      <div className="lp-marquee" data-cursor="drag">
        <div className="lp-marquee-track items-center gap-4 px-2">
          {items.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={`${item.label}-${idx}`}
                aria-hidden={idx >= DOCUMENT_TYPES.length}
                className="lp-glass flex items-center gap-3 px-4 py-2.5 rounded-xl hover:-translate-y-0.5 transition-transform duration-300 select-none"
              >
                <span className="w-7 h-7 shrink-0 rounded-lg bg-primary/12 text-primary flex items-center justify-center">
                  <Icon size={15} />
                </span>
                <span className="font-heading font-semibold text-foreground whitespace-nowrap text-[0.9375rem]">
                  {item.label}
                </span>
                <span className="text-muted-foreground whitespace-nowrap px-2 py-0.5 rounded-md bg-secondary text-[0.8125rem]">
                  {item.category}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default MarqueeStrip;
