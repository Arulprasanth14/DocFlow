import React from 'react';
import { useJourneyProgress, useActiveSection } from '../store';

const STAGES = [
  { id: 'draft', name: 'Draft' },
  { id: 'submitted', name: 'Submitted' },
  { id: 'pending', name: 'Pending' },
  { id: 'decision', name: 'Decision' },
  { id: 'archived', name: 'Archived' },
];

/**
 * LifecycleTracker — Floating Desktop Document Stage Indicator
 * Driven 100% by the single source of truth in store.ts.
 * Displays only while user is within the Journey/Workflow experience,
 * completely eliminating desync issues.
 */
export const LifecycleTracker: React.FC = () => {
  const { stageIndex } = useJourneyProgress();
  const activeSection = useActiveSection();

  // Show tracker only during relevant sections (journey, features, roles, approvals)
  const isRelevantSection = ['journey', 'features', 'roles', 'approvals'].includes(activeSection);

  if (!isRelevantSection) {
    return null;
  }

  return (
    <div
      className="fixed right-6 top-1/2 -translate-y-1/2 z-40 hidden xl:flex flex-col gap-2 pointer-events-auto"
      aria-label="Document Lifecycle Stages"
      data-qa="lifecycle-tracker"
    >
      <div className="lp-glass py-3 px-3.5 flex flex-col gap-2 rounded-2xl border border-border/80 shadow-lg backdrop-blur-md">
        <div className="text-[0.8125rem] font-bold uppercase tracking-wider text-muted-foreground px-1 pb-1 border-b border-border">
          Stage {stageIndex + 1}/5
        </div>

        {STAGES.map((s, idx) => {
          const isActive = stageIndex === idx;
          const isPassed = stageIndex > idx;

          return (
            <a
              key={s.id}
              href={`#stage-${s.id}`}
              className={`flex items-center gap-2 px-2.5 py-1.5 rounded-lg text-[0.8125rem] font-semibold transition-all ${
                isActive
                  ? 'bg-primary text-primary-foreground shadow-xs scale-102'
                  : isPassed
                  ? 'text-foreground/80 hover:bg-secondary/60'
                  : 'text-muted-foreground hover:text-foreground hover:bg-secondary/40'
              }`}
            >
              <span
                className={`w-2 h-2 rounded-full transition-colors ${
                  isActive
                    ? 'bg-primary-foreground'
                    : isPassed
                    ? 'bg-success'
                    : 'bg-muted-foreground/30'
                }`}
              />
              <span>{s.name}</span>
            </a>
          );
        })}
      </div>
    </div>
  );
};

export default LifecycleTracker;
