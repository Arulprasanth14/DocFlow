import React from 'react';
import {
  ShieldCheck,
  Database,
  Cloud,
  FileCheck,
  Cpu,
  Unlock,
  CheckCircle2,
  Lock,
  Layers,
} from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { Container } from './Container';
import { SpotlightCard } from './SpotlightCard';
import { StatusChip } from './StatusChip';
import { TornDivider } from './TornDivider';
import { IsoShieldBuilding } from '../illustrations';

export const Trust: React.FC = () => {
  const getPillarIcon = (idx: number) => {
    switch (idx) {
      case 0:
        return <ShieldCheck className="w-5 h-5 text-primary" />;
      case 1:
        return <Database className="w-5 h-5 text-accent-cyan" />;
      case 2:
        return <Cloud className="w-5 h-5 text-accent-violet" />;
      case 3:
        return <FileCheck className="w-5 h-5 text-success" />;
      case 4:
        return <Cpu className="w-5 h-5 text-warning" />;
      case 5:
        return <Unlock className="w-5 h-5 text-primary" />;
      default:
        return <ShieldCheck className="w-5 h-5 text-primary" />;
    }
  };

  return (
    <section id="security" aria-labelledby="security-heading" className="relative lp-section-rhythm bg-background overflow-x-clip">
      <Container data-qa="container">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-2 mb-3">
            <span className="lp-eyebrow px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary">
              {LANDING_CONTENT.trust.eyebrow}
            </span>
          </div>
          <h2 id="security-heading" className="lp-h2 text-foreground mt-2">
            {LANDING_CONTENT.trust.heading}
          </h2>
          <p className="lp-body text-muted-foreground mt-4">
            Transparent about what is live and what is coming. No exaggerated claims — just reliable, inspectable architecture.
          </p>
        </div>

        {/* 6 Architecture Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {LANDING_CONTENT.trust.pillars.map((pillar, idx) => (
            <SpotlightCard
              key={idx}
              data-qa="card"
              className="p-6 rounded-2xl border border-border bg-card/80 hover:border-primary/40 transition-all flex flex-col justify-between shadow-xs"
            >
              <div>
                <div className="w-11 h-11 rounded-xl bg-secondary flex items-center justify-center mb-4">
                  {getPillarIcon(idx)}
                </div>
                <div className="flex items-center justify-between mb-2">
                  <h3 className="text-base font-bold text-foreground">{pillar.title}</h3>
                  {idx === 3 && <StatusChip status="Live" size="sm" />}
                  {idx === 4 && <StatusChip status="Coming soon" size="sm" />}
                </div>
                <p className="text-[0.8125rem] sm:text-[0.9375rem] text-muted-foreground leading-relaxed">
                  {pillar.desc}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-border/60 flex items-center gap-1.5 text-[0.8125rem] font-semibold text-success">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Verified Architecture Primitive</span>
              </div>
            </SpotlightCard>
          ))}
        </div>

        {/* System Architecture Blueprint Showcase */}
        <div
          data-cursor="card" data-qa="card"
          className="rounded-3xl border border-primary/20 bg-card/90 backdrop-blur-xl p-6 sm:p-8 shadow-xl"
        >
          <div className="flex flex-col lg:flex-row items-center justify-between gap-8">
            <div className="space-y-4 max-w-xl">
              <div className="flex items-center gap-4">
                <div className="hidden sm:block shrink-0 -my-3">
                  <IsoShieldBuilding size={110} animated={true} />
                </div>
                <div>
                  <span className="lp-eyebrow px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary">
                    Transparent Systems
                  </span>
                  <h3 className="text-2xl font-bold text-foreground mt-2">
                    Engineered with resilient, decoupled primitives.
                  </h3>
                </div>
              </div>
              <p className="text-[0.8125rem] sm:text-[0.9375rem] text-muted-foreground leading-relaxed">
                Core document workflows run on an ACID transaction engine with verifiable audit tracking. The AI assistant functions as an independent, asynchronous companion — ensuring your team continues drafting, routing, and approving without disruption even during external network latency.
              </p>

              <div className="flex flex-wrap gap-2 pt-2">
                <span className="px-3 py-1 rounded-lg bg-secondary text-foreground text-[0.8125rem] font-medium">
                  PostgreSQL 16
                </span>
                <span className="px-3 py-1 rounded-lg bg-secondary text-foreground text-[0.8125rem] font-medium">
                  Firebase Auth
                </span>
                <span className="px-3 py-1 rounded-lg bg-secondary text-foreground text-[0.8125rem] font-medium">
                  S3 Storage Checksums
                </span>
                <span className="px-3 py-1 rounded-lg bg-secondary text-foreground text-[0.8125rem] font-medium">
                  ACID Audit Engine
                </span>
              </div>
            </div>

            {/* Architecture Dataflow Visualizer */}
            <div className="w-full lg:w-auto flex-1 max-w-md p-6 rounded-2xl bg-background border border-border text-[0.8125rem] space-y-3.5 shadow-sm">
              <div className="flex items-center justify-between pb-3 border-b border-border text-[0.8125rem] text-muted-foreground">
                <span className="font-bold tracking-wider">SYSTEM DATAFLOW</span>
                <span className="text-success font-semibold flex items-center gap-1">
                  <Lock className="w-3.5 h-3.5" /> Tenant Isolated
                </span>
              </div>

              {/* Step 1: Client to Auth */}
              <div className="flex items-center gap-2.5 p-3 rounded-xl bg-secondary/50">
                <Layers className="w-4 h-4 text-primary shrink-0" />
                <div className="text-[0.8125rem]">
                  <strong className="text-foreground">Client App</strong> → Verified session token
                </div>
              </div>

              {/* Step 2: RLS Query */}
              <div className="flex items-center gap-2.5 p-3 rounded-xl bg-secondary/50">
                <Database className="w-4 h-4 text-accent-cyan shrink-0" />
                <div className="text-[0.8125rem]">
                  <strong className="text-foreground">PostgreSQL</strong> → Row-level tenant isolation
                </div>
              </div>

              {/* Step 3: S3 & Hash */}
              <div className="flex items-center gap-2.5 p-3 rounded-xl bg-secondary/50">
                <Cloud className="w-4 h-4 text-accent-violet shrink-0" />
                <div className="text-[0.8125rem]">
                  <strong className="text-foreground">S3 Storage</strong> → Binary checksum verification
                </div>
              </div>

              {/* Step 4: Digital Signatures */}
              <div className="flex items-center gap-2.5 p-3 rounded-xl bg-secondary/50">
                <ShieldCheck className="w-4 h-4 text-success shrink-0" />
                <div className="text-[0.8125rem]">
                  <strong className="text-foreground">Audit Engine</strong> → Verifiable audit record
                </div>
              </div>
            </div>
          </div>
        </div>
      </Container>

      {/* Torn Edge Transition to FAQ section */}
      <div className="mt-16 sm:mt-24">
        <TornDivider fillToken="var(--lp-section-deep)" direction="bottom" seed="A" />
      </div>
    </section>
  );
};

export default Trust;
