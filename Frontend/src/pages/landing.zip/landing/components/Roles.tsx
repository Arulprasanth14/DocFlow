import React, { useState } from 'react';
import {
  CheckCircle2,
  XCircle,
  Network,
  GitBranch,
  ShieldAlert,
  UserCheck,
  Building,
  User,
  Users,
  Shield,
  GraduationCap,
  ArrowRight,
} from 'lucide-react';
import { LANDING_CONTENT, type RoleDetail } from '../content';
import { Container } from './Container';
import { Docky, type DockyAccessory, type DockyExpression } from './Docky';
import { TornDivider } from './TornDivider';

export const Roles: React.FC = () => {
  const [selectedRoleId, setSelectedRoleId] = useState<string>('employee');
  const roles = LANDING_CONTENT.roles.items;

  const currentRole = roles.find((r) => r.id === selectedRoleId) || roles[0];

  const getRoleDockyConfig = (costume: RoleDetail['costume']): { accessory: DockyAccessory; expression: DockyExpression } => {
    switch (costume) {
      case 'employee':
        return { accessory: 'pen', expression: 'thinking' };
      case 'manager':
        return { accessory: 'glasses', expression: 'thinking' };
      case 'deptAdmin':
        return { accessory: 'stamp', expression: 'happy' };
      case 'hr':
        return { accessory: 'badge', expression: 'happy' };
      case 'admin':
        return { accessory: 'key', expression: 'celebrating' };
      case 'intern':
        return { accessory: 'cap', expression: 'neutral' };
      default:
        return { accessory: 'none', expression: 'neutral' };
    }
  };

  const getRoleIcon = (id: string) => {
    switch (id) {
      case 'employee':
        return <User size={15} />;
      case 'manager':
        return <UserCheck size={15} />;
      case 'deptAdmin':
        return <Building size={15} />;
      case 'hr':
        return <Users size={15} />;
      case 'admin':
        return <Shield size={15} />;
      case 'intern':
        return <GraduationCap size={15} />;
      default:
        return <User size={15} />;
    }
  };

  const dockyConfig = getRoleDockyConfig(currentRole.costume);

  return (
    <section id="roles" aria-labelledby="roles-heading" className="relative py-20 sm:py-28 lp-section-deep">
      <Container wide>
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="lp-eyebrow text-primary px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/20 inline-block mb-3">
            {LANDING_CONTENT.roles.eyebrow}
          </span>
          <h2 id="roles-heading" className="lp-h2 text-foreground tracking-tight leading-tight">
            {LANDING_CONTENT.roles.heading}
          </h2>
          <p className="lp-body text-muted-foreground mt-4 leading-relaxed max-w-2xl mx-auto">
            {LANDING_CONTENT.roles.subheading}
          </p>
        </div>

        {/* ── Segmented Role Selector Tabs (Single Row, No Squeeze) ── */}
        <div className="flex items-center justify-start sm:justify-center gap-2 overflow-x-auto pb-4 max-w-5xl mx-auto mb-10 no-scrollbar select-none">
          {roles.map((r) => {
            const isSelected = r.id === selectedRoleId;
            return (
              <button
                key={r.id}
                type="button"
                onClick={() => setSelectedRoleId(r.id)}
                data-cursor="link"
                aria-pressed={isSelected}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-[0.9375rem] font-semibold transition-all duration-300 whitespace-nowrap cursor-pointer border active:scale-[0.97] ${
                  isSelected
                    ? 'bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/20 scale-102'
                    : 'bg-card/70 border-border text-muted-foreground hover:text-foreground hover:bg-card'
                }`}
              >
                {getRoleIcon(r.id)}
                <span>{r.title.split('/')[0].trim()}</span>
              </button>
            );
          })}
        </div>

        {/* ── Main Role Panel: Docky Costume + Can / Cannot Columns ── */}
        <div
          data-qa="card"
          className="lp-card lp-glass p-6 sm:p-10 rounded-3xl border border-border shadow-xl mb-14"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left: Role Docky Costume & Description (4 cols) */}
            <div className="lg:col-span-4 flex flex-col items-center text-center lg:items-start lg:text-left space-y-4 lg:pr-6 lg:border-r border-border">
              <div className="w-full flex justify-center lg:justify-start">
                <Docky
                  size={160}
                  expression={dockyConfig.expression}
                  accessory={dockyConfig.accessory}
                  animated={true}
                />
              </div>

              <div>
                <span className="text-[0.8125rem] font-bold uppercase tracking-wider text-primary px-2.5 py-0.5 rounded-full bg-primary/10 border border-primary/20 inline-block mb-2">
                  {currentRole.badge}
                </span>
                <h3 className="font-heading font-extrabold text-2xl text-foreground">
                  {currentRole.title}
                </h3>
                <p className="lp-body text-muted-foreground mt-2">
                  {currentRole.tagline}
                </p>
              </div>
            </div>

            {/* Right: Can Do / Cannot Do Columns (8 cols) */}
            <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Can Do Column */}
              <div className="space-y-4 p-5 rounded-2xl bg-success/5 border border-success/20">
                <div className="flex items-center gap-2 text-success font-heading font-bold text-[0.9375rem] uppercase tracking-wide">
                  <CheckCircle2 size={16} />
                  <span>Authorized Capabilities</span>
                </div>

                <ul className="space-y-3">
                  {currentRole.can.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-[0.9375rem] text-foreground leading-relaxed">
                      <span className="w-1.5 h-1.5 rounded-full bg-success shrink-0 mt-2" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Cannot Do Column */}
              <div className="space-y-4 p-5 rounded-2xl bg-destructive/5 border border-destructive/15">
                <div className="flex items-center gap-2 text-destructive font-heading font-bold text-[0.9375rem] uppercase tracking-wide">
                  <XCircle size={16} />
                  <span>Bounded Restrictions</span>
                </div>

                <ul className="space-y-3">
                  {currentRole.cannot.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2.5 text-[0.9375rem] text-muted-foreground leading-relaxed">
                      <span className="w-1.5 h-1.5 rounded-full bg-destructive/60 shrink-0 mt-2" />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>

        {/* ── ROUTING COMPARISON: Peer-to-Peer vs. Fixed Hierarchy ── */}
        <div className="space-y-6">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-[0.8125rem] font-bold uppercase tracking-wider text-primary">
              {LANDING_CONTENT.roles.routingConcept.eyebrow}
            </span>
            <h3 className="font-heading font-extrabold text-xl sm:text-2xl text-foreground mt-1">
              {LANDING_CONTENT.roles.routingConcept.title}
            </h3>
            <p className="lp-body text-muted-foreground mt-3">
              {LANDING_CONTENT.roles.routingConcept.description}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8 items-stretch">
            {/* Left Card: DocFlow Peer-to-Peer Graph */}
            <div data-qa="card" data-cursor="card" className="lp-card lp-glass lp-elev-2 p-6 sm:p-8 rounded-3xl flex flex-col justify-between hover:-translate-y-1 transition-transform duration-300">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2 text-primary font-heading font-bold text-base">
                    <Network size={18} />
                    <span>DocFlow: Dynamic Peer-to-Peer</span>
                  </div>
                  <span className="text-[0.8125rem] font-bold px-2 py-0.5 rounded-full bg-success/10 text-success border border-success/20">
                    Adaptive Flow
                  </span>
                </div>

                <p className="lp-body text-muted-foreground mb-6">
                  Documents move directly person to person across departments based on step rules, dollar thresholds, and review context.
                </p>

                {/* 6-Node Graph Visual */}
                <div className="p-5 rounded-2xl bg-secondary/40 border border-border flex flex-col gap-3 text-[0.8125rem]">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-lg bg-card border border-border font-bold text-foreground">
                      Submitter (Priya)
                    </span>
                    <ArrowRight size={14} className="text-primary" />
                    <span className="px-2.5 py-1 rounded-lg bg-primary text-primary-foreground font-bold shadow-xs">
                      Peer Reviewer (Ananya)
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-lg bg-card border border-border font-bold text-foreground">
                      Dept Head (Karthik)
                    </span>
                    <ArrowRight size={14} className="text-primary" />
                    <span className="px-2.5 py-1 rounded-lg bg-card border border-border font-bold text-foreground">
                      Finance Lead (Suresh)
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-lg bg-success/10 text-success border border-success/30 font-bold">
                      Legal Signer
                    </span>
                    <ArrowRight size={14} className="text-success" />
                    <span className="px-2.5 py-1 rounded-lg bg-success/20 text-success ring-1 ring-success/40 font-bold">
                      Finalized Archive
                    </span>
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-border text-[0.8125rem] text-success font-semibold flex items-center gap-1.5">
                <CheckCircle2 size={14} />
                <span>Eliminates unnecessary executive bottlenecks</span>
              </div>
            </div>

            {/* Right Card: Fixed Hierarchy Ladder */}
            <div data-qa="card" data-cursor="card" className="lp-card lp-glass p-6 sm:p-8 rounded-3xl opacity-80 flex flex-col justify-between hover:opacity-100 transition-opacity duration-300">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2 text-muted-foreground font-heading font-bold text-base">
                    <GitBranch size={18} />
                    <span>Traditional Tools: Rigid Ladder</span>
                  </div>
                  <span className="text-[0.8125rem] font-medium px-2 py-0.5 rounded-full bg-muted text-muted-foreground">
                    Fixed Ladder
                  </span>
                </div>

                <p className="lp-body text-muted-foreground mb-6">
                  Forces every simple requisition up an inflexible corporate hierarchy, stalling whenever an absent manager fails to sign off.
                </p>

                {/* Vertical Staircase Visual */}
                <div className="p-5 rounded-2xl bg-muted/40 border border-border/60 space-y-2 text-[0.8125rem] text-muted-foreground">
                  <div className="p-2 rounded bg-card/60 text-center">1. Employee Submits</div>
                  <div className="p-2 rounded bg-card/60 text-center ml-4 border-l-2 border-destructive/50">2. Team Lead → Pending 3 days</div>
                  <div className="p-2 rounded bg-card/60 text-center ml-8 border-l-2 border-destructive/50">3. Manager → Away on vacation</div>
                  <div className="p-2 rounded bg-card/60 text-center ml-12 opacity-50">4. VP Approval → Stalled silently</div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-border text-[0.8125rem] text-destructive font-semibold flex items-center gap-1.5">
                <ShieldAlert size={14} />
                <span>Single point of failure stalls requests for weeks</span>
              </div>
            </div>
          </div>
        </div>
      </Container>

      {/* Torn Edge Transition to Approvals Queue */}
      <div className="mt-16">
        <TornDivider seed="B" direction="bottom" fillToken="var(--background)" />
      </div>
    </section>
  );
};

export default Roles;
