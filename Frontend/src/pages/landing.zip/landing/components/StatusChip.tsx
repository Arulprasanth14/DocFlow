import React from 'react';
import type { FeatureStatus } from '../content';

interface StatusChipProps {
  status: FeatureStatus;
  className?: string;
  size?: 'sm' | 'md';
}

export const StatusChip: React.FC<StatusChipProps> = ({
  status,
  className = '',
  size = 'md',
}) => {
  const styles: Record<FeatureStatus, string> = {
    Live: 'bg-success/10 text-success border-success/25',
    'In progress': 'bg-warning/10 text-warning border-warning/25',
    'Coming soon': 'bg-chart-3/10 text-chart-3 border-chart-3/25',
  };

  const dotColors: Record<FeatureStatus, string> = {
    Live: 'bg-success',
    'In progress': 'bg-warning',
    'Coming soon': 'bg-chart-3',
  };

  const sizeClasses = size === 'sm' ? 'px-2 py-0.5 text-[0.8125rem]' : 'px-2.5 py-1 text-[0.8125rem]';

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-semibold rounded-full border ${styles[status]} ${sizeClasses} ${className}`}
    >
      <span className={`w-1.5 h-1.5 rounded-full ${dotColors[status]} animate-pulse`} />
      {status}
    </span>
  );
};

export default StatusChip;

