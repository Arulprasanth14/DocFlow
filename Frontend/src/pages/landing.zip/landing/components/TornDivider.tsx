import React, { useEffect, useId, useMemo, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { generateTornEdge } from '../lib/noise';
import { prefersReducedMotion } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger);

export type TornSeed = 'A' | 'B' | 'C' | number;
export type TornDirection = 'top' | 'bottom';

export interface TornDividerProps {
  /** Three hand-tuned variants so repeated edges never look stamped. */
  seed?: TornSeed;
  direction?: TornDirection;
  /** Colour of the section the edge reveals. Any CSS colour or var(). */
  fillToken?: string;
  flip?: boolean;
  className?: string;
  /** Scroll-scrubbed reveal. Use at most one per viewport. */
  animate?: boolean;
}

const SEED_MAP: Record<'A' | 'B' | 'C', number> = {
  A: 104729,
  B: 224737,
  C: 384751,
};

/**
 * TornDivider — procedurally generated torn paper edge.
 *
 * Layers: section silhouette, a 3-5px lighter paper-fibre band along the rip,
 * a soft drop shadow in light mode and a faint rim light in dark mode, plus a
 * micro-turbulence pulp texture. Never a thin grey line.
 *
 * IMPORTANT: every colour is applied through the `style` prop, not through SVG
 * presentation attributes. Chrome does not resolve var() inside presentation
 * attributes, so `fill="var(--x)"` is dropped and the shape falls back to
 * black — which is how a dark band appears in light mode.
 */
export const TornDivider: React.FC<TornDividerProps> = ({
  seed = 'A',
  direction = 'bottom',
  fillToken = 'var(--background)',
  flip = false,
  className = '',
  animate = false,
}) => {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const wrapRef = useRef<HTMLDivElement>(null);
  const bandRef = useRef<SVGGElement>(null);

  const numericSeed = typeof seed === 'number' ? seed : SEED_MAP[seed] ?? SEED_MAP.A;

  const { silhouetteD, fiberBandD } = useMemo(
    () => generateTornEdge(1440, 26, 11, numericSeed, 160, 56),
    [numericSeed]
  );

  useEffect(() => {
    if (!animate || prefersReducedMotion() || !wrapRef.current || !bandRef.current) return;

    const ctx = gsap.context(() => {
      gsap.fromTo(
        bandRef.current,
        { yPercent: direction === 'top' ? -12 : 12, opacity: 0.4 },
        {
          yPercent: 0,
          opacity: 1,
          ease: 'none',
          scrollTrigger: {
            trigger: wrapRef.current,
            start: 'top bottom',
            end: 'bottom center',
            scrub: 0.6,
          },
        }
      );
    }, wrapRef);

    return () => ctx.revert();
  }, [animate, direction]);

  const transform = [direction === 'top' ? 'scaleY(-1)' : '', flip ? 'scaleX(-1)' : '']
    .filter(Boolean)
    .join(' ');

  return (
    <div
      ref={wrapRef}
      className={`relative w-full overflow-hidden leading-none pointer-events-none select-none ${className}`}
      aria-hidden="true"
      style={{ transform: transform || undefined, transformOrigin: 'center center' }}
    >
      <svg
        viewBox="0 0 1440 56"
        preserveAspectRatio="none"
        className="block w-full h-9 sm:h-11 lg:h-14"
      >
        <defs>
          {/* Paper pulp micro-texture */}
          <filter id={`pulp-${uid}`} x="0%" y="0%" width="100%" height="100%">
            <feTurbulence type="fractalNoise" baseFrequency="0.65" numOctaves="3" result="n" />
            <feColorMatrix in="n" type="saturate" values="0" result="g" />
            <feBlend in="SourceGraphic" in2="g" mode="multiply" />
          </filter>

          {/* Soft directional shadow (light) / faint rim light (dark) */}
          <filter id={`edge-${uid}`} x="-5%" y="-40%" width="110%" height="240%">
            <feDropShadow
              dx="0"
              dy="3"
              stdDeviation="4"
              style={{ floodColor: 'var(--lp-torn-shadow)', floodOpacity: 1 }}
            />
          </filter>
        </defs>

        <g ref={bandRef}>
          {/* Rim light along the rip — dark mode only (transparent in light) */}
          <path
            d={fiberBandD}
            style={{ fill: 'var(--lp-torn-rim)' }}
            transform="translate(0,-1.5)"
          />

          {/* Exposed paper fibre band: warm cream in light, lit slate in dark */}
          <path
            d={fiberBandD}
            style={{ fill: 'var(--lp-paper-fiber)' }}
            opacity="0.95"
            filter={`url(#pulp-${uid})`}
          />

          {/* Hairline along the clean break */}
          <path
            d={fiberBandD}
            style={{ fill: 'none', stroke: 'var(--lp-paper-edge)', strokeWidth: 0.75 }}
            opacity="0.5"
          />

          {/* The revealed section */}
          <path d={silhouetteD} style={{ fill: fillToken }} filter={`url(#edge-${uid})`} />
        </g>
      </svg>
    </div>
  );
};

export default TornDivider;
