import React, { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  MessageSquareWarning,
  HelpCircle,
  FileQuestion,
  Clock,
  Sparkles,
  GitFork,
  FileSpreadsheet,
} from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { Container } from './Container';
import { Docky } from './Docky';
import { TornDivider } from './TornDivider';
import { FitStage } from './FitStage';
import { layoutStore } from '../hooks/useLayoutMode';
import { usePlaceInRect } from '../hooks/usePlaceInRect';
import { prefersReducedMotion } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger);

interface ChaosItemDef {
  id: string;
  width: number;
  height: number;
  preferredQuadrant: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'mid-left' | 'mid-right';
  bg: string;
  border: string;
  text: string;
  subtext: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  accentColor: string;
}

const CHAOS_ITEMS_RAW: ChaosItemDef[] = [
  {
    id: 'c1',
    width: 258,
    height: 96,
    preferredQuadrant: 'top-left',
    bg: 'bg-card',
    border: 'border-border',
    text: '“Who has the latest version?”',
    subtext: 'Finance team • Thread stalled',
    icon: HelpCircle,
    accentColor: 'text-warning',
  },
  {
    id: 'c2',
    width: 258,
    height: 96,
    preferredQuadrant: 'mid-left',
    bg: 'bg-warning/10',
    border: 'border-warning/30',
    text: 'Note: Waiting on Karthik’s sign-off',
    subtext: 'Sticky memo attached 5 days ago',
    icon: Clock,
    accentColor: 'text-warning',
  },
  {
    id: 'c3',
    width: 258,
    height: 96,
    preferredQuadrant: 'bottom-left',
    bg: 'bg-card',
    border: 'border-border',
    text: 'Re: Re: Leave approval thread',
    subtext: '14 unread replies in mailbox',
    icon: MessageSquareWarning,
    accentColor: 'text-destructive',
  },
  {
    id: 'c4',
    width: 258,
    height: 96,
    preferredQuadrant: 'top-left',
    bg: 'bg-card',
    border: 'border-border',
    text: 'Contract_v2_final_FINAL_v3.pdf',
    subtext: '3 conflicting file versions found',
    icon: FileQuestion,
    accentColor: 'text-primary',
  },
  {
    id: 'c5',
    width: 258,
    height: 96,
    preferredQuadrant: 'top-right',
    bg: 'bg-card',
    border: 'border-border',
    text: '“Still pending since last week...”',
    subtext: 'Project lead • Chasing approver',
    icon: Clock,
    accentColor: 'text-warning',
  },
  {
    id: 'c6',
    width: 258,
    height: 96,
    preferredQuadrant: 'mid-right',
    bg: 'bg-card',
    border: 'border-border',
    text: '“Where is the signed copy?”',
    subtext: 'Legal review • Scattered files',
    icon: FileQuestion,
    accentColor: 'text-accent-violet',
  },
  {
    id: 'c7',
    width: 258,
    height: 96,
    preferredQuadrant: 'bottom-right',
    bg: 'bg-card',
    border: 'border-border',
    text: '“Can you resend that attachment?”',
    subtext: 'Operations • Lost in chat channel',
    icon: MessageSquareWarning,
    accentColor: 'text-primary',
  },
  {
    id: 'c8',
    width: 258,
    height: 96,
    preferredQuadrant: 'bottom-right',
    bg: 'bg-destructive/10',
    border: 'border-destructive/30',
    text: 'Stalled in Department Queue',
    subtext: 'Approver on leave • Ladder locked',
    icon: MessageSquareWarning,
    accentColor: 'text-destructive',
  },
];

export const Problem: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const pinWrapperRef = useRef<HTMLDivElement>(null);
  const chaosContainerRef = useRef<HTMLDivElement>(null);
  const cleanCardRef = useRef<HTMLDivElement>(null);
  const dockyWorriedRef = useRef<HTMLDivElement>(null);
  const dockyRelievedRef = useRef<HTMLDivElement>(null);

  // Collision-free coordinates, recalculated from the real arena size by a
  // ResizeObserver (a one-off useMemo against a hardcoded rect cannot hold at
  // every viewport). The mascot's box is reserved as a fraction of the arena.
  const {
    containerRef: arenaRef,
    items: chaosPositions,
    strategy: chaosStrategy,
  } = usePlaceInRect(CHAOS_ITEMS_RAW, {
    seed: 88,
    padding: 16,
    gap: 16,
    avoidRatio: [{ x: 0.385, y: 0.26, width: 0.23, height: 0.48 }],
  });

  const placedChaosItems = CHAOS_ITEMS_RAW.map((item, idx) => {
    const pos = chaosPositions[item.id];
    return {
      ...item,
      x: pos?.x ?? (idx % 2) * 300 + 24,
      y: pos?.y ?? Math.floor(idx / 2) * 100 + 24,
      placed: Boolean(pos),
    };
  });

  useEffect(() => {
    if (prefersReducedMotion()) return;

    // Same gate as FitStage: only the 'wide' tier may pin a scene.
    if (!layoutStore.measure().canPin) return;

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          pin: pinWrapperRef.current,
          start: 'top top',
          end: '+=130%',
          scrub: 0.7,
          anticipatePin: 1,
        },
      });

      // 1. Chaos items converge to center and fade out
      const chaosItems = chaosContainerRef.current?.querySelectorAll('[data-chaos-item]');
      if (chaosItems && chaosItems.length > 0) {
        tl.to(
          chaosItems,
          {
            x: (i) => (i < 4 ? 120 : -120),
            y: (i) => (i % 2 === 0 ? 80 : -80),
            scale: 0.45,
            opacity: 0,
            duration: 0.55,
            ease: 'power2.inOut',
          },
          0
        );
      }

      // 2. Docky transitions from worried to relieved
      if (dockyWorriedRef.current && dockyRelievedRef.current) {
        tl.to(dockyWorriedRef.current, { opacity: 0, scale: 0.85, duration: 0.4 }, 0.2);
        tl.to(dockyRelievedRef.current, { opacity: 1, scale: 1, duration: 0.4 }, 0.35);
      }

      // 3. One Flow card materializes and expands cleanly (strictly power3.out per motion rules)
      if (cleanCardRef.current) {
        tl.fromTo(
          cleanCardRef.current,
          { scale: 0.65, opacity: 0, y: 30 },
          { scale: 1, opacity: 1, y: 0, duration: 0.5, ease: 'power3.out' },
          0.3
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section id="problem" aria-labelledby="problem-heading" ref={sectionRef} className="relative bg-background">
      {/* ── Pinned Desktop Scrollytelling Stage (Unpinned on Mobile) ── */}
      <div ref={pinWrapperRef} className="relative w-full flex flex-col justify-start">
        <FitStage designWidth={1200} designHeight={640} align="top">
          <Container wide>
            {/* Section Header */}
            <div className="text-center max-w-3xl mx-auto mb-8">
              <span className="lp-eyebrow text-primary px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/20 inline-block mb-2">
                {LANDING_CONTENT.problem.eyebrow}
              </span>
              <h2 id="problem-heading" className="lp-h2 text-foreground tracking-tight leading-tight">
                {LANDING_CONTENT.problem.heading}
              </h2>
              <p className="lp-body text-muted-foreground mt-3 max-w-2xl mx-auto">
                {LANDING_CONTENT.problem.subheading}
              </p>
            </div>

            {/* Interactive Chaos-to-Order Desktop Arena */}
            <div
              ref={arenaRef}
              data-chaos-strategy={chaosStrategy}
              className="hidden lg:block relative w-full h-[520px] rounded-3xl border border-border bg-secondary/25 backdrop-blur-md"
            >
              {/* Chaos Layer (8 non-overlapping items, placed at runtime) */}
              <div ref={chaosContainerRef} className="absolute inset-0">
                {placedChaosItems.map((coord) => {
                  const Icon = coord.icon;
                  return (
                    <div
                      key={coord.id}
                      data-chaos-item
                      data-place-id={coord.id}
                      data-qa-nooverlap={coord.id}
                      data-cursor="card"
                      className={`absolute p-3.5 rounded-2xl lp-glass lp-elev-2 hover:-translate-y-1 transition-transform duration-300 w-[260px] select-none`}
                      style={{
                        left: coord.x,
                        top: coord.y,
                        visibility: coord.placed ? 'visible' : 'hidden',
                      }}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <Icon size={15} className={coord.accentColor} />
                        <span className="font-heading font-bold text-foreground leading-snug text-[0.875rem]">
                          {coord.text}
                        </span>
                      </div>
                      <p className="text-muted-foreground leading-normal mt-1 text-[0.8125rem]">
                        {coord.subtext}
                      </p>
                    </div>
                  );
                })}
              </div>

              {/* Center: Docky Expressions (Worried & Relieved) */}
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none">
                {/* Worried Docky (Initial State) */}
                <div ref={dockyWorriedRef} className="transition-transform">
                  <Docky size={170} expression="worried" accessory="none" animated={true} />
                </div>

                {/* Relieved Docky (Revealed on Scrub) */}
                <div ref={dockyRelievedRef} className="absolute inset-0 opacity-0 transition-transform">
                  <Docky size={170} expression="happy" accessory="badge" animated={true} />
                </div>
              </div>

              {/* Resolved "One Flow" Glass Card (Centered) */}
              <div
                ref={cleanCardRef}
                className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-30 opacity-0 pointer-events-none w-full max-w-md p-6 rounded-2xl lp-glass border border-primary/40 shadow-2xl text-center space-y-3"
              >
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-success/10 text-success border border-success/20 font-bold text-[0.8125rem]">
                  <Sparkles size={13} />
                  <span>One Unified Flow</span>
                </div>
                <h3 className="font-heading font-extrabold text-xl text-foreground">
                  All requests routed in one place.
                </h3>
                <p className="text-muted-foreground leading-relaxed text-[0.9375rem]">
                  Replaces lost attachments, WhatsApp forwards, printed approval slips, and spreadsheet trackers with one role-aware platform.
                </p>
              </div>
            </div>

            {/* Tablet & mobile: the SAME eight items as the desktop arena,
                stacked. Nothing is dropped just because the scene is unpinned. */}
            <div className="lg:hidden grid grid-cols-1 md:grid-cols-2 gap-3">
              {CHAOS_ITEMS_RAW.map((item) => (
                <div
                  key={item.id}
                  className="lp-glass p-4 rounded-xl flex items-start gap-3"
                >
                  <span className="mt-0.5 shrink-0">
                    <item.icon size={17} className={item.accentColor} />
                  </span>
                  <span className="min-w-0">
                    <span className="block font-heading font-semibold text-foreground leading-snug text-[0.9375rem]">
                      {item.text}
                    </span>
                    <span className="block text-muted-foreground mt-1 text-[0.8125rem]">
                      {item.subtext}
                    </span>
                  </span>
                </div>
              ))}
            </div>
          </Container>
        </FitStage>
      </div>

      {/* ── Normal Flow: 4 Pain Point Cards (2x2 Grid) ── */}
      <div className="pb-16 sm:pb-24">
        <Container>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8">
            {/* Card 1 */}
            <div
              data-qa="card"
              data-cursor="card"
              className="lp-card lp-glass flex flex-col justify-between group hover:-translate-y-1.5 transition-transform duration-300"
            >
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-destructive/10 text-destructive flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
                  <MessageSquareWarning size={18} />
                </div>
                <h3 className="font-heading font-bold text-lg text-foreground">
                  Lost in Email & Chat Sprawl
                </h3>
                <p className="lp-body text-muted-foreground">
                  Documents get lost in endless reply chains and team channels. Approvals stall silently because nobody knows whose desk a request is sitting on.
                </p>
              </div>
              <div className="pt-4 border-t border-border/70 font-semibold text-destructive flex text-[0.8125rem] items-center gap-1.5">
                <span>Problem: Lack of ownership visibility</span>
              </div>
            </div>

            {/* Card 2 */}
            <div
              data-qa="card"
              data-cursor="card"
              className="lp-card lp-glass flex flex-col justify-between group hover:-translate-y-1.5 transition-transform duration-300"
            >
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-warning/10 text-warning flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
                  <FileQuestion size={18} />
                </div>
                <h3 className="font-heading font-bold text-lg text-foreground">
                  “Who Has the Latest Version?”
                </h3>
                <p className="lp-body text-muted-foreground">
                  Conflicting revisions scatter across hard drives. Approvers unknowingly sign outdated terms, creating duplicate work and legal risk.
                </p>
              </div>
              <div className="pt-4 border-t border-border/70 font-semibold text-warning flex text-[0.8125rem] items-center gap-1.5">
                <span>Problem: Desynchronized local copies</span>
              </div>
            </div>

            {/* Card 3 */}
            <div
              data-qa="card"
              data-cursor="card"
              className="lp-card lp-glass flex flex-col justify-between group hover:-translate-y-1.5 transition-transform duration-300"
            >
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
                  <GitFork size={18} />
                </div>
                <h3 className="font-heading font-bold text-lg text-foreground">
                  Rigid Hierarchy Ladders
                </h3>
                <p className="lp-body text-muted-foreground">
                  Traditional workflow engines force every single document up an inflexible vertical chain, even when the correct decision-maker is a peer in another team.
                </p>
              </div>
              <div className="pt-4 border-t border-border/70 font-semibold text-primary flex text-[0.8125rem] items-center gap-1.5">
                <span>Problem: Inflexible organizational bottlenecks</span>
              </div>
            </div>

            {/* Card 4 */}
            <div
              data-qa="card"
              data-cursor="card"
              className="lp-card lp-glass flex flex-col justify-between group hover:-translate-y-1.5 transition-transform duration-300"
            >
              <div className="space-y-3">
                <div className="w-10 h-10 rounded-xl bg-accent-violet/10 text-accent-violet flex items-center justify-center transition-transform duration-300 group-hover:scale-110">
                  <FileSpreadsheet size={18} />
                </div>
                <h3 className="font-heading font-bold text-lg text-foreground">
                  Scattered Proof & No Reusable Templates
                </h3>
                <p className="lp-body text-muted-foreground">
                  Signed PDFs are dumped in random folders with weak audit proof. HR and finance rebuild identical forms from scratch every single time.
                </p>
              </div>
              <div className="pt-4 border-t border-border/70 font-semibold text-accent-violet flex text-[0.8125rem] items-center gap-1.5">
                <span>Problem: High friction, lost institutional context</span>
              </div>
            </div>
          </div>
        </Container>
      </div>

      {/* Torn Edge Transition to Journey Section */}
      <div className="mt-8">
        <TornDivider seed="B" direction="bottom" fillToken="var(--background)" />
      </div>
    </section>
  );
};

export default Problem;
