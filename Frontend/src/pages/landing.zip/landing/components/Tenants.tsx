import React, { useState } from 'react';
import {
  Building2,
  Lock,
  Database,
  Users,
  FileText,
  CheckCircle2,
  Layers,
  FolderLock,
  Shield,
  ArrowRightLeft,
} from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { Container } from './Container';
import { SpotlightCard } from './SpotlightCard';

import { TornDivider } from './TornDivider';
import { IsoVault } from '../illustrations';

interface TenantData {
  id: string;
  name: string;
  industry: string;
  tenantKey: string;
  memberCount: number;
  deptCount: number;
  documents: { title: string; category: string; stage: string }[];
  templates: string[];
}

const SAMPLE_TENANTS: TenantData[] = [
  {
    id: 'acme',
    name: 'Acme Health Systems',
    industry: 'Healthcare & Clinical Operations',
    tenantKey: 'tenant_acme_904',
    memberCount: 240,
    deptCount: 8,
    documents: [
      { title: 'Clinical Equipment Requisition #CE-892', category: 'Procurement', stage: 'Pending Finance' },
      { title: 'Vendor Business Associate Agreement', category: 'Legal', stage: 'Signed & Sealed' },
      { title: 'Medical Staff Credentialing Verification', category: 'Compliance', stage: 'Approved' },
    ],
    templates: ['Standard Purchase Order', 'Clinical Incident Report', 'Vendor NDA'],
  },
  {
    id: 'meridian',
    name: 'Meridian Logistics',
    industry: 'Freight & Supply Chain Operations',
    tenantKey: 'tenant_meridian_481',
    memberCount: 115,
    deptCount: 5,
    documents: [
      { title: 'Fleet Fuel Surcharge Voucher Q4', category: 'Operations', stage: 'Pending Fleet Lead' },
      { title: 'Intermodal Freight Insurance Policy', category: 'Compliance', stage: 'Under Review' },
      { title: 'Driver Per Diem Expense Claim EXP-104', category: 'Finance', stage: 'Approved' },
    ],
    templates: ['Fleet Dispatch Voucher', 'Driver Leave Request', 'Fuel Subsidy Claim'],
  },
  {
    id: 'apex',
    name: 'Apex Financial Technologies',
    industry: 'Fintech & Cloud Systems',
    tenantKey: 'tenant_apex_108',
    memberCount: 380,
    deptCount: 12,
    documents: [
      { title: 'RFC-402: Multi-Region Microservices Mesh', category: 'Engineering', stage: 'Peer Review' },
      { title: 'Cloud Infrastructure Annual Renewal', category: 'Finance', stage: 'Pending Dept Head' },
      { title: 'Senior Staff Promotion & Compensation Memo', category: 'HR', stage: 'Approved' },
    ],
    templates: ['Architecture RFC', 'Remote Equipment Requisition', 'Stock Grant Memo'],
  },
];

export const Tenants: React.FC = () => {
  const [selectedTenantId, setSelectedTenantId] = useState<string>('acme');

  const activeTenant =
    SAMPLE_TENANTS.find((t) => t.id === selectedTenantId) || SAMPLE_TENANTS[0];

  return (
    <section id="organizations" aria-labelledby="organizations-heading" className="relative lp-section-rhythm bg-background overflow-x-clip">
      <Container data-qa="container">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-2 mb-3">
            <span className="lp-eyebrow px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary">
              {LANDING_CONTENT.tenants.eyebrow}
            </span>
          </div>
          <h2 id="organizations-heading" className="lp-h2 text-foreground mt-2">
            {LANDING_CONTENT.tenants.heading}
          </h2>
          <p className="lp-body text-muted-foreground mt-4">
            {LANDING_CONTENT.tenants.subheading}
          </p>
        </div>

        {/* 3 Tenant Switcher Tabs */}
        <div className="flex flex-wrap items-center justify-center gap-3 mb-10">
          {SAMPLE_TENANTS.map((tenant) => {
            const isActive = tenant.id === activeTenant.id;
            return (
              <button
                key={tenant.id}
                type="button"
                onClick={() => setSelectedTenantId(tenant.id)}
                className={`flex items-center gap-2.5 px-4 sm:px-5 py-2.5 rounded-xl text-[0.8125rem] sm:text-[0.9375rem] font-semibold transition-all border cursor-pointer ${
                  isActive
                    ? 'bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/20 scale-102'
                    : 'bg-card text-muted-foreground border-border hover:border-primary/40 hover:text-foreground'
                }`}
              >
                <Building2 className={`w-4 h-4 ${isActive ? 'text-primary-foreground' : 'text-primary'}`} />
                <span>{tenant.name}</span>
                <span
                  className={`text-[0.8125rem] px-2 py-0.5 rounded ${
                    isActive ? 'bg-primary-foreground/20 text-primary-foreground' : 'bg-secondary text-muted-foreground'
                  }`}
                >
                  {tenant.tenantKey}
                </span>
              </button>
            );
          })}
        </div>

        {/* Partition Graphic & Workspace Sandbox */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-16">
          {/* Active Organization Workspace Display (8 cols) */}
          <div data-cursor="card" data-qa="card" className="lg:col-span-8">
            <div className="rounded-3xl border border-primary/25 bg-card/90 backdrop-blur-xl p-6 sm:p-8 shadow-xl relative overflow-hidden space-y-6">
              {/* Header Badge & Industry */}
              <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-border">
                <div className="flex items-center gap-3.5">
                  <div className="w-12 h-12 rounded-2xl bg-primary/10 border border-primary/30 flex items-center justify-center text-primary">
                    <Building2 className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-foreground flex items-center gap-2">
                      <span>{activeTenant.name}</span>
                      <span className="text-[0.8125rem] px-2.5 py-0.5 rounded-full bg-success/10 text-success border border-success/25 font-semibold">
                        Isolated Partition
                      </span>
                    </h3>
                    <p className="text-[0.8125rem] text-muted-foreground mt-0.5">{activeTenant.industry}</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-[0.8125rem] text-muted-foreground">
                  <div className="flex items-center gap-1.5">
                    <Users className="w-4 h-4 text-primary" />
                    <span>
                      <strong className="text-foreground">{activeTenant.memberCount}</strong> Members
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-accent-violet" />
                    <span>
                      <strong className="text-foreground">{activeTenant.deptCount}</strong> Departments
                    </span>
                  </div>
                </div>
              </div>

              {/* Isolated Tenant Documents */}
              <div>
                <div className="flex items-center justify-between mb-3">
                  <span className="text-[0.8125rem] font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-primary" />
                    Isolated Tenant Documents ({activeTenant.name})
                  </span>
                  <span className="text-[0.8125rem] text-muted-foreground font-semibold">sample data</span>
                </div>

                <div className="space-y-2.5">
                  {activeTenant.documents.map((doc, idx) => (
                    <div
                      key={idx}
                      className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-background/80 border border-border hover:border-primary/30 transition-all text-[0.8125rem]"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="w-7 h-7 rounded-lg bg-secondary flex items-center justify-center shrink-0">
                          <FileText className="w-3.5 h-3.5 text-foreground" />
                        </div>
                        <div className="min-w-0">
                          <p className="font-semibold text-foreground leading-snug">{doc.title}</p>
                          <span className="text-[0.8125rem] text-muted-foreground">{doc.category}</span>
                        </div>
                      </div>
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-secondary text-foreground font-medium shrink-0 self-start sm:self-auto text-[0.8125rem]">
                        <span className="w-1.5 h-1.5 rounded-full bg-primary" />
                        {doc.stage}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Private Custom Templates */}
              <div className="pt-4 border-t border-border">
                <span className="text-[0.8125rem] font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5 mb-3">
                  <FolderLock className="w-3.5 h-3.5 text-primary" />
                  Custom Tenant Templates (Scoped strictly to this organization)
                </span>
                <div className="flex flex-wrap gap-2">
                  {activeTenant.templates.map((tpl, i) => (
                    <span
                      key={i}
                      className="px-3 py-1.5 rounded-lg bg-secondary/60 border border-border text-[0.8125rem] text-foreground font-medium flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-success" />
                      {tpl}
                    </span>
                  ))}
                </div>
              </div>

              {/* Visual Partition Barrier Graphic */}
              <div className="p-4 rounded-2xl bg-primary/5 border border-primary/20 flex items-center gap-3 text-[0.8125rem] text-foreground">
                <Shield className="w-5 h-5 text-primary shrink-0" />
                <div className="space-y-0.5">
                  <span className="font-bold text-foreground">Cryptographic Tenant Partition</span>
                  <p className="text-muted-foreground text-[0.8125rem]">
                    All queries, document keys, and member profiles are scoped by tenant ID at the database boundary.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Side Panel: Docky Mascot & 3D Isometric Vault (4 cols) */}
          <div className="lg:col-span-4 space-y-6">
            <div data-cursor="card" data-qa="card" className="rounded-3xl border border-border bg-card p-6 text-center space-y-4 shadow-md overflow-hidden">
              <div className="flex justify-center -my-2">
                <IsoVault size={170} animated={true} />
              </div>
              <h4 className="font-heading font-bold text-foreground text-base">
                Multi-Tenant Partition Wall
              </h4>
              <p className="text-[0.8125rem] text-muted-foreground leading-relaxed">
                Every organization inside DocFlow is an isolated environment. Member permissions, workflow drafts, and attachments cannot be accessed across tenant boundaries.
              </p>

              {/* Partition Boundary Metrics */}
              <div className="p-3.5 rounded-xl bg-muted/40 border border-border text-[0.8125rem] space-y-2">
                <div className="flex items-center justify-between text-[0.8125rem] text-muted-foreground">
                  <span className="font-bold text-primary">TENANT A</span>
                  <ArrowRightLeft size={14} className="text-primary" />
                  <span className="font-bold text-accent-violet">TENANT B</span>
                </div>
                <div className="text-[0.8125rem] text-center text-muted-foreground">
                  Independent Database Keys & Directory Boundaries
                </div>
              </div>
            </div>

            {/* Architecture Highlights */}
            <div data-cursor="card" data-qa="card" className="rounded-3xl border border-border bg-card p-6 space-y-4 shadow-md">
              <h4 className="text-[0.8125rem] font-bold uppercase tracking-wider text-foreground flex items-center gap-2">
                <Shield className="w-4 h-4 text-primary" />
                Tenant Isolation Controls
              </h4>
              <ul className="space-y-3 text-[0.8125rem] text-muted-foreground">
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-success shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-foreground">Row-Level Security:</strong> Database queries bind automatically to the authenticated tenant context.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-success shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-foreground">Siloed File Storage:</strong> Document files are segregated with tenant-specific prefix paths.
                  </span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-success shrink-0 mt-0.5" />
                  <span>
                    <strong className="text-foreground">Role Scoping:</strong> Admin rights in one tenant convey no access to any other organization.
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* 4 Tenant Callout Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {LANDING_CONTENT.tenants.callouts.map((callout, index) => (
            <SpotlightCard
              key={index}
              data-qa="card"
              className="p-6 rounded-2xl border border-border bg-card shadow-xs"
            >
              <div className="w-9 h-9 rounded-xl bg-primary/10 border border-primary/20 flex items-center justify-center text-primary mb-3.5">
                {index === 0 && <Database className="w-4 h-4" />}
                {index === 1 && <Lock className="w-4 h-4" />}
                {index === 2 && <Users className="w-4 h-4" />}
                {index === 3 && <Layers className="w-4 h-4" />}
              </div>
              <h4 className="text-[0.9375rem] font-bold text-foreground mb-1">{callout}</h4>
              <p className="text-[0.8125rem] text-muted-foreground leading-relaxed">
                Enforced by architecture at both application and data persistence layers.
              </p>
            </SpotlightCard>
          ))}
        </div>
      </Container>

      {/* Torn Edge Transition to Comparison section */}
      <div className="mt-16 sm:mt-24">
        <TornDivider fillToken="var(--lp-section-deep)" direction="bottom" seed="B" />
      </div>
    </section>
  );
};

export default Tenants;
