import React, { useEffect, useRef, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { ContactShadows, Environment, Lightformer, Sparkles } from '@react-three/drei';
import * as THREE from 'three';
import { usePerformanceTier } from '../../hooks/usePerformanceTier';
import { useThemeTokenSnapshot } from '../../lib/tokens';
import { WavePoints } from './FlowWave';
import { PaperStack3D } from './PaperStack3D';

export interface HeroCanvasProps {
  /** Horizontal offset for the paper stack, in world units. 0 centres it. */
  subjectX?: number;
  /** Scales the whole subject group down on smaller tiers. */
  subjectScale?: number;
}

/**
 * HeroCanvas — ONE WebGL context for the whole hero.
 *
 * The flow-wave field and the paper stack used to be two separate <Canvas>
 * elements, which put three contexts on the page (with the final CTA) and paid
 * for two renderers in the same viewport. They now share one camera: the field
 * sits far back and low, the subject is offset into the right-hand column.
 *
 * Lighting is near-white by design. Tinting a light with a text token makes it
 * an almost-black light in light mode, which renders the subject as a dark
 * block on a light page. Theme colour belongs on the materials.
 */
export const HeroCanvas: React.FC<HeroCanvasProps> = ({ subjectX = 0, subjectScale = 1 }) => {
  const tokens = useThemeTokenSnapshot();
  const { isDark } = tokens;
  const { tier, dpr, particleCount } = usePerformanceTier();

  const mouseRef = useRef(new THREE.Vector2(0, 0));
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      mouseRef.current.set(
        (e.clientX / window.innerWidth) * 2 - 1,
        -((e.clientY / window.innerHeight) * 2 - 1)
      );
    };
    const onScroll = () => {
      const h = window.innerHeight || 800;
      setScrollProgress(Math.min(1, Math.max(0, (window.scrollY || 0) / h)));
    };
    window.addEventListener('pointermove', onMove, { passive: true });
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('scroll', onScroll);
    };
  }, []);

  const high = tier === 'high';

  return (
    <Canvas
      dpr={dpr}
      camera={{ position: [0, 0.9, 9], fov: 42, near: 0.1, far: 80 }}
      gl={{ antialias: true, alpha: true, powerPreference: 'high-performance' }}
      style={{ width: '100%', height: '100%', pointerEvents: 'none' }}
      data-cursor="canvas"
    >
      {/* Procedural studio environment — no CDN preset, nothing downloaded. */}
      <Environment frames={1} resolution={128}>
        {/* cool key softbox, upper left */}
        <Lightformer
          form="rect"
          intensity={isDark ? 1.6 : 3.2}
          color="#eaf4ff"
          position={[-5, 5, 4]}
          scale={[8, 8, 1]}
          target={[0, 0, 0]}
        />
        {/* warm rim, lower right */}
        <Lightformer
          form="rect"
          intensity={isDark ? 1.1 : 1.8}
          color="#fff1dd"
          position={[6, -2, 2]}
          scale={[6, 6, 1]}
          target={[0, 0, 0]}
        />
        {/* top strip */}
        <Lightformer
          form="rect"
          intensity={isDark ? 0.8 : 1.4}
          color="#ffffff"
          position={[0, 7, 0]}
          rotation={[Math.PI / 2, 0, 0]}
          scale={[12, 2, 1]}
        />
      </Environment>

      <ambientLight intensity={isDark ? 0.4 : 1.25} color="#ffffff" />
      <directionalLight position={[4, 7, 5]} intensity={isDark ? 1.4 : 2.6} color="#ffffff" />
      <directionalLight
        position={[-4, -2, -3]}
        intensity={isDark ? 1.0 : 0.8}
        color={isDark ? tokens.primary : '#DCEEFB'}
      />

      {/* Background particle field: far back and low so it reads as atmosphere */}
      <group position={[0, -3.2, -7]} scale={[1.9, 1.5, 1.9]}>
        <WavePoints particleCount={particleCount} dpr={dpr} isDark={isDark} />
      </group>

      {/* Subject: paper cascade + mascot, offset into the right column */}
      <group position={[subjectX, 0.1, 0]} scale={subjectScale}>
        <PaperStack3D isDark={isDark} mouseRef={mouseRef} scrollProgress={scrollProgress} />

        {/* Docky is NOT in the 3D scene. Per the quality gate, the procedural
            3D mascot read as toy-like (flat slab face, wrong expression), so
            the polished 2D SVG Docky is layered beside the canvas instead. */}

        <ContactShadows
          position={[0, -2.1, 0]}
          opacity={isDark ? 0.5 : 0.22}
          scale={8}
          blur={2.6}
          far={4.5}
          color={isDark ? '#020817' : tokens.primary}
        />

        {high && (
          <Sparkles
            count={26}
            scale={[5, 5, 3]}
            size={2.4}
            speed={0.3}
            opacity={isDark ? 0.8 : 0.45}
            color={tokens.primary}
          />
        )}
      </group>
    </Canvas>
  );
};

export default HeroCanvas;
