import React, { useRef, useState, useEffect } from 'react';
import { Canvas } from '@react-three/fiber';
import { ContactShadows } from '@react-three/drei';
import * as THREE from 'three';
import { FileText, CheckCircle2, ShieldCheck } from 'lucide-react';

import { usePerformanceTier } from '../../hooks/usePerformanceTier';
import { PaperStack3D } from './PaperStack3D';
import { Docky3D } from './Docky3D';
import { Docky } from '../Docky';
import { useThemeTokenSnapshot } from '../../lib/tokens';

export const HeroScene3D: React.FC = () => {
  const tokens = useThemeTokenSnapshot();
  const { isDark } = tokens;
  const { tier, dpr, isSupported, isReducedMotion } = usePerformanceTier();

  const containerRef = useRef<HTMLDivElement>(null);
  const mouseRef = useRef(new THREE.Vector2(0, 0));
  const [scrollProgress, setScrollProgress] = useState(0);
  const [hasContextError, setHasContextError] = useState(false);

  // Pointer tracking
  useEffect(() => {
    const handlePointerMove = (e: MouseEvent) => {
      if (!containerRef.current) return;
      const rect = containerRef.current.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const y = -(((e.clientY - rect.top) / rect.height) * 2 - 1);
      mouseRef.current.set(
        Math.max(-1, Math.min(1, x)),
        Math.max(-1, Math.min(1, y))
      );
    };

    window.addEventListener('pointermove', handlePointerMove, { passive: true });
    return () => window.removeEventListener('pointermove', handlePointerMove);
  }, []);

  // Scroll tracking for hero scene
  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY || 0;
      const heroH = window.innerHeight || 800;
      setScrollProgress(Math.min(1.0, Math.max(0, scrollY / heroH)));
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Fallback to CSS 3D stack + SVG mascot if unsupported or static
  if (!isSupported || isReducedMotion || tier === 'static' || hasContextError) {
    return (
      <div
        ref={containerRef}
        className="relative w-full max-w-[420px] aspect-square flex items-center justify-center transition-transform duration-300 ease-out"
        style={{
          perspective: '1200px',
          transformStyle: 'preserve-3d',
        }}
      >
        {/* CSS Paper Stack fallback */}
        <div
          className="paper-sheet absolute w-[260px] h-[340px] rounded-2xl bg-card border border-border shadow-2xl transition-transform"
          style={{
            transform: 'rotateX(52deg) rotateZ(-24deg) translateZ(-40px)',
            boxShadow: isDark ? 'var(--lp-shadow-3)' : 'var(--lp-shadow-2)',
          }}
        />
        <div
          className="paper-sheet absolute w-[260px] h-[340px] rounded-2xl bg-card border border-border shadow-2xl transition-transform"
          style={{
            transform: 'rotateX(52deg) rotateZ(-16deg) translateZ(-20px)',
          }}
        />
        <div
          className="paper-sheet absolute w-[260px] h-[340px] rounded-2xl bg-card border border-border/80 shadow-2xl transition-transform"
          style={{
            transform: 'rotateX(52deg) rotateZ(-4deg) translateZ(10px)',
          }}
        />

        {/* SVG Docky Fallback */}
        <div className="relative z-30 transition-transform duration-300 pointer-events-none">
          <Docky size={220} expression="happy" accessory="pen" animated={true} />
        </div>

        {/* Orbital Cards */}
        <OrbitalCards />
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="relative w-full max-w-[480px] lg:max-w-[540px] aspect-square flex items-center justify-center"
    >
      {/* 3D Canvas Rig */}
      <Canvas
        dpr={dpr}
        camera={{ position: [0, 0.4, 6.8], fov: 42, near: 0.1, far: 50 }}
        gl={{
          antialias: true,
          alpha: true,
          powerPreference: 'high-performance',
        }}
        onCreated={({ gl }) => {
          gl.domElement.addEventListener('webglcontextlost', (e) => {
            e.preventDefault();
            setHasContextError(true);
          });
        }}
        style={{ width: '100%', height: '100%' }}
      >
        {/* Studio lighting.
            Lights must stay near-white: tinting a light with a text token
            (foreground is #0B1B33 in light mode) makes it an almost black
            light, which renders the whole scene as a dark block on a light
            page. Theme colour belongs on the MATERIALS, which read tokens.
            Phase 2 replaces this with an Environment + Lightformer rig. */}
        <ambientLight intensity={isDark ? 0.45 : 1.15} color="#ffffff" />
        <directionalLight
          position={[4, 7, 5]}
          intensity={isDark ? 1.6 : 2.4}
          color="#ffffff"
          castShadow
          shadow-mapSize={[1024, 1024]}
        />
        {/* Cool rim, kept luminous so it lifts rather than darkens */}
        <directionalLight
          position={[-4, -3, -3]}
          intensity={isDark ? 1.1 : 0.9}
          color={isDark ? tokens.primary : '#DCEEFB'}
        />

        {/* 3D Paper Stack */}
        <PaperStack3D
          isDark={isDark}
          mouseRef={mouseRef}
          scrollProgress={scrollProgress}
        />

        {/* 3D Mascot Character */}
        <Docky3D
          isDark={isDark}
          expression="happy"
          accessory="pen"
          mouseRef={mouseRef}
        />

        {/* Soft Contact Shadow beneath paper stack */}
        <ContactShadows
          position={[0, -2.1, 0]}
          opacity={isDark ? 0.45 : 0.25}
          scale={7.5}
          blur={2.4}
          far={4}
          color={tokens.primary}
        />
      </Canvas>

      {/* 4 Orbiting HTML Glass Cards */}
      <OrbitalCards />
    </div>
  );
};

const OrbitalCards: React.FC = () => {
  return (
    <>
      {/* 1. Top-Left: Leave Request */}
      <div
        data-qa-nooverlap="hero-orbit-1"
        data-cursor="card"
        className="absolute -top-3 -left-4 sm:-left-8 z-40 hidden sm:flex items-center gap-2.5 px-3.5 py-2 rounded-xl lp-glass border border-border shadow-lg text-[0.8125rem] hover:scale-105 hover:-translate-y-1 transition-all duration-300 select-none cursor-default"
      >
        <div className="w-6 h-6 rounded-md bg-primary/15 text-primary flex items-center justify-center">
          <FileText size={13} />
        </div>
        <div>
          <div className="font-bold text-foreground text-[0.8125rem]">Leave Request</div>
          <div className="text-[0.8125rem] text-success font-medium">Priya S. • In review</div>
        </div>
      </div>

      {/* 2. Top-Right: Purchase Order */}
      <div
        data-qa-nooverlap="hero-orbit-2"
        data-cursor="card"
        className="absolute top-6 -right-4 sm:-right-8 z-40 hidden sm:flex items-center gap-2.5 px-3.5 py-2 rounded-xl lp-glass border border-border shadow-lg text-[0.8125rem] hover:scale-105 hover:-translate-y-1 transition-all duration-300 select-none cursor-default"
      >
        <div className="w-6 h-6 rounded-md bg-success/15 text-success flex items-center justify-center">
          <CheckCircle2 size={13} />
        </div>
        <div>
          <div className="font-bold text-foreground text-[0.8125rem]">PO-8921</div>
          <div className="text-[0.8125rem] text-muted-foreground font-medium">Approved by Finance</div>
        </div>
      </div>

      {/* 3. Bottom-Left: Architecture Review */}
      <div
        data-qa-nooverlap="hero-orbit-3"
        data-cursor="card"
        className="absolute -bottom-4 -left-4 sm:-left-6 z-40 hidden sm:flex items-center gap-2.5 px-3.5 py-2 rounded-xl lp-glass border border-border shadow-lg text-[0.8125rem] hover:scale-105 hover:-translate-y-1 transition-all duration-300 select-none cursor-default"
      >
        <div className="w-6 h-6 rounded-md bg-accent-violet/15 text-accent-violet flex items-center justify-center">
          <FileText size={13} />
        </div>
        <div>
          <div className="font-bold text-foreground text-[0.8125rem]">Architecture RFC</div>
          <div className="text-[0.8125rem] text-accent-violet font-medium">Peer review stage</div>
        </div>
      </div>

      {/* 4. Bottom-Right: Digital Signatures */}
      <div
        data-qa-nooverlap="hero-orbit-4"
        data-cursor="card"
        className="absolute -bottom-2 -right-4 sm:-right-6 z-40 hidden sm:flex items-center gap-2.5 px-3.5 py-2 rounded-xl lp-glass border border-border shadow-lg text-[0.8125rem] hover:scale-105 hover:-translate-y-1 transition-all duration-300 select-none cursor-default"
      >
        <div className="w-6 h-6 rounded-md bg-warning/15 text-warning flex items-center justify-center">
          <ShieldCheck size={13} />
        </div>
        <div>
          <div className="font-bold text-foreground text-[0.8125rem]">Executive Contract</div>
          <div className="text-[0.8125rem] text-warning font-medium">Signatures (Planned)</div>
        </div>
      </div>
    </>
  );
};

export default HeroScene3D;

