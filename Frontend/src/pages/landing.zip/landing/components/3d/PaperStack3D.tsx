import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useThemeTokenSnapshot } from '../../lib/tokens';

interface PaperSheetConfig {
  offsetY: number;
  rotationZ: number;
  rotationX: number;
  scale: number;
}

/* Fanned cascade: a visible spread so six sheets read as a stack of paper
   rather than one slab seen head-on. */
const SHEETS_CONFIG: PaperSheetConfig[] = [
  { offsetY: -0.44, rotationZ: -0.30, rotationX: 0.06, scale: 0.90 },
  { offsetY: -0.30, rotationZ: -0.19, rotationX: 0.05, scale: 0.93 },
  { offsetY: -0.17, rotationZ: -0.09, rotationX: 0.03, scale: 0.95 },
  { offsetY: -0.04, rotationZ: 0.02, rotationX: 0.02, scale: 0.97 },
  { offsetY: 0.10, rotationZ: 0.13, rotationX: 0.01, scale: 0.99 },
  { offsetY: 0.24, rotationZ: 0.24, rotationX: 0.00, scale: 1.0 }, // top sheet
];

interface PaperStack3DProps {
  isDark?: boolean;
  mouseRef: React.MutableRefObject<THREE.Vector2>;
  scrollProgress: number;
}

export const PaperStack3D: React.FC<PaperStack3DProps> = ({ mouseRef, scrollProgress }) => {
  const groupRef = useRef<THREE.Group>(null);
  const sheetRefs = useRef<(THREE.Mesh | null)[]>([]);
  const tokens = useThemeTokenSnapshot();
  const { isDark } = tokens;

  // Create rounded-corner box geometry for paper sheets
  const paperGeometry = useMemo(() => {
    // 3.2 width, 4.4 height, 0.024 thickness
    return new THREE.BoxGeometry(3.2, 4.4, 0.024);
  }, []);

  // Paper materials dynamically bound to runtime CSS tokens
  const { baseMaterial, topSheetMaterial, lineMaterial, headerMaterial, accentMaterial } = useMemo(() => {
    return {
      baseMaterial: new THREE.MeshStandardMaterial({
        color: new THREE.Color(tokens.secondary),
        roughness: 0.72,
        metalness: 0.08,
      }),
      topSheetMaterial: new THREE.MeshStandardMaterial({
        color: new THREE.Color(tokens.cardSolid),
        roughness: 0.65,
        metalness: 0.08,
        emissive: new THREE.Color(tokens.primary),
        emissiveIntensity: isDark ? 0.06 : 0.01,
      }),
      // NOTE: must be a SOLID token. --border carries alpha, and an alpha
      // colour normalises to near-black, which painted black bars on the page.
      lineMaterial: new THREE.MeshBasicMaterial({
        color: new THREE.Color(tokens.isDark ? '#3A4A63' : '#D8E2EE'),
      }),
      headerMaterial: new THREE.MeshBasicMaterial({
        color: new THREE.Color(tokens.primary),
      }),
      accentMaterial: new THREE.MeshBasicMaterial({
        color: new THREE.Color(tokens.isDark ? '#22D3EE' : '#7DD3FC'),
      }),
    };
  }, [tokens, isDark]);

  useFrame((state, delta) => {
    if (!groupRef.current) return;

    const time = state.clock.elapsedTime;

    // Gentle floating idle motion
    const floatY = Math.sin(time * 1.5) * 0.06;
    const floatRotZ = Math.cos(time * 1.2) * 0.015;

    // Pointer-driven tilt interpolation
    const targetTiltX = 0.45 + mouseRef.current.y * 0.22;
    const targetTiltY = -0.35 + mouseRef.current.x * 0.28;

    groupRef.current.rotation.x = THREE.MathUtils.lerp(groupRef.current.rotation.x, targetTiltX, delta * 3.5);
    groupRef.current.rotation.y = THREE.MathUtils.lerp(groupRef.current.rotation.y, targetTiltY, delta * 3.5);
    groupRef.current.rotation.z = THREE.MathUtils.lerp(groupRef.current.rotation.z, floatRotZ, delta * 3.5);

    groupRef.current.position.y = THREE.MathUtils.lerp(
      groupRef.current.position.y,
      -0.2 + floatY - scrollProgress * 0.8,
      delta * 4.0
    );

    // Scroll-driven fanning / lift-off effect
    sheetRefs.current.forEach((mesh, index) => {
      if (!mesh) return;
      const baseCfg = SHEETS_CONFIG[index];
      const fanMultiplier = 1.0 + scrollProgress * (index * 0.45);

      mesh.position.y = baseCfg.offsetY * fanMultiplier;
      mesh.rotation.z = baseCfg.rotationZ * (1.0 + scrollProgress * 0.6);
      mesh.rotation.x = baseCfg.rotationX * fanMultiplier;
    });
  });

  return (
    <group ref={groupRef} position={[0, -0.2, 0]}>
      {SHEETS_CONFIG.map((cfg, idx) => {
        const isTop = idx === SHEETS_CONFIG.length - 1;

        return (
          <group key={idx}>
            <mesh
              ref={(el) => {
                sheetRefs.current[idx] = el;
              }}
              geometry={paperGeometry}
              material={isTop ? topSheetMaterial : baseMaterial}
              position={[0, cfg.offsetY, (idx - 3) * 0.05]}
              rotation={[cfg.rotationX, 0, cfg.rotationZ]}
              scale={cfg.scale}
              castShadow
              receiveShadow
            >
              {/* Document Mockup Layout on the Top Sheet */}
              {isTop && (
                <group position={[0, 0, 0.015]}>
                  {/* Document Title Header Bar */}
                  <mesh position={[-0.65, 1.5, 0]} material={headerMaterial}>
                    <planeGeometry args={[1.2, 0.18]} />
                  </mesh>

                  {/* Status Stamp Pill in top-right */}
                  <mesh position={[0.95, 1.5, 0]} material={accentMaterial}>
                    <planeGeometry args={[0.55, 0.14]} />
                  </mesh>

                  {/* Decorative Document Paragraph Lines */}
                  <mesh position={[0, 1.0, 0]} material={lineMaterial}>
                    <planeGeometry args={[2.5, 0.06]} />
                  </mesh>
                  <mesh position={[-0.2, 0.75, 0]} material={lineMaterial}>
                    <planeGeometry args={[2.1, 0.06]} />
                  </mesh>
                  <mesh position={[0.1, 0.5, 0]} material={lineMaterial}>
                    <planeGeometry args={[2.3, 0.06]} />
                  </mesh>

                  {/* Horizontal Rule */}
                  <mesh position={[0, 0.15, 0]} material={lineMaterial}>
                    <planeGeometry args={[2.6, 0.02]} />
                  </mesh>

                  {/* Form Dynamic Blanks Field Blocks */}
                  <mesh position={[-0.65, -0.25, 0]} material={lineMaterial}>
                    <planeGeometry args={[1.1, 0.32]} />
                  </mesh>
                  <mesh position={[0.65, -0.25, 0]} material={lineMaterial}>
                    <planeGeometry args={[1.1, 0.32]} />
                  </mesh>

                  <mesh position={[-0.65, -0.75, 0]} material={lineMaterial}>
                    <planeGeometry args={[1.1, 0.32]} />
                  </mesh>
                  <mesh position={[0.65, -0.75, 0]} material={lineMaterial}>
                    <planeGeometry args={[1.1, 0.32]} />
                  </mesh>

                  {/* Bottom Approval Signature Line */}
                  <mesh position={[-0.5, -1.45, 0]} material={lineMaterial}>
                    <planeGeometry args={[1.3, 0.04]} />
                  </mesh>
                  <mesh position={[0.85, -1.45, 0]} material={headerMaterial}>
                    <planeGeometry args={[0.7, 0.22]} />
                  </mesh>
                </group>
              )}
            </mesh>
          </group>
        );
      })}
    </group>
  );
};

export default PaperStack3D;

