import React, { useRef, useMemo, useEffect, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useUIStore } from '@/store/uiStore';
import { usePerformanceTier } from '../../hooks/usePerformanceTier';
import { AuroraGlow } from '../AuroraGlow';
import { getCssTokenAsThreeColor } from '../../lib/tokens';

const ctaWaveVertexShader = `
  uniform float uTime;
  uniform float uDpr;
  
  attribute float aScale;
  attribute float aSpeed;
  attribute float aPhase;

  varying float vElevation;
  varying float vAlpha;

  void main() {
    vec3 pos = position;
    
    // Calm undulating ribbon waves
    float wave = sin(pos.x * 0.12 + uTime * 0.5 * aSpeed + aPhase) * cos(pos.z * 0.14 + uTime * 0.4) * 1.4;
    pos.y += wave;
    
    vElevation = (pos.y + 2.0) / 4.0;
    vAlpha = aScale;

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    gl_Position = projectionMatrix * mvPosition;
    
    // Distance attenuated point size
    gl_PointSize = (12.0 * aScale * uDpr) / -mvPosition.z;
    gl_PointSize = clamp(gl_PointSize, 1.0, 28.0);
  }
`;

const ctaWaveFragmentShader = `
  uniform float uOpacity;
  uniform vec3 uColorCrest;
  uniform vec3 uColorTrough;

  varying float vElevation;
  varying float vAlpha;

  void main() {
    float dist = distance(gl_PointCoord, vec2(0.5));
    if (dist > 0.5) discard;
    float alpha = smoothstep(0.5, 0.08, dist) * vAlpha;

    vec3 finalColor = mix(uColorTrough, uColorCrest, clamp(vElevation, 0.0, 1.0));
    gl_FragColor = vec4(finalColor, alpha * uOpacity * 0.7);
  }
`;

interface RibbonPointsProps {
  particleCount: number;
  dpr: number;
  isDark: boolean;
}

const RibbonPoints: React.FC<RibbonPointsProps> = ({ particleCount, dpr, isDark }) => {
  const pointsRef = useRef<THREE.Points>(null);
  const materialRef = useRef<THREE.ShaderMaterial>(null);

  const { positions, scales, speeds, phases } = useMemo(() => {
    const count = particleCount;
    const pos = new Float32Array(count * 3);
    const sca = new Float32Array(count);
    const spd = new Float32Array(count);
    const phs = new Float32Array(count);

    const xSpan = 42;
    const zSpan = 22;

    for (let i = 0; i < count; i++) {
      pos[i * 3] = (Math.random() - 0.5) * xSpan;
      pos[i * 3 + 1] = (Math.random() - 0.5) * 2.5;
      pos[i * 3 + 2] = (Math.random() - 0.5) * zSpan;

      sca[i] = 0.5 + Math.random() * 0.75;
      spd[i] = 0.7 + Math.random() * 0.6;
      phs[i] = Math.random() * Math.PI * 2;
    }

    return { positions: pos, scales: sca, speeds: spd, phases: phs };
  }, [particleCount]);

  const crestColor = useMemo(() => getCssTokenAsThreeColor(isDark ? '--ring' : '--primary'), [isDark]);
  const troughColor = useMemo(() => getCssTokenAsThreeColor(isDark ? '--accent-violet' : '--secondary-foreground'), [isDark]);

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uDpr: { value: dpr },
      uColorCrest: { value: crestColor },
      uColorTrough: { value: troughColor },
      uOpacity: { value: 0.75 },
    }),
    [dpr, crestColor, troughColor]
  );

  useEffect(() => {
    if (materialRef.current) {
      materialRef.current.uniforms.uColorCrest.value.copy(crestColor);
      materialRef.current.uniforms.uColorTrough.value.copy(troughColor);
      materialRef.current.blending = isDark ? THREE.AdditiveBlending : THREE.NormalBlending;
      materialRef.current.needsUpdate = true;
    }
  }, [isDark, crestColor, troughColor]);

  useFrame((state) => {
    if (!materialRef.current) return;
    materialRef.current.uniforms.uTime.value = state.clock.getElapsedTime();

    if (pointsRef.current) {
      pointsRef.current.rotation.y = Math.sin(state.clock.getElapsedTime() * 0.12) * 0.06;
    }
  });

  return (
    <points ref={pointsRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
        <bufferAttribute
          attach="attributes-aScale"
          args={[scales, 1]}
        />
        <bufferAttribute
          attach="attributes-aSpeed"
          args={[speeds, 1]}
        />
        <bufferAttribute
          attach="attributes-aPhase"
          args={[phases, 1]}
        />
      </bufferGeometry>
      <shaderMaterial
        ref={materialRef}
        vertexShader={ctaWaveVertexShader}
        fragmentShader={ctaWaveFragmentShader}
        uniforms={uniforms}
        transparent
        depthWrite={false}
        blending={isDark ? THREE.AdditiveBlending : THREE.NormalBlending}
      />
    </points>
  );
};

export interface FinalCtaWave3DProps {
  className?: string;
}

export const FinalCtaWave3D: React.FC<FinalCtaWave3DProps> = ({ className = '' }) => {
  const { theme } = useUIStore();
  const isDark = theme === 'dark';
  const { tier, dpr, particleCount, isSupported, isReducedMotion } = usePerformanceTier();
  const [isInView, setIsInView] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const [hasContextError, setHasContextError] = useState(false);

  // Lazy mount/unmount via IntersectionObserver (rootMargin: 300px)
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new IntersectionObserver(
      (entries) => {
        setIsInView(entries[0]?.isIntersecting ?? false);
      },
      { rootMargin: '300px', threshold: 0.02 }
    );

    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Fallback to CSS AuroraGlow if 3D unsupported, reduced motion, static tier, or context lost
  if (!isSupported || isReducedMotion || tier === 'static' || hasContextError) {
    return <AuroraGlow intensity="subtle" className={className} />;
  }

  const ribbonCount = Math.min(2200, Math.round(particleCount * 0.65));

  return (
    <div
      ref={containerRef}
      className={`absolute inset-0 pointer-events-none overflow-hidden select-none z-0 ${className}`}
      aria-hidden="true"
    >
      {/* Background Soft Aurora Gradient */}
      <div
        className="absolute inset-0 transition-opacity duration-700"
        style={{
          background: isDark
            ? 'radial-gradient(ellipse 85% 65% at 50% 60%, color-mix(in srgb, var(--primary) 8%, transparent) 0%, color-mix(in srgb, var(--accent-violet) 5%, transparent) 50%, transparent 80%)'
            : 'radial-gradient(ellipse 85% 65% at 50% 60%, color-mix(in srgb, var(--primary) 9%, transparent) 0%, color-mix(in srgb, var(--chart-3) 4%, transparent) 50%, transparent 80%)',
        }}
      />

      {isInView && (
        <Canvas
          dpr={dpr}
          camera={{ position: [0, 4, 16], fov: 42, near: 0.1, far: 80 }}
          gl={{
            antialias: true,
            alpha: true,
            powerPreference: 'high-performance',
          }}
          onCreated={({ gl }) => {
            gl.domElement.addEventListener('webglcontextlost', (e) => {
              e.preventDefault();
              setHasContextError(true);
            });
          }}
          frameloop={isInView ? 'always' : 'never'}
          style={{ width: '100%', height: '100%', pointerEvents: 'none' }}
        >
          <RibbonPoints
            particleCount={ribbonCount}
            dpr={dpr}
            isDark={isDark}
          />
        </Canvas>
      )}
    </div>
  );
};

export default FinalCtaWave3D;

