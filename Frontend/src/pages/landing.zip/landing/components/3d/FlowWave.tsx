import React, { useRef, useMemo, useEffect, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { useUIStore } from '@/store/uiStore';
import { usePerformanceTier } from '../../hooks/usePerformanceTier';
import { AuroraGlow } from '../AuroraGlow';
import { getCssTokenAsThreeColor } from '../../lib/tokens';

const waveVertexShader = `
  uniform float uTime;
  uniform vec2 uMouse;
  uniform float uScroll;
  uniform float uDpr;
  uniform float uSize;
  
  attribute float aScale;
  attribute vec3 aColor;

  varying vec3 vColor;
  varying float vElevation;

  void main() {
    vec3 pos = position;
    
    // Wave calculations with multiple octaves
    float distToCenter = length(pos.xz);
    float wave1 = sin(pos.x * 0.18 + uTime * 0.8) * cos(pos.z * 0.18 + uTime * 0.6) * 1.8;
    float wave2 = sin(pos.x * 0.08 + pos.z * 0.08 + uTime * 0.4) * 1.2;
    float mouseInfluence = sin(length(pos.xz - uMouse * 12.0) * 0.3 - uTime * 1.5) * 0.8;
    
    // Flatten as scroll progresses
    float scrollDamp = max(0.1, 1.0 - uScroll * 1.4);
    pos.y += (wave1 + wave2 + mouseInfluence) * scrollDamp;
    
    // Pass elevation for color gradient
    vElevation = (pos.y + 3.0) / 6.0;
    vColor = aColor;

    vec4 mvPosition = modelViewMatrix * vec4(pos, 1.0);
    gl_Position = projectionMatrix * mvPosition;
    
    // Point size with distance attenuation
    gl_PointSize = (uSize * aScale * uDpr) / -mvPosition.z;
    gl_PointSize = clamp(gl_PointSize, 1.0, 32.0);
  }
`;

const waveFragmentShader = `
  uniform float uOpacity;
  uniform vec3 uColorCrest;
  uniform vec3 uColorTrough;

  varying vec3 vColor;
  varying float vElevation;

  void main() {
    // Soft anti-aliased circular particle
    float dist = distance(gl_PointCoord, vec2(0.5));
    if (dist > 0.5) discard;
    float alpha = smoothstep(0.5, 0.05, dist);

    vec3 finalColor = mix(uColorTrough, uColorCrest, clamp(vElevation, 0.0, 1.0));
    gl_FragColor = vec4(finalColor, alpha * uOpacity * 0.75);
  }
`;

export interface WavePointsProps {
  particleCount: number;
  dpr: number;
  isDark: boolean;
}

export const WavePoints: React.FC<WavePointsProps> = ({ particleCount, dpr, isDark }) => {
  const pointsRef = useRef<THREE.Points>(null);
  const materialRef = useRef<THREE.ShaderMaterial>(null);
  const mouseRef = useRef(new THREE.Vector2(0, 0));
  const targetMouseRef = useRef(new THREE.Vector2(0, 0));

  // Grid distribution
  const { positions, scales, colors } = useMemo(() => {
    const cols = Math.round(Math.sqrt(particleCount * 1.5));
    const rows = Math.round(particleCount / cols);
    const total = cols * rows;

    const pos = new Float32Array(total * 3);
    const sca = new Float32Array(total);
    const col = new Float32Array(total * 3);

    const xSpan = 38;
    const zSpan = 28;

    let idx = 0;
    for (let i = 0; i < cols; i++) {
      for (let j = 0; j < rows; j++) {
        const u = i / (cols - 1);
        const v = j / (rows - 1);

        const x = (u - 0.5) * xSpan;
        const z = (v - 0.5) * zSpan;
        const y = 0;

        pos[idx * 3] = x;
        pos[idx * 3 + 1] = y;
        pos[idx * 3 + 2] = z;

        sca[idx] = 0.75 + Math.random() * 0.5;

        // Subtle color tint attribute
        col[idx * 3] = 0.2 + Math.random() * 0.1;
        col[idx * 3 + 1] = 0.7 + Math.random() * 0.2;
        col[idx * 3 + 2] = 0.9 + Math.random() * 0.1;

        idx++;
      }
    }

    return { positions: pos, scales: sca, colors: col };
  }, [particleCount]);

  const crestColor = useMemo(() => getCssTokenAsThreeColor('--primary'), [isDark]);
  const troughColor = useMemo(() => getCssTokenAsThreeColor(isDark ? '--accent-violet' : '--secondary-foreground'), [isDark]);

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uMouse: { value: new THREE.Vector2(0, 0) },
      uScroll: { value: 0 },
      uDpr: { value: dpr },
      uSize: { value: 44.0 },
      uColorCrest: { value: crestColor },
      uColorTrough: { value: troughColor },
      uOpacity: { value: 1.0 },
    }),
    [dpr, crestColor, troughColor]
  );

  useEffect(() => {
    const handlePointerMove = (e: MouseEvent) => {
      const nx = (e.clientX / window.innerWidth) * 2 - 1;
      const ny = -(e.clientY / window.innerHeight) * 2 + 1;
      targetMouseRef.current.set(nx, ny);
    };

    window.addEventListener('pointermove', handlePointerMove, { passive: true });
    return () => window.removeEventListener('pointermove', handlePointerMove);
  }, []);

  useFrame((_state, delta) => {
    if (!materialRef.current) return;

    // Smooth pointer lerp
    mouseRef.current.lerp(targetMouseRef.current, delta * 3.5);

    // Uniform updates
    materialRef.current.uniforms.uTime.value += delta * 0.9;
    materialRef.current.uniforms.uMouse.value.copy(mouseRef.current);

    // Scroll normalization (hero scroll range)
    const scrollY = window.scrollY || 0;
    const heroH = window.innerHeight || 800;
    const scrollNorm = Math.min(1.0, scrollY / heroH);
    materialRef.current.uniforms.uScroll.value = scrollNorm;

    // Theme transition lerp
    materialRef.current.uniforms.uColorCrest.value.copy(crestColor);
    materialRef.current.uniforms.uColorTrough.value.copy(troughColor);

    // Rotate points slightly with mouse
    if (pointsRef.current) {
      pointsRef.current.rotation.y = mouseRef.current.x * 0.06;
      pointsRef.current.rotation.x = -0.42 + mouseRef.current.y * 0.04;
    }
  });

  return (
    <points ref={pointsRef} position={[0, -2.4, -4.5]} rotation={[-0.42, 0, 0]}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
        <bufferAttribute
          attach="attributes-aScale"
          args={[scales, 1]}
        />
        <bufferAttribute
          attach="attributes-aColor"
          args={[colors, 3]}
        />
      </bufferGeometry>
      <shaderMaterial
        ref={materialRef}
        vertexShader={waveVertexShader}
        fragmentShader={waveFragmentShader}
        uniforms={uniforms}
        transparent
        depthWrite={false}
        blending={isDark ? THREE.AdditiveBlending : THREE.NormalBlending}
      />
    </points>
  );
};

export interface FlowWaveProps {
  className?: string;
  intensity?: 'subtle' | 'vibrant';
}

export const FlowWave: React.FC<FlowWaveProps> = ({ className = '', intensity = 'vibrant' }) => {
  const { theme } = useUIStore();
  const isDark = theme === 'dark';
  const { tier, dpr, particleCount, isSupported, isReducedMotion } = usePerformanceTier();
  const [isInView, setIsInView] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);
  const [hasContextError, setHasContextError] = useState(false);

  // Lazy pause when scrolled out of view
  useEffect(() => {
    if (!containerRef.current) return;
    const observer = new IntersectionObserver(
      (entries) => {
        setIsInView(entries[0]?.isIntersecting ?? true);
      },
      { threshold: 0.05 }
    );

    observer.observe(containerRef.current);
    return () => observer.disconnect();
  }, []);

  // Fallback to CSS AuroraGlow if 3D unsupported, reduced motion, or WebGL context error
  if (!isSupported || isReducedMotion || tier === 'static' || hasContextError) {
    return <AuroraGlow intensity={intensity} className={className} />;
  }

  return (
    <div
      ref={containerRef}
      className={`absolute inset-0 pointer-events-none overflow-hidden select-none z-0 ${className}`}
      aria-hidden="true"
    >
      {/* Background radial gradient backing that matches theme perfectly */}
      <div
        className="absolute inset-0 transition-opacity duration-700"
        style={{
          background: isDark
            ? 'radial-gradient(ellipse 90% 60% at 50% 20%, color-mix(in srgb, var(--primary) 12%, transparent) 0%, color-mix(in srgb, var(--accent-violet) 6%, transparent) 45%, transparent 75%)'
            : 'radial-gradient(ellipse 90% 60% at 50% 20%, color-mix(in srgb, var(--primary) 10%, transparent) 0%, color-mix(in srgb, var(--chart-3) 4%, transparent) 50%, transparent 75%)',
        }}
      />

      {isInView && (
        <Canvas
          dpr={dpr}
          camera={{ position: [0, 6, 14], fov: 45, near: 0.1, far: 100 }}
          gl={{
            antialias: true,
            alpha: true,
            powerPreference: 'high-performance',
          }}
          onCreated={({ gl }) => {
            gl.domElement.addEventListener('webglcontextlost', (e) => {
              e.preventDefault();
              setHasContextError(true);
            });
          }}
          frameloop={isInView ? 'always' : 'never'}
          style={{ width: '100%', height: '100%', pointerEvents: 'none' }}
        >
          <WavePoints
            particleCount={intensity === 'subtle' ? Math.round(particleCount * 0.7) : particleCount}
            dpr={dpr}
            isDark={isDark}
          />
        </Canvas>
      )}
    </div>
  );
};

export default FlowWave;
