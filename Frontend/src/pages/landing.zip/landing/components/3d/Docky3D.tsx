import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import type { DockyExpression, DockyAccessory } from '../Docky';
import { getCssTokenAsThreeColor } from '../../lib/tokens';

interface Docky3DProps {
  isDark: boolean;
  expression?: DockyExpression;
  accessory?: DockyAccessory;
  mouseRef: React.MutableRefObject<THREE.Vector2>;
}

export const Docky3D: React.FC<Docky3DProps> = ({
  isDark,
  expression = 'happy',
  accessory = 'pen',
  mouseRef,
}) => {
  const mascotRef = useRef<THREE.Group>(null);
  const leftEyeRef = useRef<THREE.Mesh>(null);
  const rightEyeRef = useRef<THREE.Mesh>(null);
  const leftBrowRef = useRef<THREE.Mesh>(null);
  const rightBrowRef = useRef<THREE.Mesh>(null);
  const mouthRef = useRef<THREE.Mesh>(null);
  const penRef = useRef<THREE.Group>(null);

  // Materials for 3D Docky
  const {
    bodyMaterial,
    foldMaterial,
    faceMaterial,
    blushMaterial,
    specularMaterial,
    penBodyMaterial,
    penTipMaterial,
  } = useMemo(() => {
    const bodyColor = getCssTokenAsThreeColor(isDark ? '--muted' : '--card-solid');
    const foldColor = getCssTokenAsThreeColor(isDark ? '--primary' : '--accent-amber-soft');
    const faceColor = getCssTokenAsThreeColor('--foreground');
    const blushColor = getCssTokenAsThreeColor('--destructive');
    const specularColor = getCssTokenAsThreeColor(isDark ? '--foreground' : '--card-solid');
    const penBodyColor = getCssTokenAsThreeColor('--primary');
    const penTipColor = getCssTokenAsThreeColor(isDark ? '--muted-foreground' : '--border-strong');
    const emissiveColor = getCssTokenAsThreeColor('--primary');

    if (isDark) {
      return {
        bodyMaterial: new THREE.MeshStandardMaterial({
          color: bodyColor,
          roughness: 0.55,
          metalness: 0.1,
          emissive: emissiveColor,
          emissiveIntensity: 0.08,
        }),
        foldMaterial: new THREE.MeshStandardMaterial({
          color: foldColor,
          roughness: 0.45,
          metalness: 0.2,
        }),
        faceMaterial: new THREE.MeshBasicMaterial({
          color: faceColor,
        }),
        blushMaterial: new THREE.MeshBasicMaterial({
          color: blushColor,
          transparent: true,
          opacity: 0.45,
        }),
        specularMaterial: new THREE.MeshBasicMaterial({
          color: specularColor,
        }),
        penBodyMaterial: new THREE.MeshStandardMaterial({
          color: penBodyColor,
          roughness: 0.4,
          metalness: 0.25,
        }),
        penTipMaterial: new THREE.MeshStandardMaterial({
          color: penTipColor,
          roughness: 0.2,
          metalness: 0.8,
        }),
      };
    }

    return {
      bodyMaterial: new THREE.MeshStandardMaterial({
        color: bodyColor,
        roughness: 0.62,
        metalness: 0.02,
      }),
      foldMaterial: new THREE.MeshStandardMaterial({
        color: foldColor,
        roughness: 0.5,
        metalness: 0.05,
      }),
      faceMaterial: new THREE.MeshBasicMaterial({
        color: faceColor,
      }),
      blushMaterial: new THREE.MeshBasicMaterial({
        color: blushColor,
        transparent: true,
        opacity: 0.55,
      }),
      specularMaterial: new THREE.MeshBasicMaterial({
        color: specularColor,
      }),
      penBodyMaterial: new THREE.MeshStandardMaterial({
        color: penBodyColor,
        roughness: 0.35,
        metalness: 0.2,
      }),
      penTipMaterial: new THREE.MeshStandardMaterial({
        color: penTipColor,
        roughness: 0.2,
        metalness: 0.85,
      }),
    };
  }, [isDark]);

  useFrame((state, delta) => {
    if (!mascotRef.current) return;

    const time = state.clock.elapsedTime;

    // Organic idle breathing / float motion
    const breathScale = 1.0 + Math.sin(time * 2.2) * 0.015;
    const idleBounceY = Math.sin(time * 1.8) * 0.04;

    mascotRef.current.scale.set(breathScale, breathScale, breathScale);

    // Head tilt following mouse pointer smoothly
    const targetRotY = mouseRef.current.x * 0.35;
    const targetRotX = -mouseRef.current.y * 0.25;

    mascotRef.current.rotation.y = THREE.MathUtils.lerp(mascotRef.current.rotation.y, targetRotY, delta * 4.0);
    mascotRef.current.rotation.x = THREE.MathUtils.lerp(mascotRef.current.rotation.x, targetRotX, delta * 4.0);
    mascotRef.current.position.y = THREE.MathUtils.lerp(
      mascotRef.current.position.y,
      0.55 + idleBounceY,
      delta * 4.0
    );

    // Gentle pen hover
    if (penRef.current) {
      penRef.current.rotation.z = -0.4 + Math.sin(time * 2.5) * 0.08;
      penRef.current.position.y = -0.15 + Math.cos(time * 2.0) * 0.03;
    }

    // Dynamic Eyebrows based on Expression
    if (leftBrowRef.current && rightBrowRef.current) {
      if (expression === 'thinking') {
        // Inquisitive arched eyebrow
        leftBrowRef.current.rotation.z = THREE.MathUtils.lerp(leftBrowRef.current.rotation.z, 0.25, delta * 6.0);
        leftBrowRef.current.position.y = THREE.MathUtils.lerp(leftBrowRef.current.position.y, 0.44, delta * 6.0);
        rightBrowRef.current.rotation.z = THREE.MathUtils.lerp(rightBrowRef.current.rotation.z, -0.05, delta * 6.0);
        rightBrowRef.current.position.y = THREE.MathUtils.lerp(rightBrowRef.current.position.y, 0.38, delta * 6.0);
      } else if (expression === 'celebrating') {
        // High excited brows
        leftBrowRef.current.rotation.z = THREE.MathUtils.lerp(leftBrowRef.current.rotation.z, -0.15, delta * 6.0);
        leftBrowRef.current.position.y = THREE.MathUtils.lerp(leftBrowRef.current.position.y, 0.46, delta * 6.0);
        rightBrowRef.current.rotation.z = THREE.MathUtils.lerp(rightBrowRef.current.rotation.z, 0.15, delta * 6.0);
        rightBrowRef.current.position.y = THREE.MathUtils.lerp(rightBrowRef.current.position.y, 0.46, delta * 6.0);
      } else {
        // Gentle happy brows
        leftBrowRef.current.rotation.z = THREE.MathUtils.lerp(leftBrowRef.current.rotation.z, -0.08, delta * 6.0);
        leftBrowRef.current.position.y = THREE.MathUtils.lerp(leftBrowRef.current.position.y, 0.40, delta * 6.0);
        rightBrowRef.current.rotation.z = THREE.MathUtils.lerp(rightBrowRef.current.rotation.z, 0.08, delta * 6.0);
        rightBrowRef.current.position.y = THREE.MathUtils.lerp(rightBrowRef.current.position.y, 0.40, delta * 6.0);
      }
    }
  });

  return (
    <group ref={mascotRef} position={[0, 0.55, 0.35]}>
      {/* ── Main Mascot Body: Folded Paper Character Slab ── */}
      <mesh material={bodyMaterial} castShadow receiveShadow>
        <boxGeometry args={[1.75, 2.2, 0.08]} />
      </mesh>

      {/* ── Top-Right Dog-Ear Folded Corner ── */}
      <group position={[0.62, 0.85, 0.045]}>
        <mesh material={foldMaterial} rotation={[0, 0, -Math.PI / 4]} castShadow>
          <coneGeometry args={[0.38, 0.04, 3]} />
        </mesh>
      </group>

      {/* ── Facial Features ── */}
      <group position={[0, 0.1, 0.05]}>
        {/* Left Eye */}
        <group position={[-0.32, 0.22, 0]}>
          <mesh ref={leftEyeRef} material={faceMaterial}>
            <sphereGeometry args={[0.085, 16, 16]} />
          </mesh>
          {/* Specular Catchlight */}
          <mesh material={specularMaterial} position={[0.025, 0.025, 0.06]}>
            <sphereGeometry args={[0.03, 8, 8]} />
          </mesh>
        </group>

        {/* Right Eye */}
        <group position={[0.32, 0.22, 0]}>
          <mesh ref={rightEyeRef} material={faceMaterial}>
            <sphereGeometry args={[0.085, 16, 16]} />
          </mesh>
          {/* Specular Catchlight */}
          <mesh material={specularMaterial} position={[0.025, 0.025, 0.06]}>
            <sphereGeometry args={[0.03, 8, 8]} />
          </mesh>
        </group>

        {/* Left Eyebrow */}
        <mesh
          ref={leftBrowRef}
          material={faceMaterial}
          position={[-0.32, 0.40, 0]}
        >
          <boxGeometry args={[0.22, 0.04, 0.02]} />
        </mesh>

        {/* Right Eyebrow */}
        <mesh
          ref={rightBrowRef}
          material={faceMaterial}
          position={[0.32, 0.40, 0]}
        >
          <boxGeometry args={[0.22, 0.04, 0.02]} />
        </mesh>

        {/* Rosy Blush Cheeks */}
        <mesh material={blushMaterial} position={[-0.48, 0.1, 0.01]}>
          <circleGeometry args={[0.09, 16]} />
        </mesh>
        <mesh material={blushMaterial} position={[0.48, 0.1, 0.01]}>
          <circleGeometry args={[0.09, 16]} />
        </mesh>

        {/* Expressive Mouth */}
        <mesh
          ref={mouthRef}
          material={faceMaterial}
          position={[0, -0.05, 0]}
          rotation={[0, 0, 0]}
        >
          {expression === 'celebrating' ? (
            <coneGeometry args={[0.16, 0.12, 16]} />
          ) : (
            <torusGeometry args={[0.12, 0.025, 8, 16, Math.PI]} />
          )}
        </mesh>
      </group>

      {/* ── Optional Accessory: Paper Stylus Pen ── */}
      {accessory === 'pen' && (
        <group ref={penRef} position={[0.88, -0.15, 0.15]} rotation={[0, 0, -0.4]}>
          {/* Pen Barrel */}
          <mesh material={penBodyMaterial} position={[0, 0.25, 0]} castShadow>
            <cylinderGeometry args={[0.05, 0.05, 0.7, 16]} />
          </mesh>
          {/* Pen Cap Ring */}
          <mesh material={penTipMaterial} position={[0, 0.45, 0]}>
            <cylinderGeometry args={[0.055, 0.055, 0.08, 16]} />
          </mesh>
          {/* Pen Nib Tip */}
          <mesh material={penTipMaterial} position={[0, -0.16, 0]}>
            <coneGeometry args={[0.048, 0.14, 16]} />
          </mesh>
        </group>
      )}

      {/* ── Optional Accessory: Glasses ── */}
      {accessory === 'glasses' && (
        <group position={[0, 0.32, 0.07]}>
          <mesh material={penBodyMaterial} position={[-0.32, 0, 0]}>
            <torusGeometry args={[0.13, 0.02, 8, 16]} />
          </mesh>
          <mesh material={penBodyMaterial} position={[0.32, 0, 0]}>
            <torusGeometry args={[0.13, 0.02, 8, 16]} />
          </mesh>
          <mesh material={penBodyMaterial} position={[0, 0, 0]}>
            <boxGeometry args={[0.18, 0.02, 0.02]} />
          </mesh>
        </group>
      )}
    </group>
  );
};

export default Docky3D;

