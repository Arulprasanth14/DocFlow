import React, { useId } from 'react';
import { useReducedMotion } from '../hooks/useReducedMotion';

export type DockyExpression = 'neutral' | 'thinking' | 'happy' | 'worried' | 'celebrating';
export type DockyAccessory = 'none' | 'pen' | 'stamp' | 'glasses' | 'badge' | 'key' | 'cap' | 'sign';

export interface DockyProps {
  expression?: DockyExpression;
  accessory?: DockyAccessory;
  size?: number; // width in px, height scales proportionally (aspect ratio 280:320)
  animated?: boolean;
  className?: string;
  signText?: string;
}

/**
 * Docky — The DocFlow Mascot Rig (Cinematic Vector Edition)
 * Original character: a living paper document with a folded corner, expressive eyes,
 * soft gradient fills, hairline outlines, ground shadow, and swappable accessories.
 * Padded viewBox ensures no accessories or limbs clip.
 */
export const Docky: React.FC<DockyProps> = ({
  expression = 'neutral',
  accessory = 'none',
  size = 180,
  animated = true,
  className = '',
  signText = 'Get Started',
}) => {
  const id = useId();
  const prefersReduced = useReducedMotion();
  const shouldAnimate = animated && !prefersReduced;

  // ViewBox coordinate system: 280 x 320
  // Paper sheet core: x: 65, y: 55, w: 150, h: 200 (fold at x: 175, y: 55 to 215, 95)
  // Center: x: 140, y: 160

  return (
    <div
      className={`inline-block select-none pointer-events-none relative ${className}`}
      style={{
        width: size,
        height: (size * 320) / 280,
        overflow: 'visible',
      }}
      aria-hidden="true"
    >
      <svg
        viewBox="0 0 280 320"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-full overflow-visible"
      >
        <defs>
          {/* Paper Gradient */}
          <linearGradient id={`docky-body-grad-${id}`} x1="70" y1="50" x2="210" y2="260" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="var(--card-solid)" />
            <stop offset="100%" stopColor="var(--muted)" />
          </linearGradient>

          {/* Fold Corner Gradient */}
          <linearGradient id={`docky-fold-grad-${id}`} x1="175" y1="55" x2="215" y2="95" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="var(--border)" />
            <stop offset="100%" stopColor="var(--border-strong)" />
          </linearGradient>

          {/* Soft Ground Shadow */}
          <radialGradient id={`docky-shadow-${id}`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="var(--border)" stopOpacity="0.4" />
            <stop offset="70%" stopColor="var(--border)" stopOpacity="0.1" />
            <stop offset="100%" stopColor="var(--border)" stopOpacity="0" />
          </radialGradient>

          {/* Pen / Gold Accent Gradient */}
          <linearGradient id={`docky-gold-${id}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="var(--accent-amber)" />
            <stop offset="100%" stopColor="var(--warning)" />
          </linearGradient>

          {/* Stamp Gradient */}
          <linearGradient id={`docky-stamp-${id}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="var(--primary)" />
            <stop offset="100%" stopColor="var(--primary-hover)" />
          </linearGradient>
        </defs>

        <style>{`
          @keyframes docky-breathe-${id} {
            0%, 100% { transform: scale(1, 1); }
            50% { transform: scale(1.015, 0.985) translate(0, 1.5px); }
          }
          @keyframes docky-blink-${id} {
            0%, 94%, 98%, 100% { transform: scaleY(1); }
            96% { transform: scaleY(0.08); }
          }
          @keyframes docky-arm-l-${id} {
            0%, 100% { transform: rotate(0deg); }
            50% { transform: rotate(-5deg); }
          }
          @keyframes docky-arm-r-${id} {
            0%, 100% { transform: rotate(0deg); }
            50% { transform: rotate(6deg); }
          }
          .docky-rig-body-${id} {
            transform-origin: 140px 255px;
            animation: ${shouldAnimate ? `docky-breathe-${id} 4.2s ease-in-out infinite` : 'none'};
          }
          .docky-eye-blink-${id} {
            transform-origin: 140px 145px;
            animation: ${shouldAnimate ? `docky-blink-${id} 4.6s ease-in-out infinite` : 'none'};
          }
          .docky-left-arm-${id} {
            transform-origin: 65px 175px;
            animation: ${shouldAnimate ? `docky-arm-l-${id} 3.8s ease-in-out infinite` : 'none'};
          }
          .docky-right-arm-${id} {
            transform-origin: 215px 175px;
            animation: ${shouldAnimate ? `docky-arm-r-${id} 3.8s ease-in-out infinite` : 'none'};
          }
        `}</style>

        {/* 1. Ambient Ground Shadow */}
        <ellipse cx="140" cy="292" rx="72" ry="10" fill={`url(#docky-shadow-${id})`} />

        {/* Rigged Character Group with Idle Breathing */}
        <g className={`docky-rig-body-${id}`}>
          {/* 2. Legs */}
          <g id="docky-legs" stroke="var(--primary)" strokeWidth="4.5" strokeLinecap="round" strokeLinejoin="round">
            <path d="M 115 255 L 115 285 L 105 285" />
            <path d="M 165 255 L 165 285 L 175 285" />
          </g>

          {/* 3. Paper Body Sheet with Folded Corner */}
          <g id="docky-sheet">
            {/* Sheet Outline & Fill */}
            <path
              d="M 75 55 L 175 55 L 215 95 L 215 255 L 75 255 Z"
              fill={`url(#docky-body-grad-${id})`}
              stroke="var(--lp-docky-edge, var(--border))"
              strokeWidth="2"
              strokeLinejoin="round"
            />

            {/* Inner Border Highlight */}
            <path
              d="M 77 57 L 174 57 L 213 96 L 213 253 L 77 253 Z"
              stroke="var(--card-solid)"
              strokeWidth="1.5"
              fill="none"
              opacity="0.9"
            />

            {/* Folded Corner Flap */}
            <path
              d="M 175 55 L 175 95 L 215 95 Z"
              fill={`url(#docky-fold-grad-${id})`}
              stroke="var(--lp-docky-edge, var(--border))"
              strokeWidth="2"
              strokeLinejoin="round"
            />
            {/* Soft shade under fold */}
            <path d="M 173 95 L 215 95 L 173 98 Z" fill="var(--muted-foreground)" opacity="0.15" />

            {/* Faint document lines on chest */}
            <line x1="95" y1="195" x2="185" y2="195" stroke="var(--border)" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="95" y1="210" x2="160" y2="210" stroke="var(--border)" strokeWidth="2.5" strokeLinecap="round" />
            <line x1="95" y1="225" x2="175" y2="225" stroke="var(--border)" strokeWidth="2.5" strokeLinecap="round" />
          </g>

          {/* 4. Face & Expressions */}
          <g id="docky-face">
            {/* Eyes Group with Blinking */}
            <g className={`docky-eye-blink-${id}`}>
              {expression === 'happy' || expression === 'celebrating' ? (
                // Happy arched eyes (^ ^)
                <>
                  <path d="M 112 144 Q 120 136 128 144" stroke="var(--foreground)" strokeWidth="3.5" strokeLinecap="round" fill="none" />
                  <path d="M 152 144 Q 160 136 168 144" stroke="var(--foreground)" strokeWidth="3.5" strokeLinecap="round" fill="none" />
                  {/* Subtle blush */}
                  <circle cx="106" cy="154" r="5" fill="var(--destructive)" opacity="0.35" />
                  <circle cx="174" cy="154" r="5" fill="var(--destructive)" opacity="0.35" />
                </>
              ) : expression === 'worried' ? (
                // Wide nervous eyes (O O)
                <>
                  <ellipse cx="120" cy="144" rx="7" ry="8" fill="var(--foreground)" />
                  <circle cx="122" cy="141" r="2.5" fill="var(--card-solid)" />
                  <ellipse cx="160" cy="144" rx="7" ry="8" fill="var(--foreground)" />
                  <circle cx="162" cy="141" r="2.5" fill="var(--card-solid)" />
                </>
              ) : expression === 'thinking' ? (
                // Glancing eyes
                <>
                  <circle cx="120" cy="144" r="5.5" fill="var(--foreground)" />
                  <circle cx="122" cy="142" r="2" fill="var(--card-solid)" />
                  <circle cx="160" cy="144" r="5.5" fill="var(--foreground)" />
                  <circle cx="162" cy="142" r="2" fill="var(--card-solid)" />
                </>
              ) : (
                // Neutral dot eyes
                <>
                  <circle cx="120" cy="145" r="5" fill="var(--foreground)" />
                  <circle cx="122" cy="143" r="1.8" fill="var(--card-solid)" />
                  <circle cx="160" cy="145" r="5" fill="var(--foreground)" />
                  <circle cx="162" cy="143" r="1.8" fill="var(--card-solid)" />
                </>
              )}
            </g>

            {/* Eyebrows */}
            {expression === 'thinking' && (
              <>
                {/* Inquisitive raised eyebrow + thoughtful level eyebrow (warm & curious, never angry) */}
                <path d="M 112 131 Q 120 126 128 131" stroke="var(--foreground)" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                <path d="M 152 133 L 166 133" stroke="var(--foreground)" strokeWidth="2.5" strokeLinecap="round" />
              </>
            )}
            {expression === 'worried' && (
              <>
                <path d="M 112 132 L 126 136" stroke="var(--foreground)" strokeWidth="2.5" strokeLinecap="round" />
                <path d="M 154 136 L 168 132" stroke="var(--foreground)" strokeWidth="2.5" strokeLinecap="round" />
              </>
            )}
            {expression === 'happy' && (
              <>
                <path d="M 112 132 Q 120 128 128 132" stroke="var(--foreground)" strokeWidth="2.5" strokeLinecap="round" fill="none" />
                <path d="M 152 132 Q 160 128 168 132" stroke="var(--foreground)" strokeWidth="2.5" strokeLinecap="round" fill="none" />
              </>
            )}

            {/* Mouth */}
            {expression === 'celebrating' ? (
              // Open joyful mouth :D
              <path d="M 130 156 Q 140 172 150 156 Z" fill="var(--foreground)" stroke="var(--foreground)" strokeWidth="2" strokeLinejoin="round" />
            ) : expression === 'happy' ? (
              // Curved confident smile :)
              <path d="M 132 158 Q 140 168 148 158" stroke="var(--foreground)" strokeWidth="3" strokeLinecap="round" fill="none" />
            ) : expression === 'worried' ? (
              // Small wavy mouth
              <path d="M 132 163 Q 136 160 140 163 T 148 162" stroke="var(--foreground)" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            ) : expression === 'thinking' ? (
              // Gentle tilted curious smile
              <path d="M 133 161 Q 140 166 147 161" stroke="var(--foreground)" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            ) : (
              // Neutral gentle smile
              <path d="M 133 160 Q 140 166 147 160" stroke="var(--foreground)" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            )}
          </g>

          {/* 5. Accessories */}
          {accessory === 'glasses' && (
            <g id="docky-glasses" stroke="var(--foreground)" strokeWidth="2.5" fill="var(--secondary)">
              <rect x="110" y="136" width="22" height="17" rx="4" />
              <rect x="148" y="136" width="22" height="17" rx="4" />
              <line x1="132" y1="144" x2="148" y2="144" />
              <line x1="95" y1="143" x2="110" y2="143" />
              <line x1="170" y1="143" x2="185" y2="143" />
            </g>
          )}

          {accessory === 'cap' && (
            <g id="docky-cap" transform="translate(68, 22) rotate(-8)">
              {/* Graduation mortarboard */}
              <polygon points="40,25 75,10 110,25 75,40" fill="var(--foreground)" stroke="var(--border)" strokeWidth="1.5" />
              <rect x="58" y="30" width="34" height="14" rx="2" fill="var(--muted)" />
              <circle cx="75" cy="25" r="3" fill="var(--accent-amber)" />
              <path d="M 75 25 Q 90 32 94 48" stroke="var(--accent-amber)" strokeWidth="2" fill="none" />
            </g>
          )}

          {accessory === 'badge' && (
            <g id="docky-badge" transform="translate(132, 182)">
              <polygon points="8,0 16,5 16,15 8,22 0,15 0,5" fill={`url(#docky-gold-${id})`} stroke="var(--warning)" strokeWidth="1.5" />
              <path d="M 5 11 L 7 13 L 11 8" stroke="var(--card-solid)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            </g>
          )}

          {/* 6. Arms & Handheld Items */}
          {expression === 'celebrating' ? (
            // Arms raised up high
            <g id="docky-arms" stroke="var(--primary)" strokeWidth="4.5" strokeLinecap="round">
              <path d="M 75 165 Q 55 130 50 115" />
              <path d="M 215 165 Q 235 130 240 115" />
            </g>
          ) : accessory === 'sign' ? (
            // Holding placard with both hands
            <g id="docky-sign-group">
              <g stroke="var(--primary)" strokeWidth="4.5" strokeLinecap="round">
                <path d="M 75 175 Q 90 195 105 195" />
                <path d="M 215 175 Q 200 195 185 195" />
              </g>
              {/* Sign Board */}
              <rect x="70" y="178" width="140" height="42" rx="8" fill="var(--card-solid)" stroke="var(--primary)" strokeWidth="2" />
              <text x="140" y="204" textAnchor="middle" fill="var(--primary)" fontSize="13" fontWeight="bold" fontFamily="var(--font-heading)">
                {signText}
              </text>
            </g>
          ) : (
            // Standard Left and Right Arms with sway
            <g id="docky-standard-arms">
              {/* Left Arm */}
              <g className={`docky-left-arm-${id}`}>
                <path d="M 75 175 Q 55 185 52 205" stroke="var(--primary)" strokeWidth="4.5" strokeLinecap="round" fill="none" />
                <circle cx="52" cy="207" r="4.5" fill="var(--primary)" />
              </g>

              {/* Right Arm */}
              <g className={`docky-right-arm-${id}`}>
                <path d="M 215 175 Q 235 185 238 205" stroke="var(--primary)" strokeWidth="4.5" strokeLinecap="round" fill="none" />
                <circle cx="238" cy="207" r="4.5" fill="var(--primary)" />

                {/* Handheld Pen */}
                {accessory === 'pen' && (
                  <g transform="translate(236, 185) rotate(-28)">
                    <rect x="0" y="0" width="6" height="32" rx="3" fill="var(--primary)" stroke="var(--primary-hover)" strokeWidth="1" />
                    <polygon points="0,32 6,32 3,40" fill={`url(#docky-gold-${id})`} />
                    <rect x="1" y="4" width="4" height="4" fill="var(--primary-soft)" />
                  </g>
                )}

                {/* Handheld Stamp */}
                {accessory === 'stamp' && (
                  <g transform="translate(235, 192) rotate(15)">
                    <rect x="-6" y="-14" width="12" height="12" rx="2" fill="var(--warning)" />
                    <rect x="-10" y="-2" width="20" height="6" rx="2" fill="var(--primary-hover)" />
                    <ellipse cx="0" cy="4" rx="8" ry="3" fill="var(--primary)" />
                  </g>
                )}

                {/* Handheld Key */}
                {accessory === 'key' && (
                  <g transform="translate(236, 196) rotate(-45)">
                    <circle cx="4" cy="4" r="6" stroke="var(--warning)" strokeWidth="2.5" fill="none" />
                    <line x1="8" y1="8" x2="22" y2="8" stroke="var(--warning)" strokeWidth="2.5" strokeLinecap="round" />
                    <line x1="16" y1="8" x2="16" y2="13" stroke="var(--warning)" strokeWidth="2" strokeLinecap="round" />
                    <line x1="20" y1="8" x2="20" y2="12" stroke="var(--warning)" strokeWidth="2" strokeLinecap="round" />
                  </g>
                )}
              </g>
            </g>
          )}
        </g>
      </svg>
    </div>
  );
};

export default Docky;
