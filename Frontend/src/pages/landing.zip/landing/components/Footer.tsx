import React from 'react';
import { ArrowUp, ShieldCheck } from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { Container } from './Container';
import { Docky } from './Docky';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const currentYear = new Date().getFullYear();

  return (
    <footer className="relative bg-card text-foreground border-t border-border pt-16 pb-12 overflow-hidden">
      <Container data-qa="container">
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-10 lg:gap-8 pb-12 border-b border-border">
          {/* Brand & Blurb (2 columns) */}
          <div className="lg:col-span-2 space-y-4">
            <a href="#top" className="inline-flex items-center gap-2.5 group">
              {/* DocFlow Logo Icon */}
              <div className="w-8 h-8 rounded-xl bg-primary text-primary-foreground flex items-center justify-center font-bold text-[0.9375rem] shadow-md shadow-primary/25">
                D
              </div>
              <span className="font-heading font-extrabold text-xl tracking-tight text-foreground">
                DocFlow
              </span>
            </a>

            <p className="text-[0.8125rem] sm:text-[0.9375rem] text-muted-foreground leading-relaxed max-w-sm">
              {LANDING_CONTENT.footer.blurb}
            </p>

            <div className="flex items-center gap-2 pt-2 text-[0.8125rem] text-muted-foreground">
              <ShieldCheck className="w-4 h-4 text-success" />
              <span>Multi-Tenant Enterprise Architecture</span>
            </div>
          </div>

          {/* 4 Link Column Sections */}
          {LANDING_CONTENT.footer.sections.map((section, idx) => (
            <div key={idx} className="space-y-3">
              <h4 className="font-heading font-bold text-[0.8125rem] uppercase tracking-wider text-foreground">
                {section.title}
              </h4>
              <ul className="space-y-2.5">
                {section.links.map((link, lIdx) => (
                  <li key={lIdx}>
                    <a
                      href={link.href}
                      className="text-[0.8125rem] text-muted-foreground hover:text-primary transition-colors inline-block py-0.5"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar: Copyright, SD Innovations Attribution, Docky Peeker, Back to Top */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-6 text-[0.8125rem] text-muted-foreground relative">
          <div className="flex flex-col sm:flex-row items-center gap-2 text-center sm:text-left">
            <p>© {currentYear} DocFlow. All rights reserved.</p>
            <span className="hidden sm:inline text-border">•</span>
            <span className="flex items-center gap-1">
              Built at <strong className="text-foreground font-semibold">SD Innovations</strong>
            </span>
          </div>

          <div className="flex items-center gap-4">
            {/* Discreet Docky Peeking in corner */}
            <div className="relative group cursor-pointer" title="Docky says hi!">
              <div className="w-8 h-8 opacity-80 group-hover:opacity-100 transition-opacity">
                <Docky size={32} expression="happy" accessory="none" animated={false} />
              </div>
            </div>

            {/* Back to Top Button */}
            <button
              data-cursor="link" type="button"
              onClick={scrollToTop}
              aria-label="Scroll back to top"
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-secondary text-foreground hover:bg-primary hover:text-primary-foreground transition-all duration-200 text-[0.8125rem] font-semibold shadow-xs cursor-pointer"
            >
              <span>Back to top</span>
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </Container>
    </footer>
  );
};

export default Footer;
