import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Sun, Moon, Menu, X, ArrowRight } from 'lucide-react';
import { useUIStore } from '@/store/uiStore';
import { useActiveSection, landingStore, useLandingStore } from '../store';
import { Container } from './Container';
import { Docky } from './Docky';
import { prefersReducedMotion } from '@/lib/motion';

const NAV_LINKS = [
  { label: 'How it works', href: '#journey', id: 'journey' },
  { label: 'Features', href: '#features', id: 'features' },
  { label: 'Roles', href: '#roles', id: 'roles' },
  { label: 'AI Assistant', href: '#ai', id: 'ai' },
  { label: 'Security', href: '#security', id: 'security' },
  { label: 'FAQ', href: '#faq', id: 'faq' },
];

export const Navbar: React.FC = () => {
  const { theme, toggleTheme } = useUIStore();
  const isLight = theme === 'light';
  const activeSection = useActiveSection();
  const { isMobileDrawerOpen } = useLandingStore();

  const [scrolled, setScrolled] = useState(false);
  const [visible, setVisible] = useState(true);
  const lastScrollY = useRef(0);

  const navListRef = useRef<HTMLDivElement>(null);
  const pillRef = useRef<HTMLSpanElement>(null);
  const ctaRef = useRef<HTMLAnchorElement>(null);

  /* Sliding pill indicator: measured from the active link, so it can never
     drift out of sync with the section the tracker reports. */
  const movePill = useCallback(() => {
    const list = navListRef.current;
    const pill = pillRef.current;
    if (!list || !pill) return;

    const active = list.querySelector<HTMLElement>('[data-nav-active="true"]');
    if (!active) {
      pill.style.opacity = '0';
      return;
    }
    pill.style.opacity = '1';
    pill.style.width = `${active.offsetWidth}px`;
    pill.style.transform = `translate3d(${active.offsetLeft}px, 0, 0)`;
  }, []);

  useLayoutEffect(movePill, [movePill, activeSection]);

  useEffect(() => {
    window.addEventListener('resize', movePill, { passive: true });
    document.fonts?.ready.then(movePill).catch(() => {});
    return () => window.removeEventListener('resize', movePill);
  }, [movePill]);

  // Hide on scroll down, reveal on scroll up
  useEffect(() => {
    const onScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 20);
      if (y > 120) {
        setVisible(!(y > lastScrollY.current) || isMobileDrawerOpen);
      } else {
        setVisible(true);
      }
      lastScrollY.current = y;
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, [isMobileDrawerOpen]);

  // Close the drawer on Escape
  useEffect(() => {
    if (!isMobileDrawerOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') landingStore.setMobileDrawerOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isMobileDrawerOpen]);

  // Magnetic nav CTA
  useEffect(() => {
    const el = ctaRef.current;
    if (!el || prefersReducedMotion()) return;
    const onMove = (e: MouseEvent) => {
      const r = el.getBoundingClientRect();
      el.style.transform = `translate3d(${Math.max(-8, Math.min(8, (e.clientX - r.left - r.width / 2) * 0.25))}px, ${Math.max(-8, Math.min(8, (e.clientY - r.top - r.height / 2) * 0.35))}px, 0)`;
    };
    const onLeave = () => {
      el.style.transform = 'translate3d(0,0,0)';
    };
    el.addEventListener('mousemove', onMove);
    el.addEventListener('mouseleave', onLeave);
    return () => {
      el.removeEventListener('mousemove', onMove);
      el.removeEventListener('mouseleave', onLeave);
    };
  }, []);

  const setDrawerOpen = (open: boolean) => landingStore.setMobileDrawerOpen(open);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-[transform,background-color,box-shadow,border-color] duration-500 ${
        visible ? 'translate-y-0' : '-translate-y-full'
      } ${
        scrolled
          ? 'bg-card/75 backdrop-blur-xl backdrop-saturate-150 border-b border-border shadow-[var(--lp-shadow-1)]'
          : 'bg-transparent border-b border-transparent'
      }`}
      style={{ height: 'var(--lp-nav-h)' }}
    >
      <Container wide className="h-full flex items-center justify-between gap-4">
        {/* Brand */}
        <a
          href="#hero"
          data-cursor="link"
          className="flex items-center gap-2.5 group select-none rounded-xl"
          aria-label="DocFlow home"
        >
          <span className="w-9 h-9 rounded-xl bg-gradient-brand flex items-center justify-center shadow-[var(--shadow-glow)] transition-transform duration-500 group-hover:scale-105 group-hover:-rotate-6">
            <Docky size={24} expression="happy" animated={false} />
          </span>
          <span className="font-heading font-extrabold text-xl tracking-tight text-foreground">
            Doc<span className="text-primary">Flow</span>
          </span>
        </a>

        {/* Desktop nav with sliding pill */}
        <nav
          className="hidden lg:block relative rounded-xl lp-glass p-1"
          aria-label="Main"
        >
          <div ref={navListRef} className="relative flex items-center gap-0.5">
            <span ref={pillRef} className="lp-nav-pill" aria-hidden="true" />
            {NAV_LINKS.map((link) => {
              const isActive = activeSection === link.id;
              return (
                <a
                  key={link.id}
                  href={link.href}
                  data-cursor="link"
                  data-nav-active={isActive ? 'true' : 'false'}
                  aria-current={isActive ? 'true' : undefined}
                  className={`relative z-10 px-3.5 py-2 rounded-lg font-medium whitespace-nowrap transition-colors duration-300 text-[0.9375rem] ${
                    isActive ? 'text-primary font-semibold' : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  {link.label}
                </a>
              );
            })}
          </div>
        </nav>

        {/* Actions */}
        <div className="hidden sm:flex items-center gap-2.5">
          <button
            type="button"
            onClick={toggleTheme}
            data-cursor="link"
            className="relative w-10 h-10 grid place-items-center rounded-xl lp-glass text-foreground hover:text-primary transition-colors"
            aria-label={isLight ? 'Switch to dark theme' : 'Switch to light theme'}
          >
            <span className="lp-theme-icon absolute inset-0" data-hidden={isLight ? 'false' : 'true'}>
              <Moon size={17} />
            </span>
            <span className="lp-theme-icon absolute inset-0" data-hidden={isLight ? 'true' : 'false'}>
              <Sun size={17} />
            </span>
          </button>

          <Link
            to="/login"
            data-cursor="link"
            className="px-3.5 py-2 font-semibold text-foreground hover:text-primary transition-colors rounded-lg text-[0.9375rem]"
          >
            Log in
          </Link>

          <Link
            ref={ctaRef}
            to="/register"
            data-cursor="cta"
            className="group inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground font-bold shadow-[var(--shadow-glow)] hover:bg-primary-hover active:scale-[0.97] transition-colors text-[0.9375rem]"
          >
            <span>Get started</span>
            <ArrowRight size={15} className="transition-transform duration-300 group-hover:translate-x-0.5" />
          </Link>
        </div>

        {/* Mobile */}
        <div className="flex sm:hidden items-center gap-2">
          <button
            type="button"
            onClick={toggleTheme}
            data-cursor="link"
            className="w-10 h-10 grid place-items-center rounded-xl lp-glass text-foreground active:scale-95 transition-transform"
            aria-label={isLight ? 'Switch to dark theme' : 'Switch to light theme'}
          >
            {isLight ? <Moon size={17} /> : <Sun size={17} />}
          </button>
          <button
            type="button"
            onClick={() => setDrawerOpen(!isMobileDrawerOpen)}
            data-cursor="link"
            className="w-10 h-10 grid place-items-center rounded-xl lp-glass text-foreground active:scale-95 transition-transform"
            aria-label={isMobileDrawerOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={isMobileDrawerOpen}
          >
            {isMobileDrawerOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </Container>

      {/* Mobile drawer */}
      {isMobileDrawerOpen && (
        <div className="sm:hidden bg-card/95 backdrop-blur-xl border-b border-border px-6 py-6 flex flex-col gap-5">
          <nav className="flex flex-col gap-1.5" aria-label="Mobile">
            {NAV_LINKS.map((link) => (
              <a
                key={link.id}
                href={link.href}
                data-cursor="link"
                onClick={() => setDrawerOpen(false)}
                aria-current={activeSection === link.id ? 'true' : undefined}
                className={`px-3.5 py-2.5 rounded-xl font-medium transition-colors ${
                  activeSection === link.id
                    ? 'text-primary font-semibold bg-primary/10'
                    : 'text-foreground hover:bg-muted'
                }`}
              >
                {link.label}
              </a>
            ))}
          </nav>
          <div className="pt-5 border-t border-border flex flex-col gap-2.5">
            <Link
              to="/login"
              onClick={() => setDrawerOpen(false)}
              data-cursor="link"
              className="w-full text-center py-3 rounded-xl lp-glass font-semibold"
            >
              Log in
            </Link>
            <Link
              to="/register"
              onClick={() => setDrawerOpen(false)}
              data-cursor="cta"
              className="w-full text-center py-3 rounded-xl bg-primary text-primary-foreground font-bold active:scale-[0.97] transition-transform"
            >
              Get started
            </Link>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
