import React, { Suspense, lazy } from 'react';
import { useMagnetic } from '../hooks/useMagnetic';
import { ArrowRight, Sparkles, CheckCircle2, Calendar } from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { Container } from './Container';
import { Docky } from './Docky';
import { TornDivider } from './TornDivider';
import { AuroraGlow } from './AuroraGlow';

const FinalCtaWave3D = lazy(() => import('./3d/FinalCtaWave3D'));

export const FinalCta: React.FC = () => {
  const ctaRef = useMagnetic<HTMLAnchorElement>(14);

  return (
    <section
      id="get-started"
      aria-labelledby="final-cta-heading"
      className="relative lp-section-rhythm bg-background overflow-x-clip"
    >
      {/* 3D Calm Ribbon Wave (Lazy, unmounted off-screen) with Aurora fallback */}
      <div className="absolute inset-0 pointer-events-none" aria-hidden="true">
        <Suspense fallback={<AuroraGlow intensity="subtle" />}>
          <FinalCtaWave3D />
        </Suspense>
      </div>

      {/* Floating Ambient Atmosphere Orbs */}
      <div
        className="absolute top-1/3 -left-32 w-80 h-80 rounded-full pointer-events-none blur-3xl opacity-10 dark:opacity-20"
        style={{ background: 'radial-gradient(circle, var(--primary) 0%, transparent 70%)' }}
        aria-hidden="true"
      />
      <div
        className="absolute bottom-1/3 -right-32 w-80 h-80 rounded-full pointer-events-none blur-3xl opacity-10 dark:opacity-20"
        style={{ background: 'radial-gradient(circle, var(--accent-violet) 0%, transparent 70%)' }}
        aria-hidden="true"
      />

      <Container data-qa="container">
        <div className="relative max-w-4xl mx-auto text-center z-10">
          {/* Docky Celebratory Mascot Entrance */}
          <div className="flex justify-center mb-8">
            <Docky
              size={130}
              expression="celebrating"
              accessory="stamp"
              animated={true}
            />
          </div>

          {/* Eyebrow Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-primary lp-eyebrow mb-6">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Ready to Retire the Paper Chase?</span>
          </div>

          {/* Main Heading */}
          <h2 id="final-cta-heading" className="lp-h1 text-foreground leading-[1.08] max-w-3xl mx-auto">
            {LANDING_CONTENT.finalCta.heading}
          </h2>

          {/* Subheading */}
          <p className="mt-6 lp-body text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            {LANDING_CONTENT.finalCta.subheading}
          </p>

          {/* CTA Buttons with Animated Border Beam on Primary */}
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-5">
            {/* Primary Action Button with Animated Border Beam */}
            <div className="lp-border-beam-container p-[1.5px] rounded-2xl w-full sm:w-auto shadow-xl shadow-primary/20">
              <a
                ref={ctaRef}
                href="/login"
                data-cursor="cta"
                className="relative z-10 w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-9 py-4 rounded-[14px] bg-primary text-primary-foreground font-bold text-base hover:bg-primary-hover active:scale-[0.97] transition-colors duration-300 group"
              >
                <span>{LANDING_CONTENT.finalCta.primaryButton}</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </a>
            </div>

            {/* Secondary Action Button */}
            <a
              href="mailto:demo@docflow.app?subject=DocFlow%20Product%20Demo%20Request"
              data-cursor="link"
              className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-8 py-4 rounded-2xl lp-glass text-foreground font-semibold text-base hover:-translate-y-0.5 active:scale-[0.97] transition-transform duration-300"
            >
              <Calendar className="w-4 h-4 text-primary" />
              <span>{LANDING_CONTENT.finalCta.secondaryButton}</span>
            </a>
          </div>

          {/* Footnote Trust Points */}
          <div className="mt-12 pt-8 border-t border-border flex flex-wrap items-center justify-center gap-6 text-[0.9375rem] text-muted-foreground">
            <span className="flex items-center gap-1.5 font-medium">
              <CheckCircle2 className="w-4 h-4 text-success" />
              <span>Instant workspace setup</span>
            </span>
            <span className="hidden sm:inline text-muted-foreground/60">•</span>
            <span className="flex items-center gap-1.5 font-medium">
              <CheckCircle2 className="w-4 h-4 text-success" />
              <span>Isolated workspace per organization</span>
            </span>
            <span className="hidden sm:inline text-muted-foreground/60">•</span>
            <span className="flex items-center gap-1.5 font-medium">
              <CheckCircle2 className="w-4 h-4 text-success" />
              <span>Unified role portal</span>
            </span>
          </div>
        </div>
      </Container>

      {/* Torn Edge Transition to Footer */}
      <div className="mt-20 sm:mt-28">
        <TornDivider fillToken="var(--background)" direction="bottom" seed="C" />
      </div>
    </section>
  );
};

export default FinalCta;
