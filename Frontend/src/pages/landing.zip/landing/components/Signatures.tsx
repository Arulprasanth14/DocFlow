import React, { useRef, useEffect } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  Lock,
  History,
  CheckCircle,
  FileSignature,
  Fingerprint,
} from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { StatusChip } from './StatusChip';
import { Container } from './Container';
import { TornDivider } from './TornDivider';
import { IsoStamp, IsoSignature } from '../illustrations';
import { prefersReducedMotion } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger);

export const Signatures: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const sigPathRef = useRef<SVGPathElement>(null);
  const sealRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (prefersReducedMotion()) return;

    const ctx = gsap.context(() => {
      // Self-drawing signature stroke animation
      const path = sigPathRef.current;
      if (path) {
        const length = path.getTotalLength();
        gsap.set(path, {
          strokeDasharray: length,
          strokeDashoffset: length,
        });

        gsap.to(path, {
          strokeDashoffset: 0,
          duration: 1.8,
          ease: 'power2.inOut',
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none none',
          },
        });
      }

      // Cryptographic seal stamp slam animation
      if (sealRef.current) {
        gsap.from(sealRef.current, {
          scale: 2.4,
          opacity: 0,
          rotate: -28,
          duration: 0.65,
          ease: 'back.out(2)',
          delay: 1.1,
          scrollTrigger: {
            trigger: sectionRef.current,
            start: 'top 70%',
            toggleActions: 'play none none none',
          },
        });
      }

      // Audit timeline line-by-line reveal
      if (timelineRef.current) {
        const items = timelineRef.current.querySelectorAll('[data-audit-item]');
        gsap.from(items, {
          x: 24,
          opacity: 0,
          stagger: 0.16,
          duration: 0.7,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: timelineRef.current,
            start: 'top 80%',
            toggleActions: 'play none none none',
          },
        });
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      id="signatures"
      aria-labelledby="signatures-heading"
      ref={sectionRef}
      className="relative lp-section-rhythm lp-section-deep overflow-x-clip"
    >
      {/* Background Atmosphere Glow */}
      <div
        className="absolute top-1/4 -left-40 w-96 h-96 rounded-full pointer-events-none blur-3xl opacity-10 dark:opacity-20"
        style={{ background: 'radial-gradient(circle, var(--primary) 0%, transparent 70%)' }}
        aria-hidden="true"
      />
      <div
        className="absolute bottom-1/4 -right-40 w-96 h-96 rounded-full pointer-events-none blur-3xl opacity-10 dark:opacity-15"
        style={{ background: 'radial-gradient(circle, var(--accent-violet) 0%, transparent 70%)' }}
        aria-hidden="true"
      />

      <Container data-qa="container">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-2 mb-3">
            <span className="lp-eyebrow px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary">
              {LANDING_CONTENT.signatures.eyebrow}
            </span>
            <StatusChip status={LANDING_CONTENT.signatures.status} size="sm" />
          </div>
          <h2 id="signatures-heading" className="lp-h2 text-foreground mt-2">
            {LANDING_CONTENT.signatures.heading}
          </h2>
          <p className="lp-body text-muted-foreground mt-4">
            {LANDING_CONTENT.signatures.subheading}
          </p>
        </div>

        {/* Split Grid: Left Signature Certificate / Right Audit Timeline */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Interactive Cryptographic Certificate Mockup (6 cols) */}
          <div
            data-cursor="card" data-qa="card"
            className="lg:col-span-6 lp-glass p-6 sm:p-8 rounded-3xl border border-border shadow-2xl space-y-6 relative overflow-hidden"
          >
            {/* Subtle card glow overlay */}
            <div
              className="absolute -top-24 -right-24 w-48 h-48 rounded-full pointer-events-none blur-2xl opacity-20"
              style={{ background: 'radial-gradient(circle, var(--primary) 0%, transparent 70%)' }}
              aria-hidden="true"
            />

            <div className="flex items-center justify-between pb-4 border-b border-border">
              <div className="flex items-center gap-2.5">
                <FileSignature size={20} className="text-primary" />
                <span className="font-heading font-bold text-[0.9375rem] text-foreground">
                  Cryptographic Signature Proof
                </span>
              </div>
              <span className="text-[0.8125rem] text-primary font-semibold bg-primary/10 border border-primary/20 px-2.5 py-1 rounded-full flex items-center gap-1.5">
                <Fingerprint size={12} />
                <span>Verified Certificate</span>
              </span>
            </div>

            {/* Document Details Block & Signing Tablet Graphic */}
            <div className="flex flex-col sm:flex-row items-center gap-4 p-4 rounded-xl bg-secondary/40 border border-border text-[0.8125rem]">
              <div className="hidden sm:block shrink-0 -my-2">
                <IsoSignature size={95} animated={true} />
              </div>
              <div className="flex-1 space-y-2.5 w-full">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Document:</span>
                  <span className="font-bold text-foreground">
                    Contract Agreement #MSA-9042
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Signer Identity:</span>
                  <span className="font-bold text-foreground">
                    Karthik Raja (Manager, Operations)
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Verification Hash:</span>
                  <span className="font-mono text-[0.8125rem] text-primary">
                    sig-digest: 4a8f92c10b77e8...
                  </span>
                </div>
              </div>
            </div>

            {/* Signature Draw Area with 3D Isometric Stamp */}
            <div className="relative p-5 sm:p-6 rounded-2xl bg-secondary/30 border border-border flex flex-col sm:flex-row items-center justify-between gap-4 min-h-[140px]">
              {/* SVG Cursive Signature */}
              <div className="space-y-1 w-full sm:w-auto">
                <span className="text-[0.8125rem] text-muted-foreground block">Digital Signer Stroke</span>
                <svg viewBox="0 0 300 80" className="w-56 h-18 text-primary overflow-visible">
                  <path
                    ref={sigPathRef}
                    d="M 20 50 Q 40 20, 60 40 T 90 35 T 120 45 Q 140 10, 160 55 T 190 30 T 220 50 Q 240 25, 270 45"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </div>

              {/* 3D Isometric Stamp with concentric verification seal */}
              <div
                ref={sealRef}
                className="shrink-0 flex items-center justify-center"
              >
                <IsoStamp size={110} animated={true} />
              </div>
            </div>

            {/* Tamper-Evident Integrity Notice */}
            <div className="p-3.5 rounded-xl bg-primary/10 border border-primary/20 flex items-start gap-2.5 text-[0.8125rem] text-muted-foreground">
              <Lock size={15} className="text-primary shrink-0 mt-0.5" />
              <span>
                <strong className="text-foreground">Tamper-evident verification:</strong>{' '}
                If any clause or byte in this document is modified after signing, verification flags the discrepancy immediately.
              </span>
            </div>
          </div>

          {/* Right: ACID Audit Trail Stream (6 cols) */}
          <div ref={timelineRef} className="lg:col-span-6 space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <History size={18} className="text-primary" />
              <h3 className="font-heading font-bold text-base text-foreground">
                Verifiable Audit Trail
              </h3>
            </div>

            {/* Audit Line 1 */}
            <div
              data-audit-item
              data-qa="card"
              className="lp-glass p-5 rounded-2xl border border-border flex items-start gap-3.5 hover:border-primary/40 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-primary/15 text-primary flex items-center justify-center shrink-0 text-[0.8125rem] font-bold mt-0.5">
                01
              </div>
              <div className="flex-1 text-[0.8125rem]">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-foreground">Priya Sharma submitted document</span>
                  <span className="font-mono text-muted-foreground text-[0.8125rem]">09:15:20 UTC</span>
                </div>
                <p className="text-muted-foreground mt-1 leading-relaxed">
                  Initial version 1.0 created from Leave Request template. Sealed with initial checksum.
                </p>
              </div>
            </div>

            {/* Audit Line 2 */}
            <div
              data-audit-item
              data-qa="card"
              className="lp-glass p-5 rounded-2xl border border-border flex items-start gap-3.5 hover:border-primary/40 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-primary/15 text-primary flex items-center justify-center shrink-0 text-[0.8125rem] font-bold mt-0.5">
                02
              </div>
              <div className="flex-1 text-[0.8125rem]">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-foreground">Prior approver visibility logged</span>
                  <span className="font-mono text-muted-foreground text-[0.8125rem]">09:15:22 UTC</span>
                </div>
                <p className="text-muted-foreground mt-1 leading-relaxed">
                  Workflow evaluated Stage 1 rules and dispatched in-app notification to Karthik Raja.
                </p>
              </div>
            </div>

            {/* Audit Line 3 */}
            <div
              data-audit-item
              data-qa="card"
              className="lp-glass p-5 rounded-2xl border border-success/40 flex items-start gap-3.5 shadow-md"
            >
              <div className="w-8 h-8 rounded-full bg-success/20 text-success flex items-center justify-center shrink-0 text-[0.8125rem] font-bold mt-0.5">
                03
              </div>
              <div className="flex-1 text-[0.8125rem]">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-foreground">Karthik Raja signed & approved</span>
                  <span className="font-mono text-success font-bold text-[0.8125rem]">10:42:15 UTC</span>
                </div>
                <p className="text-muted-foreground mt-1 leading-relaxed">
                  Digital signature verified and committed into transactional audit stream alongside decision note.
                </p>
              </div>
            </div>

            {/* Audit Line 4 */}
            <div
              data-audit-item
              data-qa="card"
              className="lp-glass p-5 rounded-2xl border border-border flex items-start gap-3.5 hover:border-primary/40 transition-colors"
            >
              <div className="w-8 h-8 rounded-full bg-primary/15 text-primary flex items-center justify-center shrink-0 text-[0.8125rem] font-bold mt-0.5">
                04
              </div>
              <div className="flex-1 text-[0.8125rem]">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-foreground">Discussion thread recorded as history</span>
                  <span className="font-mono text-muted-foreground text-[0.8125rem]">11:05:00 UTC</span>
                </div>
                <p className="text-muted-foreground mt-1 leading-relaxed">
                  Contextual @mention discussion saved alongside final document version for audit reference.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Feature Highlights Grid */}
        <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-[0.8125rem]">
          {LANDING_CONTENT.signatures.highlights.map((h) => (
            <div
              key={h.title}
              data-qa="card"
              className="p-5 rounded-2xl lp-glass space-y-2 border border-border"
            >
              <div className="font-bold text-foreground flex items-center gap-2">
                <CheckCircle size={15} className="text-primary shrink-0" />
                <span>{h.title}</span>
              </div>
              <p className="text-muted-foreground leading-relaxed text-[0.8125rem]">{h.desc}</p>
            </div>
          ))}
        </div>
      </Container>

      {/* Torn Edge transition to active theme background */}
      <div className="mt-16 sm:mt-24">
        <TornDivider fillToken="var(--background)" direction="bottom" seed="B" />
      </div>
    </section>
  );
};

export default Signatures;
