import React, { type ElementType, type ComponentPropsWithoutRef } from 'react';

export interface ContainerProps<T extends ElementType = 'div'> {
  as?: T;
  wide?: boolean; // max-w-[1440px] if true, else max-w-[1280px]
  className?: string;
  children: React.ReactNode;
}

/**
 * Standardized DocFlow Landing Container
 * Enforces centered viewport alignment (equal left/right margins) and consistent gutters.
 * Marked with data-qa="container" for automated layout regression testing.
 */
export function Container<T extends ElementType = 'div'>({
  as,
  wide = false,
  className = '',
  children,
  ...props
}: ContainerProps<T> & Omit<ComponentPropsWithoutRef<T>, keyof ContainerProps<T>>) {
  const Component = as || 'div';
  const maxWidthClass = wide ? 'max-w-[1440px]' : 'max-w-[1280px]';

  return (
    <Component
      data-qa="container"
      className={`w-full mx-auto px-5 sm:px-8 lg:px-12 ${maxWidthClass} ${className}`}
      {...props}
    >
      {children}
    </Component>
  );
}

export default Container;

