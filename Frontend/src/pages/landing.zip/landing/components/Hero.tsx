import React, { Suspense, lazy, useEffect, useRef } from 'react';
import gsap from 'gsap';
import { SplitText } from 'gsap/SplitText';
import { ArrowRight, Sparkles, CheckCircle2, ShieldCheck, Clock, FileText } from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { Container } from './Container';
import { TornDivider } from './TornDivider';
import { AuroraGlow } from './AuroraGlow';
import { Docky } from './Docky';
import { usePlaceInRect } from '../hooks/usePlaceInRect';
import { useLayoutState } from '../hooks/useLayoutMode';
import { usePerformanceTier } from '../hooks/usePerformanceTier';
import { prefersReducedMotion } from '@/lib/motion';

gsap.registerPlugin(SplitText);

// The 3D chunk loads after first paint so the h1 stays the LCP element.
const HeroCanvas = lazy(() =>
  import('./3d/HeroCanvas').then((m) => ({ default: m.HeroCanvas }))
);

interface OrbitCard {
  id: string;
  width: number;
  height: number;
  preferredQuadrant: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right';
  title: string;
  meta: string;
  tone: 'primary' | 'success' | 'violet' | 'warning';
  icon: React.ComponentType<{ size?: number; className?: string }>;
}

const ORBIT_CARDS: OrbitCard[] = [
  {
    id: 'orbit-leave',
    width: 232,
    height: 64,
    preferredQuadrant: 'top-left',
    title: 'Leave Request',
    meta: 'Priya S. · In review',
    tone: 'primary',
    icon: FileText,
  },
  {
    id: 'orbit-po',
    width: 232,
    height: 64,
    preferredQuadrant: 'top-right',
    title: 'PO-8921',
    meta: 'Approved by Finance',
    tone: 'success',
    icon: CheckCircle2,
  },
  {
    id: 'orbit-rfc',
    width: 232,
    height: 64,
    preferredQuadrant: 'bottom-left',
    title: 'Architecture RFC',
    meta: 'Peer review stage',
    tone: 'violet',
    icon: FileText,
  },
  {
    id: 'orbit-sign',
    width: 232,
    height: 64,
    preferredQuadrant: 'bottom-right',
    title: 'Executive Contract',
    meta: 'Signatures (Coming soon)',
    tone: 'warning',
    icon: ShieldCheck,
  },
];

const TONE: Record<OrbitCard['tone'], { chip: string; text: string }> = {
  primary: { chip: 'bg-primary/12 text-primary', text: 'text-primary' },
  success: { chip: 'bg-success/12 text-success', text: 'text-success' },
  violet: { chip: 'bg-accent-violet/12 text-accent-violet', text: 'text-accent-violet' },
  warning: { chip: 'bg-warning/12 text-warning', text: 'text-warning' },
};

const VALUE_CHIPS = [
  { icon: CheckCircle2, label: 'Role-based routing', tone: 'text-success' },
  { icon: CheckCircle2, label: 'Peer-to-peer workflows', tone: 'text-success' },
  { icon: Clock, label: 'Digital signatures (Coming soon)', tone: 'text-primary' },
  { icon: ShieldCheck, label: 'Policy-grounded AI (Coming soon)', tone: 'text-primary' },
];

export const Hero: React.FC = () => {
  const heroRef = useRef<HTMLElement>(null);
  const headlineRef = useRef<HTMLHeadingElement>(null);
  const underlineRef = useRef<SVGPathElement>(null);
  const ctaRef = useRef<HTMLAnchorElement>(null);

  const { mode } = useLayoutState();
  const { isSupported, isReducedMotion, tier } = usePerformanceTier();
  const show3D = isSupported && !isReducedMotion && tier !== 'static';

  const isWide = mode === 'wide' || mode === 'compact';

  // Orbit cards are placed at runtime so they can never overlap each other or
  // the mascot, at any viewport. (Hardcoded corner offsets used to collide.)
  const {
    containerRef: orbitRef,
    items: orbitPos,
    strategy: orbitStrategy,
  } = usePlaceInRect(ORBIT_CARDS, {
    seed: 1207,
    padding: 10,
    gap: 20,
    // keep the centre clear for the paper stack / mascot
    avoidRatio: [
      { x: 0.26, y: 0.20, width: 0.50, height: 0.46 }, // the 3D cascade
    ],
  });

  useEffect(() => {
    if (prefersReducedMotion()) return;

    const ctx = gsap.context(() => {
      // 1. Headline: line-mask reveal
      let split: SplitText | null = null;
      if (headlineRef.current) {
        split = new SplitText(headlineRef.current, {
          type: 'lines',
          mask: 'lines', // SplitText wraps each line so it can slide up behind a mask
          linesClass: 'lp-split-line',
        });
        gsap.from(split.lines, {
          yPercent: 115,
          opacity: 0,
          duration: 0.95,
          stagger: 0.085,
          ease: 'expo.out',
          delay: 0.1,
        });
      }

      // 2. Hand-drawn underline on the accent word
      if (underlineRef.current) {
        const len = underlineRef.current.getTotalLength();
        gsap.set(underlineRef.current, { strokeDasharray: len, strokeDashoffset: len });
        gsap.to(underlineRef.current, {
          strokeDashoffset: 0,
          duration: 1.1,
          ease: 'power2.out',
          delay: 0.75,
        });
      }

      // 3. Everything below the headline, staggered in
      gsap.from('[data-hero-stagger]', {
        y: 26,
        opacity: 0,
        duration: 0.7,
        stagger: 0.075,
        ease: 'power3.out',
        delay: 0.45,
      });

      // 4. Orbit cards float in, then drift
      gsap.fromTo(
        '[data-orbit-card]',
        { scale: 0.86, opacity: 0 },
        {
          scale: 1,
          opacity: 1,
          duration: 0.7,
          stagger: 0.09,
          ease: 'back.out(1.6)',
          delay: 0.9,
          clearProps: 'scale',
        }
      );

      gsap.utils.toArray<HTMLElement>('[data-orbit-card]').forEach((el, i) => {
        gsap.to(el, {
          y: i % 2 === 0 ? -9 : 9,
          duration: 3.2 + i * 0.35,
          ease: 'sine.inOut',
          repeat: -1,
          yoyo: true,
          delay: 1.4 + i * 0.2,
        });
      });

      return () => split?.revert();
    }, heroRef);

    return () => ctx.revert();
  }, []);

  // Magnetic primary CTA
  useEffect(() => {
    const el = ctaRef.current;
    if (!el || prefersReducedMotion()) return;

    const xTo = gsap.quickTo(el, 'x', { duration: 0.4, ease: 'power3.out' });
    const yTo = gsap.quickTo(el, 'y', { duration: 0.4, ease: 'power3.out' });

    const onMove = (e: MouseEvent) => {
      const r = el.getBoundingClientRect();
      xTo(Math.max(-12, Math.min(12, (e.clientX - r.left - r.width / 2) * 0.3)));
      yTo(Math.max(-12, Math.min(12, (e.clientY - r.top - r.height / 2) * 0.4)));
    };
    const onLeave = () => {
      xTo(0);
      yTo(0);
    };

    el.addEventListener('mousemove', onMove);
    el.addEventListener('mouseleave', onLeave);
    return () => {
      el.removeEventListener('mousemove', onMove);
      el.removeEventListener('mouseleave', onLeave);
    };
  }, []);

  return (
    <section
      id="hero"
      aria-labelledby="hero-heading"
      ref={heroRef}
      className="relative min-h-[min(100svh,920px)] pt-28 pb-6 lg:pb-10 bg-background text-foreground overflow-x-clip flex flex-col justify-between"
    >
      {/* One WebGL context for the whole hero; CSS aurora when 3D is unavailable */}
      <div className="absolute inset-0 z-0 pointer-events-none" aria-hidden="true">
        <AuroraGlow intensity="medium" />
        {show3D && (
          <Suspense fallback={null}>
            <HeroCanvas subjectX={isWide ? 2.9 : 0} subjectScale={isWide ? 0.62 : 0.5} />
          </Suspense>
        )}
      </div>

      {/* Text alternative for the decorative scene */}
      <span className="sr-only">
        An illustration of a stack of documents moving through review, with the DocFlow mascot.
      </span>

      <Container wide className="relative z-10 flex-1 flex flex-col justify-center">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          {/* ── Copy ───────────────────────────────────────────────────── */}
          <div className="lg:col-span-6 flex flex-col items-center lg:items-start text-center lg:text-left">
            <div
              data-hero-stagger
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full lp-glass text-primary lp-eyebrow mb-6"
            >
              <Sparkles size={14} />
              <span>{LANDING_CONTENT.brand.creatorCredit}</span>
            </div>

            <h1
              id="hero-heading" ref={headlineRef}
              className="lp-h1 text-foreground mb-6 max-w-[16ch]"
            >
              Paperwork, minus the{' '}
              <span className="relative inline-block">
                <span className="lp-accent-word">paper&nbsp;chase.</span>
                <svg
                  className="absolute -bottom-1 left-0 w-full h-3 overflow-visible pointer-events-none"
                  viewBox="0 0 240 12"
                  fill="none"
                  aria-hidden="true"
                  preserveAspectRatio="none"
                >
                  <defs>
                    <linearGradient id="lp-hero-underline" x1="0%" x2="100%">
                      <stop offset="0%" stopColor="var(--primary)" />
                      <stop offset="100%" stopColor="var(--chart-3)" />
                    </linearGradient>
                  </defs>
                  <path
                    ref={underlineRef}
                    d="M 4 8 Q 60 2 120 7 T 236 5"
                    style={{ stroke: 'url(#lp-hero-underline)' }}
                    strokeWidth="3.5"
                    strokeLinecap="round"
                  />
                </svg>
              </span>
            </h1>

            <p
              data-hero-stagger
              className="lp-body text-muted-foreground max-w-[54ch] mb-9"
            >
              {LANDING_CONTENT.brand.subhead}
            </p>

            <div
              data-hero-stagger
              className="flex flex-col sm:flex-row items-stretch sm:items-center justify-center lg:justify-start gap-3.5 mb-10 w-full sm:w-auto"
            >
              <a
                ref={ctaRef}
                href="/register"
                data-cursor="cta"
                className="lp-border-beam-container group inline-flex items-center justify-center gap-2 px-7 py-3.5 rounded-xl font-bold text-base active:scale-[0.97] transition-transform"
              >
                <span className="absolute inset-[1.5px] rounded-[inherit] bg-primary transition-colors group-hover:bg-primary-hover" />
                <span
                  className="absolute inset-[1.5px] rounded-[inherit] opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                  style={{ background: 'var(--sheen)' }}
                />
                <span className="relative z-10 text-primary-foreground">Get started</span>
                <ArrowRight
                  size={17}
                  className="relative z-10 text-primary-foreground transition-transform duration-300 group-hover:translate-x-1"
                />
              </a>

              <a
                href="#journey"
                data-cursor="link"
                className="lp-glass inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl text-foreground font-semibold text-base hover:-translate-y-0.5 active:scale-[0.97] transition-all duration-300"
              >
                See how it works
              </a>
            </div>

            <ul
              data-hero-stagger
              className="flex flex-wrap items-center justify-center lg:justify-start gap-2.5 pt-5 border-t border-border w-full"
            >
              {VALUE_CHIPS.map((chip) => (
                <li
                  key={chip.label}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg lp-glass text-muted-foreground font-medium hover:text-foreground transition-colors"
                  style={{ fontSize: 'var(--lp-text-eyebrow)', letterSpacing: 0, textTransform: 'none' }}
                >
                  <chip.icon size={14} className={chip.tone} />
                  <span>{chip.label}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* ── Scene column: runtime-placed orbit cards over the 3D ───── */}
          <div className="lg:col-span-6 relative">
            {/* 2D Docky layered beside the 3D cascade (quality gate: the
                procedural 3D mascot read as toy-like). He sits in his own
                strip, outside the placement box, so neither the scatter nor
                the grid fallback can ever land a card on him. */}
            <div className="absolute left-0 bottom-0 z-20 hidden sm:block pointer-events-none">
              <Docky size={160} expression="happy" accessory="pen" animated />
            </div>

            <div
              ref={orbitRef}
              data-orbit-strategy={orbitStrategy}
              className="relative w-full sm:w-[calc(100%-176px)] sm:ml-[176px] h-[min(68svh,560px)] min-h-[430px]"
            >
              {ORBIT_CARDS.map((card) => {
                const pos = orbitPos[card.id];
                const tone = TONE[card.tone];
                return (
                  <div
                    key={card.id}
                    data-orbit-card
                    data-place-id={card.id}
                    data-qa-nooverlap={card.id}
                    data-cursor="card"
                    data-cursor-label="Open"
                    className="absolute hidden sm:flex items-center gap-3 px-3.5 py-2.5 rounded-xl lp-glass lp-elev-2 w-[232px] select-none hover:-translate-y-1 transition-transform duration-300"
                    style={{
                      left: pos?.x ?? 0,
                      top: pos?.y ?? 0,
                      visibility: pos ? 'visible' : 'hidden',
                    }}
                  >
                    <span
                      className={`w-8 h-8 shrink-0 rounded-lg flex items-center justify-center ${tone.chip}`}
                    >
                      <card.icon size={15} />
                    </span>
                    <span className="min-w-0">
                      <span className="block font-heading font-bold text-foreground leading-tight text-[0.9375rem]">
                        {card.title}
                      </span>
                      <span className={`block ${tone.text} font-medium leading-tight text-[0.875rem]`}>
                        {card.meta}
                      </span>
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </Container>

      <TornDivider seed="A" direction="bottom" fillToken="var(--lp-section-deep)" className="relative z-10 mt-8" />
    </section>
  );
};

export default Hero;
