import React, { useState } from 'react';
import {
  CheckSquare,
  CheckCircle2,
  ShieldCheck,
  Bell,
  RefreshCw,
  FileText,
  Eye,
  RotateCcw,
  GitBranch,
} from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { Container } from './Container';
import { Docky, type DockyExpression, type DockyAccessory } from './Docky';
import { TornDivider } from './TornDivider';
import { IsoNetwork } from '../illustrations';

type DemoDecision = 'pending' | 'approved' | 'sent_back' | 'revoked';

export const Approvals: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'pending' | 'approved' | 'rejected'>('pending');
  const [demoDecision, setDemoDecision] = useState<DemoDecision>('pending');
  const [badgeCount, setBadgeCount] = useState(3);

  const handleDecision = (decision: DemoDecision) => {
    setDemoDecision(decision);
    if (decision === 'approved') {
      setBadgeCount((prev) => Math.max(1, prev - 1));
    } else if (decision === 'revoked') {
      setBadgeCount(3);
    }
  };

  const getDockyReaction = (): { expression: DockyExpression; accessory: DockyAccessory; note: string } => {
    switch (demoDecision) {
      case 'approved':
        return {
          expression: 'celebrating',
          accessory: 'stamp',
          note: 'Approved! Cryptographic digital signature stamped.',
        };
      case 'sent_back':
        return {
          expression: 'thinking',
          accessory: 'pen',
          note: 'Sent back! Revision Round 2 created without overwriting Version 1.',
        };
      case 'revoked':
        return {
          expression: 'worried',
          accessory: 'none',
          note: 'Approval revoked! Workflow held until re-approved.',
        };
      case 'pending':
      default:
        return {
          expression: 'neutral',
          accessory: 'glasses',
          note: 'Awaiting your action on PO-8492',
        };
    }
  };

  const dockyReaction = getDockyReaction();

  return (
    <section id="approvals" aria-labelledby="approvals-heading" className="relative py-20 sm:py-28 lp-section-surface">
      <Container wide>
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="lp-eyebrow text-primary px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/20 inline-block mb-3">
            {LANDING_CONTENT.approvals.eyebrow}
          </span>
          <h2 id="approvals-heading" className="lp-h2 text-foreground tracking-tight leading-tight">
            {LANDING_CONTENT.approvals.heading}
          </h2>
          <p className="lp-body text-muted-foreground mt-4 leading-relaxed max-w-2xl mx-auto">
            {LANDING_CONTENT.approvals.subheading}
          </p>
        </div>

        {/* ── Split Layout: Left Mock Approvals Portal / Right Feature Cards ── */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-16">
          {/* Left: Mock Approvals Portal Page (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div data-qa="card" className="lp-card lp-glass p-6 sm:p-8 rounded-3xl border border-border shadow-xl space-y-6">
              {/* App Shell Header */}
              <div className="flex items-center justify-between pb-4 border-b border-border">
                <div className="flex items-center gap-2">
                  <CheckSquare size={18} className="text-primary" />
                  <span className="font-heading font-bold text-base text-foreground">
                    Approvals Queue
                  </span>
                </div>

                {/* Tabs with Live Badge */}
                <div className="flex items-center gap-1 p-1 rounded-xl bg-secondary text-[0.8125rem]">
                  <button
                    type="button"
                    data-cursor="link" onClick={() => setActiveTab('pending')}
                    className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-colors ${
                      activeTab === 'pending'
                        ? 'bg-card text-foreground shadow-xs'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    <span>Pending</span>
                    <span className="w-5 h-5 rounded-full bg-primary text-primary-foreground text-[0.8125rem] font-bold flex items-center justify-center">
                      {badgeCount}
                    </span>
                  </button>

                  <button
                    type="button"
                    data-cursor="link" onClick={() => setActiveTab('approved')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                      activeTab === 'approved'
                        ? 'bg-card text-foreground shadow-xs'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    Approved
                  </button>

                  <button
                    type="button"
                    data-cursor="link" onClick={() => setActiveTab('rejected')}
                    className={`px-3 py-1.5 rounded-lg font-semibold transition-colors ${
                      activeTab === 'rejected'
                        ? 'bg-card text-foreground shadow-xs'
                        : 'text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    Rejected
                  </button>
                </div>
              </div>

              {/* 3 Document Rows */}
              <div className="space-y-3">
                {/* Row 1: Expanded / Interactive Demo Target */}
                <div data-qa="stamp-target" className="p-5 rounded-2xl border-2 border-primary/40 bg-card/90 shadow-[var(--lp-shadow-2)] space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <FileText size={16} className="text-primary" />
                        <h4 className="font-heading font-bold text-[0.9375rem] text-foreground">
                          Purchase Order PO-8492: Cloud Capacity Expansion
                        </h4>
                      </div>
                      <span className="text-[0.8125rem] text-muted-foreground mt-0.5 block">
                        Raised by Rahul Verma (Engineering Ops) • Amount: ₹1,85,000
                      </span>
                    </div>

                    {/* Current Stage Status Badge */}
                    <span
                      className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-[0.8125rem] font-bold shrink-0 self-start sm:self-auto ${
                        demoDecision === 'approved'
                          ? 'bg-success/15 text-success border border-success/30'
                          : demoDecision === 'sent_back'
                          ? 'bg-warning/15 text-warning border border-warning/30'
                          : demoDecision === 'revoked'
                          ? 'bg-accent-violet/15 text-accent-violet border border-accent-violet/30'
                          : 'bg-primary/10 text-primary border border-primary/25'
                      }`}
                    >
                      {demoDecision === 'approved' && <CheckCircle2 size={13} />}
                      {demoDecision === 'sent_back' && <RefreshCw size={13} />}
                      {demoDecision === 'revoked' && <RotateCcw size={13} />}
                      {demoDecision === 'pending' && <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />}
                      <span>
                        {demoDecision === 'approved'
                          ? 'Approved & Signed'
                          : demoDecision === 'sent_back'
                          ? 'Revision Round 2'
                          : demoDecision === 'revoked'
                          ? 'Approval Revoked'
                          : 'Awaiting Action'}
                      </span>
                    </span>
                  </div>

                  {/* Prior Approver Line */}
                  <div className="p-2.5 rounded-lg bg-secondary/40 border border-border text-[0.8125rem] text-muted-foreground flex items-center gap-2">
                    <CheckCircle2 size={14} className="text-success shrink-0" />
                    <span>
                      Prior sign-off: <strong className="text-foreground">Ananya Sen (Dept Admin)</strong> verified on Oct 27, 14:15 UTC.
                    </span>
                  </div>

                  {/* Docky Reaction Note inside Card */}
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-primary/5 border border-primary/20 text-[0.8125rem]">
                    <Docky
                      size={42}
                      expression={dockyReaction.expression}
                      accessory={dockyReaction.accessory}
                      animated={true}
                    />
                    <p className="text-foreground font-medium leading-relaxed">
                      {dockyReaction.note}
                    </p>
                  </div>

                  {/* Interactive Action Controls */}
                  <div className="pt-2 border-t border-border flex flex-wrap items-center justify-between gap-3">
                    <span className="text-[0.8125rem] text-muted-foreground font-semibold">
                      Test Decision Actions:
                    </span>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => handleDecision('approved')}
                        data-cursor="stamp"
                        data-cursor-label="Stamp"
                        aria-pressed={demoDecision === 'approved'}
                        className={`px-3.5 py-2 rounded-xl text-[0.8125rem] font-bold transition-all duration-300 active:scale-[0.96] ${
                          demoDecision === 'approved'
                            ? 'bg-success/20 text-success ring-1 ring-success/50 shadow-[var(--lp-shadow-1)]'
                            : 'bg-success/10 text-success hover:bg-success/20 hover:-translate-y-0.5'
                        }`}
                      >
                        Approve
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDecision('sent_back')}
                        data-cursor="link"
                        data-cursor-label="Send back"
                        aria-pressed={demoDecision === 'sent_back'}
                        className={`px-3.5 py-2 rounded-xl text-[0.8125rem] font-bold transition-all duration-300 active:scale-[0.96] ${
                          demoDecision === 'sent_back'
                            ? 'bg-warning/20 text-warning ring-1 ring-warning/50 shadow-[var(--lp-shadow-1)]'
                            : 'bg-warning/10 text-warning hover:bg-warning/20 hover:-translate-y-0.5'
                        }`}
                      >
                        Send Back
                      </button>
                      <button
                        type="button"
                        onClick={() => handleDecision('revoked')}
                        data-cursor="link"
                        data-cursor-label="Revoke"
                        aria-pressed={demoDecision === 'revoked'}
                        className={`px-3.5 py-2 rounded-xl text-[0.8125rem] font-bold transition-all duration-300 active:scale-[0.96] ${
                          demoDecision === 'revoked'
                            ? 'bg-accent-violet/20 text-accent-violet ring-1 ring-accent-violet/50 shadow-[var(--lp-shadow-1)]'
                            : 'bg-accent-violet/10 text-accent-violet hover:bg-accent-violet/20 hover:-translate-y-0.5'
                        }`}
                      >
                        Revoke
                      </button>
                    </div>
                  </div>
                </div>

                {/* Row 2: Standard Pending Item */}
                <div data-cursor="card" className="p-4 rounded-xl border border-border bg-card/60 flex items-center justify-between gap-4 text-[0.8125rem] hover:border-primary/40 hover:-translate-y-0.5 transition-all duration-300">
                  <div>
                    <h5 className="font-semibold text-foreground">Leave Request • Priya Sharma</h5>
                    <span className="text-muted-foreground">4 Days Casual Leave • Nov 04 – Nov 07</span>
                  </div>
                  <span className="px-2.5 py-1 rounded-md bg-secondary text-secondary-foreground font-medium">
                    Queued for HR
                  </span>
                </div>

                {/* Row 3: Standard Pending Item */}
                <div data-cursor="card" className="p-4 rounded-xl border border-border bg-card/60 flex items-center justify-between gap-4 text-[0.8125rem] hover:border-primary/40 hover:-translate-y-0.5 transition-all duration-300">
                  <div>
                    <h5 className="font-semibold text-foreground">Master Vendor NDA • SteelCore Ltd</h5>
                    <span className="text-muted-foreground">Standard Mutual Non-Disclosure Agreement</span>
                  </div>
                  <span className="px-2.5 py-1 rounded-md bg-secondary text-secondary-foreground font-medium">
                    Awaiting Legal
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Sticky Feature Explanations with 3D Routing Mesh (5 cols) */}
          <div className="lg:col-span-5 space-y-4">
            {/* 3D Isometric Routing Mesh Card */}
            <div data-qa="card" className="lp-card lp-glass p-5 rounded-2xl border border-primary/25 flex flex-col items-center text-center overflow-hidden">
              <div className="-my-2">
                <IsoNetwork size={180} animated={true} />
              </div>
              <div className="text-[0.8125rem] font-bold text-primary uppercase tracking-wider">
                Peer-to-Peer Routing Mesh
              </div>
              <p className="text-[0.8125rem] text-muted-foreground mt-1 max-w-xs">
                Role-aware dispatch routing requests directly between submitters, reviewers, and department leads.
              </p>
            </div>

            {LANDING_CONTENT.approvals.features.map((feature, idx) => (
              <div
                key={idx}
                data-qa="card"
                className="lp-card lp-glass p-5 sm:p-6 rounded-2xl border border-border hover:border-primary/40 transition-colors space-y-2"
              >
                <div className="flex items-center gap-2 text-primary font-heading font-bold text-[0.9375rem]">
                  {idx === 0 && <Eye size={16} />}
                  {idx === 1 && <RotateCcw size={16} />}
                  {idx === 2 && <GitBranch size={16} />}
                  {idx === 3 && <Bell size={16} />}
                  <span>{feature.title}</span>
                </div>
                <p className="text-[0.8125rem] sm:text-[0.9375rem] text-muted-foreground leading-relaxed">
                  {feature.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* ── Scenarios B & D Narrative Cards Beneath Split Layout ── */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Scenario B Card */}
          <div data-qa="card" className="lp-card lp-glass p-6 sm:p-8 rounded-2xl border border-border flex flex-col justify-between">
            <div className="space-y-3">
              <span className="text-[0.8125rem] font-bold uppercase tracking-wider text-warning px-2.5 py-0.5 rounded-full bg-warning/10 border border-warning/20 inline-block">
                Story Beat • Scenario B
              </span>
              <h4 className="font-heading font-bold text-base sm:text-lg text-foreground">
                Purchase Order Revision Loop
              </h4>
              <p className="text-[0.8125rem] sm:text-[0.9375rem] text-muted-foreground leading-relaxed">
                A team member raises a PO from a template. Finance spots a discrepancy and uses <strong>“Send Back”</strong> with an @mention comment. The submitter revises; a clean new version is created while the history of all earlier rounds is preserved without overwriting.
              </p>
            </div>
            <div className="pt-4 border-t border-border text-[0.8125rem] text-muted-foreground flex items-center gap-1.5">
              <CheckCircle2 size={13} className="text-success" />
              <span>Full revision lineage retained in audit log</span>
            </div>
          </div>

          {/* Scenario D Card */}
          <div data-qa="card" className="lp-card lp-glass p-6 sm:p-8 rounded-2xl border border-border flex flex-col justify-between">
            <div className="space-y-3">
              <span className="text-[0.8125rem] font-bold uppercase tracking-wider text-accent-violet px-2.5 py-0.5 rounded-full bg-accent-violet/10 border border-accent-violet/20 inline-block">
                Story Beat • Scenario D
              </span>
              <h4 className="font-heading font-bold text-base sm:text-lg text-foreground">
                Revoke & Recall Safety Net
              </h4>
              <p className="text-[0.8125rem] sm:text-[0.9375rem] text-muted-foreground leading-relaxed">
                A manager approves a requisition, then realizes a discrepancy and triggers <strong>“Revoke Approval”</strong>. The document continues through the workflow, but the platform prevents closure until the revoking reviewer re-approves.
              </p>
            </div>
            <div className="pt-4 border-t border-border text-[0.8125rem] text-muted-foreground flex items-center gap-1.5">
              <ShieldCheck size={13} className="text-primary" />
              <span>Prevents erroneous premature workflow closure</span>
            </div>
          </div>
        </div>
      </Container>

      {/* Torn Edge Transition to Signatures Section */}
      <div className="mt-16">
        <TornDivider seed="C" direction="bottom" fillToken="var(--lp-section-deep)" />
      </div>
    </section>
  );
};

export default Approvals;
