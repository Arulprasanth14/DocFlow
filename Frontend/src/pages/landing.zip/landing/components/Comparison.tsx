import React from 'react';
import {
  CheckCircle2,
  XCircle,
  Sparkles,
  Zap,
  Shield,
  Layers,
  FileCheck,
  Bot,
  Users,
} from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { Container } from './Container';
import { TornDivider } from './TornDivider';
import { Docky } from './Docky';

export const Comparison: React.FC = () => {
  const getIconForIndex = (idx: number) => {
    switch (idx) {
      case 0:
        return <Layers className="w-4 h-4 text-primary" />;
      case 1:
        return <FileCheck className="w-4 h-4 text-primary" />;
      case 2:
        return <Shield className="w-4 h-4 text-primary" />;
      case 3:
        return <Zap className="w-4 h-4 text-primary" />;
      case 4:
        return <Bot className="w-4 h-4 text-primary" />;
      case 5:
        return <Users className="w-4 h-4 text-primary" />;
      default:
        return <Sparkles className="w-4 h-4 text-primary" />;
    }
  };

  return (
    <section id="comparison" aria-labelledby="comparison-heading" className="relative lp-section-rhythm lp-section-deep overflow-x-clip">
      <Container data-qa="container">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-2 mb-3">
            <span className="lp-eyebrow px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary">
              {LANDING_CONTENT.comparison.eyebrow}
            </span>
          </div>
          <h2 id="comparison-heading" className="lp-h2 text-foreground mt-2">
            {LANDING_CONTENT.comparison.heading}
          </h2>
          <p className="lp-body text-muted-foreground mt-4">
            {LANDING_CONTENT.comparison.subheading}
          </p>

          <div className="mt-6 inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-[0.8125rem] font-semibold text-primary">
            <Sparkles size={14} className="text-primary" />
            <span>Only DocFlow combines all into a single cohesive platform</span>
          </div>
        </div>

        {/* Desktop Comparison Table (Hidden on small mobile) */}
        <div
          data-cursor="card" data-qa="card"
          className="hidden md:block rounded-3xl border border-border bg-card/90 backdrop-blur-xl shadow-xl overflow-hidden mb-12"
        >
          {/* Table Header */}
          <div className="grid grid-cols-12 border-b border-border bg-secondary/40 text-[0.8125rem] font-bold uppercase tracking-wider text-muted-foreground p-6">
            <div className="col-span-4 flex items-center gap-2">
              <span>Capability / Architecture</span>
            </div>
            <div className="col-span-4 text-muted-foreground">
              <span>Typical Workflow Tools</span>
            </div>
            <div className="col-span-4 text-primary flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-primary" />
              <span>DocFlow Platform</span>
            </div>
          </div>

          {/* Table Rows with generous padding & legible 15-16px text */}
          <div className="divide-y divide-border/60">
            {LANDING_CONTENT.comparison.rows.map((row, idx) => {
              const isHighlight = 'isHighlight' in row && Boolean(row.isHighlight);
              return (
                <div
                  key={idx}
                  className={`grid grid-cols-12 p-6 items-center transition-colors ${
                    isHighlight
                      ? 'bg-primary/[0.04] hover:bg-primary/[0.07]'
                      : 'hover:bg-secondary/30'
                  }`}
                >
                  {/* Capability Name */}
                  <div className="col-span-4 pr-6">
                    <div className="flex items-center gap-3 font-bold text-foreground text-[15px] sm:text-base">
                      <div className="w-8 h-8 rounded-xl bg-secondary flex items-center justify-center shrink-0">
                        {getIconForIndex(idx)}
                      </div>
                      <span>{row.capability}</span>
                    </div>
                  </div>

                  {/* Typical Tools */}
                  <div className="col-span-4 pr-6 text-muted-foreground flex items-start gap-2.5">
                    <XCircle className="w-4 h-4 text-destructive/80 shrink-0 mt-1" />
                    <span className="text-[0.9375rem] leading-relaxed">{row.typicalTools}</span>
                  </div>

                  {/* DocFlow */}
                  <div className="col-span-4 text-foreground flex items-start gap-2.5 font-medium">
                    <CheckCircle2 className="w-4 h-4 text-success shrink-0 mt-1" />
                    <div className="text-[0.9375rem] leading-relaxed">
                      <span className={isHighlight ? 'text-primary font-bold' : 'text-foreground'}>
                        {row.docFlow}
                      </span>
                      {isHighlight && (
                        <span className="ml-2 inline-block text-[0.8125rem] px-2 py-0.5 rounded-md bg-primary/10 text-primary border border-primary/20 font-semibold">
                          Key Differentiator
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Mobile Comparison Cards (Shown on small screens) */}
        <div className="md:hidden space-y-4 mb-12">
          {LANDING_CONTENT.comparison.rows.map((row, idx) => {
            const isHighlight = 'isHighlight' in row && Boolean(row.isHighlight);
            return (
              <div
                key={idx}
                data-qa="card"
                className={`p-6 rounded-2xl border ${
                  isHighlight
                    ? 'border-primary/40 bg-card shadow-md'
                    : 'border-border bg-card'
                }`}
              >
                <div className="flex items-center gap-2.5 mb-3">
                  {getIconForIndex(idx)}
                  <h3 className="font-bold text-foreground text-[0.9375rem]">{row.capability}</h3>
                </div>

                {/* DocFlow Advantage */}
                <div className="p-3.5 rounded-xl bg-success/5 border border-success/20 mb-3 text-[0.8125rem]">
                  <div className="flex items-center gap-1.5 text-success font-bold mb-1">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>DocFlow Advantage:</span>
                  </div>
                  <p className="text-foreground leading-relaxed">{row.docFlow}</p>
                </div>

                {/* Typical Limitation */}
                <div className="p-3.5 rounded-xl bg-destructive/5 border border-destructive/10 text-[0.8125rem]">
                  <div className="flex items-center gap-1.5 text-destructive font-medium mb-1">
                    <XCircle className="w-3.5 h-3.5" />
                    <span>Typical Tool Limitation:</span>
                  </div>
                  <p className="text-muted-foreground leading-relaxed">{row.typicalTools}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Mascot Banner Note */}
        <div
          data-cursor="card" data-qa="card"
          className="rounded-3xl border border-primary/20 bg-card/80 p-6 sm:p-8 flex flex-col sm:flex-row items-center gap-6 shadow-md"
        >
          <div className="shrink-0">
            <Docky size={76} expression="happy" accessory="pen" />
          </div>
          <div className="text-center sm:text-left">
            <h4 className="font-heading font-bold text-foreground text-base mb-1.5">
              All essential approval vectors united into one single pane of glass.
            </h4>
            <p className="text-[0.8125rem] sm:text-[0.9375rem] text-muted-foreground leading-relaxed">
              No stitching together disparate single-purpose form tools or separate signature portals. Every step from draft creation to verifiable document closure stays unified in DocFlow.
            </p>
          </div>
        </div>
      </Container>

      {/* Torn Edge Transition to Trust section */}
      <div className="mt-16 sm:mt-24">
        <TornDivider fillToken="var(--background)" direction="bottom" seed="C" />
      </div>
    </section>
  );
};

export default Comparison;
