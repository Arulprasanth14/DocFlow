import React, { useCallback, useEffect, useLayoutEffect, useRef, useState } from 'react';
import { layoutStore, useLayoutState } from '../hooks/useLayoutMode';

export interface FitStageProps {
  children: React.ReactNode;
  /** Design width the scene is composed at. Height is MEASURED, not declared. */
  designWidth?: number;
  /** Optional hint only; the real content height is measured at runtime. */
  designHeight?: number;
  /** Below this scale the scene refuses to pin and falls back to normal flow. */
  minScale?: number;
  align?: 'center' | 'top';
  className?: string;
  stageClassName?: string;
  onFit?: (info: { scale: number; pinned: boolean; contentHeight: number }) => void;
}

function readPx(name: string, fallback: number): number {
  if (typeof window === 'undefined') return fallback;
  const raw = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  const n = Number.parseFloat(raw);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

/**
 * FitStage — fits a scrollytelling scene inside the viewport without ever
 * clipping or shrinking text past the legibility floor.
 *
 * Three rules make this safe:
 *  1. Available HEIGHT comes from the viewport (100svh - navbar - safe padding),
 *     never from this component's own box. Measuring a box whose height this
 *     component also sets is a feedback loop that oscillates under a
 *     ResizeObserver.
 *  2. Content height is MEASURED at the design width (layout is unaffected by
 *     the scale transform), so a scene can never be scaled against a declared
 *     height that is smaller than what it actually contains.
 *  3. Pinning requires layoutStore.canPin (tier 'wide') AND scale >= minScale.
 *     The same gate drives the section's ScrollTrigger, so the two decisions
 *     cannot disagree. Below the gate the scene renders in normal flow at
 *     full size, and nothing is ever hidden behind `overflow: hidden`.
 */
export const FitStage: React.FC<FitStageProps> = ({
  children,
  designWidth = 1200,
  designHeight = 680,
  minScale = 0.75,
  align = 'center',
  className = '',
  stageClassName = '',
  onFit,
}) => {
  const outerRef = useRef<HTMLDivElement>(null);
  const innerRef = useRef<HTMLDivElement>(null);
  const onFitRef = useRef(onFit);
  onFitRef.current = onFit;

  const { canPin } = useLayoutState();
  const [fit, setFit] = useState({ scale: 1, pinned: false, contentHeight: designHeight });

  const measure = useCallback(() => {
    if (typeof window === 'undefined') return;

    const outer = outerRef.current;
    const inner = innerRef.current;
    if (!outer || !inner) return;

    const { canPin: mayPin, height: viewportH } = layoutStore.measure();

    if (!mayPin) {
      setFit((prev) =>
        prev.pinned || prev.scale !== 1
          ? { scale: 1, pinned: false, contentHeight: inner.offsetHeight }
          : prev
      );
      return;
    }

    const navH = readPx('--lp-nav-h', 72);
    const safe = readPx('--lp-safe', 24);

    // Width is parent-driven (w-full), so it is safe to measure.
    const availW = outer.clientWidth || window.innerWidth;
    const availH = Math.max(1, viewportH - navH - safe * 2);

    // The inner box keeps width:designWidth / height:auto in every state, and
    // a transform does not affect layout, so this height is scale-independent.
    const contentH = Math.max(1, inner.offsetHeight);

    const scale = Math.min(availW / designWidth, availH / contentH, 1);

    if (scale < minScale) {
      setFit((prev) =>
        prev.pinned || prev.scale !== 1 ? { scale: 1, pinned: false, contentHeight: contentH } : prev
      );
      return;
    }

    setFit((prev) =>
      Math.abs(prev.scale - scale) < 0.002 && prev.pinned && prev.contentHeight === contentH
        ? prev
        : { scale, pinned: true, contentHeight: contentH }
    );
  }, [designWidth, minScale]);

  useLayoutEffect(measure, [measure, canPin]);

  useEffect(() => {
    onFitRef.current?.(fit);
  }, [fit]);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    // Width of the outer box, and natural height of the content (fonts loading,
    // text rewrapping, images arriving) both change the required scale.
    const ro = new ResizeObserver(measure);
    if (outerRef.current) ro.observe(outerRef.current);
    if (innerRef.current) ro.observe(innerRef.current);

    const unsubscribe = layoutStore.subscribe(measure);
    document.fonts?.ready.then(measure).catch(() => {});

    return () => {
      ro.disconnect();
      unsubscribe();
    };
  }, [measure]);

  const { scale, pinned } = fit;

  return (
    <div
      ref={outerRef}
      data-lp-fit={pinned ? 'pinned' : 'flow'}
      className={`relative w-full ${
        pinned
          ? `flex justify-center ${align === 'top' ? 'items-start' : 'items-center'}`
          : 'block'
      } ${className}`}
      style={
        pinned
          ? { height: 'calc(100svh - var(--lp-nav-h) - var(--lp-safe))', overflow: 'visible' }
          : undefined
      }
    >
      <div
        ref={innerRef}
        data-qa-fit="true"
        data-qa-fit-scale={scale.toFixed(3)}
        /* Raises the nominal type floor so scale x 16px never renders under 12px. */
        data-lp-stage={pinned && scale < 1 ? 'scaled' : undefined}
        className={`${align === 'top' ? 'origin-top' : 'origin-center'} ${
          pinned ? 'shrink-0' : ''
        } ${stageClassName}`}
        style={
          pinned
            ? ({
                width: designWidth,
                transform: `scale(${scale})`,
                // Lets CSS raise the nominal type floor by exactly the amount
                // the scale takes away, instead of a blunt fixed bump.
                '--lp-scale': scale,
              } as React.CSSProperties)
            : { width: '100%' }
        }
      >
        {children}
      </div>
    </div>
  );
};

export default FitStage;
