import React, { useState, useEffect, useRef } from 'react';
import {
  CalendarDays,
  ReceiptText,
  CreditCard,
  FileSignature,
  Receipt,
  MailCheck,
  Check,
  Plus,
  Sparkles,
  Lock,
  Type,
  ListFilter,
  CheckCircle2,
} from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { Container } from './Container';
import { StatusChip } from './StatusChip';
import { SpotlightCard } from './SpotlightCard';
import { TornDivider } from './TornDivider';
import { IsoDocStack } from '../illustrations/IsoDocStack';
import { prefersReducedMotion } from '@/lib/motion';

export const DocumentTypes: React.FC = () => {
  const [typedText, setTypedText] = useState('');
  const [isAiDrafting, setIsAiDrafting] = useState(false);
  const teaserRef = useRef<HTMLDivElement>(null);

  const fullClauseText =
    'The Employee is entitled to 18 days of paid annual leave per calendar year, accruing on the first day of each calendar month. Unused leave may be carried forward up to a maximum of 5 business days upon departmental manager sign-off.';

  // Scroll into view trigger for Template Studio typing
  useEffect(() => {
    if (prefersReducedMotion()) {
      setTypedText(fullClauseText);
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          let i = 0;
          const timer = setInterval(() => {
            if (i <= fullClauseText.length) {
              setTypedText(fullClauseText.slice(0, i));
              i += 2;
            } else {
              clearInterval(timer);
            }
          }, 20);
          observer.disconnect();
        }
      },
      { threshold: 0.25 }
    );

    if (teaserRef.current) {
      observer.observe(teaserRef.current);
    }

    return () => observer.disconnect();
  }, [fullClauseText]);

  const handleAiDraft = () => {
    setIsAiDrafting(true);
    setTypedText('');
    let i = 0;
    const aiGeneratedClause =
      'Contract Renewal Clause: This Agreement automatically renews for successive 12-month periods unless either party delivers written notice at least 30 days prior. Cryptographic digital signatures are required for all amendments.';

    const timer = setInterval(() => {
      if (i <= aiGeneratedClause.length) {
        setTypedText(aiGeneratedClause.slice(0, i));
        i += 3;
      } else {
        clearInterval(timer);
        setIsAiDrafting(false);
      }
    }, 18);
  };

  const getDocIcon = (iconName: string) => {
    switch (iconName) {
      case 'CalendarDays':
        return <CalendarDays size={22} className="text-primary" />;
      case 'ReceiptText':
        return <ReceiptText size={22} className="text-warning" />;
      case 'CreditCard':
        return <CreditCard size={22} className="text-success" />;
      case 'FileSignature':
        return <FileSignature size={22} className="text-accent-violet" />;
      case 'Receipt':
        return <Receipt size={22} className="text-primary" />;
      case 'MailCheck':
        return <MailCheck size={22} className="text-primary" />;
      default:
        return <FileSignature size={22} className="text-primary" />;
    }
  };

  return (
    <section id="features" aria-labelledby="features-heading" className="relative py-20 sm:py-28 bg-background">
      <Container wide>
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="lp-eyebrow text-primary px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/20 inline-block mb-3">
            {LANDING_CONTENT.documentTypes.eyebrow}
          </span>
          <h2 id="features-heading" className="lp-h2 text-foreground tracking-tight leading-tight">
            {LANDING_CONTENT.documentTypes.heading}
          </h2>
          <p className="lp-body text-muted-foreground mt-4 leading-relaxed max-w-2xl mx-auto">
            {LANDING_CONTENT.documentTypes.subheading}
          </p>
        </div>

        {/* ── 3x2 Grid: Spotlight Glass Cards ── */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 mb-8">
          {LANDING_CONTENT.documentTypes.items.map((item) => (
            <SpotlightCard
              key={item.title}
              data-qa="card"
              data-cursor="card" className="lp-card lp-glass p-6 sm:p-8 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between mb-5">
                  <div className="w-12 h-12 rounded-2xl bg-secondary flex items-center justify-center shadow-xs">
                    {getDocIcon(item.icon)}
                  </div>
                  <span className="text-[0.8125rem] font-semibold px-2.5 py-1 rounded-full bg-secondary text-secondary-foreground border border-border/80">
                    {item.category}
                  </span>
                </div>

                <h3 className="font-heading font-bold text-lg text-foreground mb-2">
                  {item.title}
                </h3>
                <p className="text-[0.9375rem] text-muted-foreground leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-border flex items-center justify-between text-[0.8125rem] text-muted-foreground">
                <span className="font-medium">Standardized Workflow</span>
                <Check className="text-success" size={16} />
              </div>
            </SpotlightCard>
          ))}
        </div>

        {/* Subtle note about other supported workflows */}
        <div className="text-center text-[0.8125rem] sm:text-[0.9375rem] text-muted-foreground mb-16 max-w-2xl mx-auto">
          <p className="italic">{LANDING_CONTENT.documentTypes.moreTypesNote}</p>
        </div>

        {/* ── TEMPLATE STUDIO SHOWCASE ── */}
        <div
          ref={teaserRef}
          className="rounded-3xl border border-primary/25 bg-card/85 backdrop-blur-xl p-6 sm:p-10 shadow-xl relative overflow-hidden"
        >
          {/* Studio Header & Status Chip */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-border">
            <div className="flex items-start gap-4 sm:gap-5">
              <div className="hidden sm:block shrink-0 -mt-2">
                <IsoDocStack size={90} animated={true} />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[0.8125rem] font-bold uppercase tracking-wider text-primary">
                    {LANDING_CONTENT.documentTypes.templateStudio.badge}
                  </span>
                  <StatusChip
                    status={LANDING_CONTENT.documentTypes.templateStudio.status}
                    size="sm"
                  />
                </div>
                <h3 className="font-heading font-extrabold text-xl sm:text-2xl text-foreground">
                  {LANDING_CONTENT.documentTypes.templateStudio.title}
                </h3>
                <p className="text-[0.8125rem] sm:text-[0.9375rem] text-muted-foreground mt-1 max-w-xl">
                  {LANDING_CONTENT.documentTypes.templateStudio.description}
                </p>
              </div>
            </div>

            {/* AI Draft Synthesis Action Button */}
            <button
              data-cursor="link" type="button"
              onClick={handleAiDraft}
              disabled={isAiDrafting}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-accent-violet/10 text-accent-violet border border-accent-violet/30 hover:bg-accent-violet/20 font-semibold text-[0.8125rem] transition-all shadow-xs shrink-0 self-start md:self-auto cursor-pointer"
            >
              <Sparkles size={14} className={isAiDrafting ? 'animate-spin' : ''} />
              <span>{isAiDrafting ? 'Synthesizing...' : 'AI Draft Clause'}</span>
            </button>
          </div>

          {/* Interactive Editor Canvas & Dynamic Blanks Mockup */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6 items-start">
            {/* Main Document Canvas (8 cols) */}
            <div className="lg:col-span-8 rounded-2xl bg-background border border-border p-6 shadow-inner space-y-4">
              {/* Document Editor Toolbar */}
              <div className="flex items-center gap-2 pb-3 border-b border-border text-muted-foreground text-[0.8125rem] select-none">
                <span className="p-1.5 rounded-md hover:bg-muted font-bold">B</span>
                <span className="p-1.5 rounded-md hover:bg-muted italic">I</span>
                <span className="p-1.5 rounded-md hover:bg-muted underline">U</span>
                <span className="w-px h-4 bg-border mx-1" />
                <span className="flex items-center gap-1 px-2 py-1 rounded bg-secondary text-primary font-semibold text-[0.8125rem]">
                  <Type size={12} />
                  <span>Dynamic Blank</span>
                </span>
                <span className="flex items-center gap-1 px-2 py-1 rounded bg-muted text-foreground font-semibold text-[0.8125rem]">
                  <Lock size={12} />
                  <span>Locked Clause</span>
                </span>
              </div>

              {/* Document Editor Body */}
              <div className="space-y-4 font-sans text-[0.8125rem] sm:text-[0.9375rem] text-foreground leading-relaxed">
                <div className="flex items-center gap-2">
                  <span className="text-[0.8125rem] font-bold uppercase tracking-wider text-primary bg-primary/10 px-2 py-0.5 rounded">
                    Clause 4.1 • Standard Provision
                  </span>
                  <span className="text-[0.8125rem] text-muted-foreground flex items-center gap-1">
                    <Lock size={11} /> Locked by Admin
                  </span>
                </div>

                <div className="p-4 rounded-xl bg-card border border-border/70 font-sans leading-relaxed min-h-[96px] text-foreground">
                  <p>
                    {typedText}
                    <span className="inline-block w-1.5 h-4 bg-primary ml-1 animate-pulse align-middle" />
                  </p>
                </div>

                {/* Dynamic Blanks Row */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                  <div className="p-2.5 rounded-lg border border-primary/30 bg-primary/5 text-[0.8125rem]">
                    <span className="text-[0.8125rem] text-muted-foreground block">Blank field #1</span>
                    <strong className="text-foreground">Accrual Rate: Monthly</strong>
                  </div>
                  <div className="p-2.5 rounded-lg border border-primary/30 bg-primary/5 text-[0.8125rem]">
                    <span className="text-[0.8125rem] text-muted-foreground block">Blank field #2</span>
                    <strong className="text-foreground">Carryover: Max 5 Days</strong>
                  </div>
                  <div className="p-2.5 rounded-lg border border-primary/30 bg-primary/5 text-[0.8125rem]">
                    <span className="text-[0.8125rem] text-muted-foreground block">Blank field #3</span>
                    <strong className="text-foreground">Approver: Manager</strong>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Panel: Template Config & Fields (4 cols) */}
            <div className="lg:col-span-4 rounded-2xl bg-secondary/30 border border-border p-5 space-y-4">
              <div className="flex items-center justify-between text-[0.8125rem] font-heading font-bold text-foreground">
                <span className="flex items-center gap-1.5">
                  <ListFilter size={14} className="text-primary" />
                  <span>Configured Blanks</span>
                </span>
                <span className="text-[0.8125rem] text-primary font-bold">3 Fields Active</span>
              </div>

              <div className="space-y-2 text-[0.8125rem]">
                <div className="p-3 rounded-xl bg-card border border-border flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-foreground">Annual Allowance</p>
                    <span className="text-[0.8125rem] text-muted-foreground">Type: Numeric (Default: 18)</span>
                  </div>
                  <CheckCircle2 size={16} className="text-success" />
                </div>

                <div className="p-3 rounded-xl bg-card border border-border flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-foreground">Manager Sign-off</p>
                    <span className="text-[0.8125rem] text-muted-foreground">Condition: Required if {'>'} 3 days</span>
                  </div>
                  <CheckCircle2 size={16} className="text-success" />
                </div>

                <div className="p-3 rounded-xl bg-card border border-border flex items-center justify-between">
                  <div>
                    <p className="font-semibold text-foreground">HR Notification</p>
                    <span className="text-[0.8125rem] text-muted-foreground">Dispatch: In-app + Email</span>
                  </div>
                  <CheckCircle2 size={16} className="text-success" />
                </div>
              </div>

              <div className="pt-2">
                <button
                  data-cursor="link" type="button"
                  className="w-full py-2.5 rounded-xl border border-dashed border-primary/40 text-primary hover:bg-primary/5 font-semibold text-[0.8125rem] flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Plus size={14} />
                  <span>Add Dynamic Blank Field</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </Container>

      {/* Torn Edge Transition to Roles & Routing */}
      <div className="mt-16">
        <TornDivider seed="A" direction="bottom" fillToken="var(--lp-section-deep)" />
      </div>
    </section>
  );
};

export default DocumentTypes;
