import React, { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { CURSOR_DEFAULT_LABELS, type CursorKind } from '../lib/cursor';
import './custom-cursor.css';

const MAGNET_MAX = 12;      // px of pull on a [data-cursor="cta"] element
const IDLE_MS = 3000;       // stillness before the ring starts breathing
const STRETCH_MAX = 1.3;

/**
 * CustomCursor — branded, context-aware pointer for the landing page.
 *
 * One mounted instance; components only declare `data-cursor` (see lib/cursor).
 *
 * Design notes that matter:
 * - One persistent ring node MORPHS between states via a data attribute and CSS
 *   transitions. Rendering a different node per state would remount it, so it
 *   could never animate between states.
 * - Centring is done with GSAP's own xPercent/yPercent, never a CSS translate
 *   class: GSAP rebuilds `transform` from its internal cache and would discard
 *   a CSS -50% offset, leaving the cursor misaligned by half its size.
 * - `cursor: none` is applied to the landing root only AFTER this component has
 *   mounted and positioned itself, and is removed on unmount, so a failure can
 *   never leave the user without a pointer.
 * - Reduced motion keeps a plain follow: no stretch, breathing, particles or
 *   magnetism — but the cursor still works.
 */
export const CustomCursor: React.FC = () => {
  const layerRef = useRef<HTMLDivElement>(null);
  const ringWrapRef = useRef<HTMLDivElement>(null);
  const squashRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);
  const labelRef = useRef<HTMLSpanElement>(null);
  const coreWrapRef = useRef<HTMLDivElement>(null);
  const coreRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const fine = window.matchMedia('(hover: hover) and (pointer: fine)');
    if (!fine.matches) return; // touch / coarse pointer: native cursor only

    const layer = layerRef.current;
    const ringWrap = ringWrapRef.current;
    const squash = squashRef.current;
    const ring = ringRef.current;
    const label = labelRef.current;
    const coreWrap = coreWrapRef.current;
    const core = coreRef.current;
    if (!layer || !ringWrap || !squash || !ring || !label || !coreWrap || !core) return;

    const reduceQuery = window.matchMedia('(prefers-reduced-motion: reduce)');
    let reduced = reduceQuery.matches;

    const root = layer.closest('.landing-scope') as HTMLElement | null;

    gsap.set([ringWrap, coreWrap], { xPercent: -50, yPercent: -50, x: -100, y: -100 });
    gsap.set(layer, { autoAlpha: 0 });

    const coreX = gsap.quickTo(coreWrap, 'x', { duration: 0.08, ease: 'power3.out' });
    const coreY = gsap.quickTo(coreWrap, 'y', { duration: 0.08, ease: 'power3.out' });
    const ringX = gsap.quickTo(ringWrap, 'x', { duration: reduced ? 0.08 : 0.35, ease: 'power3.out' });
    const ringY = gsap.quickTo(ringWrap, 'y', { duration: reduced ? 0.08 : 0.35, ease: 'power3.out' });

    let mode: CursorKind = 'default';
    let visible = false;
    let shown = false;              // has the cursor ever been positioned?
    let prevX = 0;
    let prevY = 0;
    let lastX = 0;
    let lastY = 0;
    let idleId: number | undefined;
    let breathe: gsap.core.Tween | null = null;
    let settle: gsap.core.Tween | null = null;

    /* ── magnetism ────────────────────────────────────────────────────────── */
    let magnetEl: HTMLElement | null = null;
    let magnetX: ((v: number) => void) | null = null;
    let magnetY: ((v: number) => void) | null = null;

    const releaseMagnet = () => {
      if (magnetEl) gsap.to(magnetEl, { x: 0, y: 0, duration: 0.45, ease: 'elastic.out(1, 0.5)' });
      magnetEl = null;
      magnetX = null;
      magnetY = null;
    };

    const attachMagnet = (el: HTMLElement) => {
      if (magnetEl === el) return;
      releaseMagnet();
      if (reduced) return;
      magnetEl = el;
      magnetX = gsap.quickTo(el, 'x', { duration: 0.4, ease: 'power3.out' });
      magnetY = gsap.quickTo(el, 'y', { duration: 0.4, ease: 'power3.out' });
    };

    /* ── state ────────────────────────────────────────────────────────────── */
    const setMode = (next: CursorKind, text?: string, caretHeight?: number) => {
      if (next !== mode) {
        mode = next;
        ring.dataset.state = next;
        core.dataset.state = next;
        layer.dataset.state = next;
      }
      const resolved = text ?? CURSOR_DEFAULT_LABELS[next] ?? '';
      if (label.textContent !== resolved) label.textContent = resolved;
      label.dataset.visible = resolved ? 'true' : 'false';
      if (caretHeight) core.style.setProperty('--lp-caret-h', `${Math.round(caretHeight)}px`);
    };

    const isTextTarget = (el: HTMLElement) => {
      if (el.closest('[data-cursor="text"]')) return true;
      if (!el.closest('p, li, blockquote, h1, h2, h3, h4, dd, dt, figcaption')) return false;
      // Only when hovering real text, not the padding around it.
      return !el.closest('a, button, [role="button"], [data-cursor]');
    };

    const resolveTarget = (el: HTMLElement | null) => {
      if (!el) return setMode('default');

      if (
        el.matches('input, textarea, select') ||
        el.isContentEditable ||
        el.closest('input, textarea, select, [contenteditable="true"], [data-cursor="native"]')
      ) {
        releaseMagnet();
        return setMode('native');
      }

      const declared = el.closest<HTMLElement>('[data-cursor]');
      const kind = declared?.dataset.cursor as CursorKind | undefined;
      const text = declared?.dataset.cursorLabel;

      if (kind === 'cta' && declared) {
        attachMagnet(declared);
        return setMode('cta', text);
      }
      releaseMagnet();

      if (kind && kind !== 'default') return setMode(kind, text);
      if (el.closest('canvas')) return setMode('canvas', text);
      if (isTextTarget(el)) {
        const lh = Number.parseFloat(getComputedStyle(el).lineHeight);
        return setMode('text', '', Number.isFinite(lh) ? lh : 20);
      }
      if (el.closest('a, button, [role="button"], .cursor-pointer, summary')) {
        return setMode('link', text);
      }
      return setMode('default', text);
    };

    /* ── motion ───────────────────────────────────────────────────────────── */
    const stopBreathing = () => {
      if (breathe) {
        breathe.kill();
        breathe = null;
        gsap.to(ring, { scale: 1, duration: 0.3, ease: 'power2.out', overwrite: 'auto' });
      }
    };

    const startBreathing = () => {
      if (reduced || breathe || mode === 'native' || mode === 'text') return;
      breathe = gsap.to(ring, {
        scale: 1.08,
        duration: 1.4,
        ease: 'sine.inOut',
        repeat: -1,
        yoyo: true,
        overwrite: 'auto',
      });
    };

    const onMove = (e: MouseEvent) => {
      lastX = e.clientX;
      lastY = e.clientY;

      if (!shown) {
        gsap.set([ringWrap, coreWrap], { x: lastX, y: lastY });
        shown = true;
        prevX = lastX;
        prevY = lastY;
        // cursor: none only once we are definitely on screen and placed
        root?.setAttribute('data-cursor-active', 'true');
      }

      if (!visible) {
        visible = true;
        gsap.to(layer, { autoAlpha: 1, duration: 0.2, overwrite: 'auto' });
      }

      coreX(lastX);
      coreY(lastY);
      ringX(lastX);
      ringY(lastY);

      if (!reduced) {
        const dx = lastX - prevX;
        const dy = lastY - prevY;
        const speed = Math.hypot(dx, dy);

        if (speed > 3) {
          stopBreathing();
          const stretch = Math.min(STRETCH_MAX, 1 + speed * 0.012);
          settle?.kill();
          gsap.set(squash, {
            rotation: (Math.atan2(dy, dx) * 180) / Math.PI,
            scaleX: stretch,
            scaleY: 1 / stretch,
          });
          // Decay back to a circle when movement stops.
          settle = gsap.to(squash, {
            scaleX: 1,
            scaleY: 1,
            duration: 0.45,
            ease: 'power3.out',
            overwrite: 'auto',
          });
        }

        if (magnetX && magnetY && magnetEl) {
          const r = magnetEl.getBoundingClientRect();
          const pullX = lastX - (r.left + r.width / 2);
          const pullY = lastY - (r.top + r.height / 2);
          const dist = Math.hypot(pullX, pullY) || 1;
          const amount = Math.min(MAGNET_MAX, dist * 0.35);
          magnetX((pullX / dist) * amount);
          magnetY((pullY / dist) * amount);
        }
      }

      prevX = lastX;
      prevY = lastY;

      window.clearTimeout(idleId);
      idleId = window.setTimeout(startBreathing, IDLE_MS);

      resolveTarget(e.target as HTMLElement | null);
    };

    /* ── press feedback ───────────────────────────────────────────────────── */
    const ripple = () => {
      if (reduced || !layer) return;
      const el = document.createElement('span');
      el.className = 'lp-cursor-ripple';
      el.style.left = `${lastX}px`;
      el.style.top = `${lastY}px`;
      layer.appendChild(el);
      gsap.fromTo(
        el,
        { scale: 0.3, opacity: 0.55 },
        {
          scale: 2.4,
          opacity: 0,
          duration: 0.55,
          ease: 'power2.out',
          onComplete: () => el.remove(),
        }
      );
    };

    const paperBits = () => {
      if (reduced || !layer) return;
      const count = 6 + Math.floor(Math.random() * 5); // 6-10
      for (let i = 0; i < count; i++) {
        const bit = document.createElement('span');
        bit.className = 'lp-cursor-bit';
        bit.dataset.tone = String(i % 3);
        bit.style.left = `${lastX}px`;
        bit.style.top = `${lastY}px`;
        layer.appendChild(bit);

        const angle = (Math.PI * 2 * i) / count + Math.random() * 0.6;
        const dist = 26 + Math.random() * 30;
        gsap.fromTo(
          bit,
          { x: 0, y: 0, scale: 1, opacity: 1, rotation: 0 },
          {
            x: Math.cos(angle) * dist,
            y: Math.sin(angle) * dist + 14,
            rotation: (Math.random() - 0.5) * 220,
            scale: 0.4,
            opacity: 0,
            duration: 0.6 + Math.random() * 0.25,
            ease: 'power2.out',
            onComplete: () => bit.remove(),
          }
        );
      }
    };

    const onDown = () => {
      gsap.to(ring, { scale: 0.85, duration: 0.12, ease: 'power2.out', overwrite: 'auto' });
      if (mode === 'stamp') {
        gsap.to(squash, { scale: 0.88, duration: 0.09, ease: 'power2.in', overwrite: 'auto' });
      }
    };

    const onUp = () => {
      gsap.to(ring, { scale: 1, duration: 0.3, ease: 'power3.out', overwrite: 'auto' });
      if (mode === 'stamp') {
        gsap.to(squash, { scale: 1, duration: 0.35, ease: 'elastic.out(1, 0.45)', overwrite: 'auto' });
        paperBits();
      }
      ripple();
    };

    /* ── window enter / leave ─────────────────────────────────────────────── */
    const hide = () => {
      visible = false;
      stopBreathing();
      gsap.to(layer, { autoAlpha: 0, duration: 0.2, overwrite: 'auto' });
    };

    const onDocLeave = (e: MouseEvent) => {
      if (e.relatedTarget === null) hide();
    };

    const onBlur = () => hide();

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Tab') hide();
    };

    const onReduceChange = (e: MediaQueryListEvent) => {
      reduced = e.matches;
      if (reduced) {
        stopBreathing();
        settle?.kill();
        gsap.set(squash, { scaleX: 1, scaleY: 1, rotation: 0 });
        releaseMagnet();
      }
    };

    const onPointerTypeChange = () => {
      if (!fine.matches) {
        hide();
        root?.removeAttribute('data-cursor-active');
      }
    };

    window.addEventListener('mousemove', onMove, { passive: true });
    window.addEventListener('mousedown', onDown, { passive: true });
    window.addEventListener('mouseup', onUp, { passive: true });
    window.addEventListener('keydown', onKeyDown, { passive: true });
    window.addEventListener('blur', onBlur);
    document.addEventListener('mouseout', onDocLeave);
    reduceQuery.addEventListener('change', onReduceChange);
    fine.addEventListener('change', onPointerTypeChange);

    return () => {
      window.clearTimeout(idleId);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mousedown', onDown);
      window.removeEventListener('mouseup', onUp);
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('blur', onBlur);
      document.removeEventListener('mouseout', onDocLeave);
      reduceQuery.removeEventListener('change', onReduceChange);
      fine.removeEventListener('change', onPointerTypeChange);

      breathe?.kill();
      settle?.kill();
      releaseMagnet();
      gsap.killTweensOf([ringWrap, coreWrap, ring, squash, layer]);
      // Always give the pointer back.
      root?.removeAttribute('data-cursor-active');
      layer.querySelectorAll('.lp-cursor-ripple, .lp-cursor-bit').forEach((n) => n.remove());
    };
  }, []);

  return (
    <div ref={layerRef} className="lp-cursor-layer" data-state="default" aria-hidden="true">
      <div ref={ringWrapRef} className="lp-cursor-ringwrap">
        <div ref={squashRef} className="lp-cursor-squash">
          <div ref={ringRef} className="lp-cursor-ring" data-state="default" />
        </div>
        <span ref={labelRef} className="lp-cursor-chip" data-visible="false" />
      </div>
      <div ref={coreWrapRef} className="lp-cursor-corewrap">
        <div ref={coreRef} className="lp-cursor-core" data-state="default" />
      </div>
    </div>
  );
};

export default CustomCursor;
