import React, { useState } from 'react';
import { ChevronDown, HelpCircle, Sparkles, Mail } from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { Container } from './Container';
import { SpotlightCard } from './SpotlightCard';
import { Docky } from './Docky';
import { TornDivider } from './TornDivider';

export const Faq: React.FC = () => {
  const [openIndices, setOpenIndices] = useState<number[]>([0]); // First question open by default

  const toggleItem = (idx: number) => {
    setOpenIndices((prev) =>
      prev.includes(idx) ? prev.filter((i) => i !== idx) : [...prev, idx]
    );
  };

  return (
    <section id="faq" aria-labelledby="faq-heading" className="relative lp-section-rhythm lp-section-deep overflow-x-clip">
      <Container data-qa="container">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="flex items-center justify-center gap-2 mb-3">
            <span className="lp-eyebrow px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary">
              {LANDING_CONTENT.faq.eyebrow}
            </span>
          </div>
          <h2 id="faq-heading" className="lp-h2 text-foreground mt-2">
            {LANDING_CONTENT.faq.heading}
          </h2>
          <p className="lp-body text-muted-foreground mt-4">
            {LANDING_CONTENT.faq.subheading}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* FAQ Accordion List (8 columns) */}
          <div className="lg:col-span-8 space-y-3.5">
            {LANDING_CONTENT.faq.items.map((item, idx) => {
              const isOpen = openIndices.includes(idx);

              return (
                <div
                  key={idx}
                  data-qa="card"
                  className={`rounded-2xl lp-glass overflow-hidden transition-shadow duration-300 ${
                    isOpen ? 'lp-elev-2' : 'hover:lp-elev-2'
                  }`}
                >
                  <button
                    data-cursor="link" type="button"
                    onClick={() => toggleItem(idx)}
                    aria-expanded={isOpen}
                    aria-controls={`faq-answer-${idx}`}
                    id={`faq-question-${idx}`}
                    className="w-full text-left p-5 sm:p-6 flex items-center justify-between gap-4 select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-primary rounded-2xl cursor-pointer"
                  >
                    <span className="font-heading font-bold text-[0.9375rem] sm:text-base text-foreground flex items-center gap-3">
                      <span className="w-7 h-7 rounded-lg bg-primary/10 text-primary text-[0.8125rem] font-bold flex items-center justify-center shrink-0">
                        {String(idx + 1).padStart(2, '0')}
                      </span>
                      <span>{item.question}</span>
                    </span>
                    <div
                      className={`w-8 h-8 rounded-full bg-secondary flex items-center justify-center shrink-0 transition-transform duration-300 ${
                        isOpen ? 'rotate-180 bg-primary/10 text-primary' : 'text-muted-foreground'
                      }`}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </div>
                  </button>

                  {/* Accordion Expandable Content */}
                  <div
                    id={`faq-answer-${idx}`}
                    role="region"
                    aria-labelledby={`faq-question-${idx}`}
                    className={`grid transition-all duration-300 ease-in-out px-5 sm:px-6 ${
                      isOpen ? 'grid-rows-[1fr] pb-6 opacity-100' : 'grid-rows-[0fr] pb-0 opacity-0'
                    }`}
                  >
                    <div className="overflow-hidden">
                      <div className="pt-3 border-t border-border/60">
                        <p
                          className="lp-body text-muted-foreground transition-all duration-500 ease-out"
                          style={{
                            transform: isOpen ? 'translateY(0)' : 'translateY(8px)',
                            opacity: isOpen ? 1 : 0,
                          }}
                        >
                          {item.answer}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Sticky Side Card with Docky (4 columns) */}
          <div className="lg:col-span-4 space-y-6">
            <SpotlightCard
              data-qa="card"
              className="p-6 sm:p-8 rounded-3xl border border-primary/20 bg-card/90 backdrop-blur-xl text-center space-y-4 shadow-xl"
            >
              <div className="flex justify-center">
                <Docky size={92} expression="thinking" accessory="none" />
              </div>

              <div>
                <h3 className="font-heading font-bold text-base text-foreground">
                  Still have specific questions?
                </h3>
                <p className="text-[0.8125rem] text-muted-foreground mt-2 leading-relaxed">
                  Every company’s approval matrices and compliance needs are unique. We are happy to map out how DocFlow models your exact team hierarchy.
                </p>
              </div>

              <div className="pt-2">
                <a
                  href="mailto:demo@docflow.app"
                  className="inline-flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl bg-primary text-primary-foreground font-semibold text-[0.8125rem] transition-transform hover:scale-102 shadow-md shadow-primary/20"
                >
                  <Mail className="w-4 h-4" />
                  <span>Contact Product Specialist</span>
                </a>
              </div>

              <div className="flex items-center justify-center gap-2 pt-2 text-[0.8125rem] text-muted-foreground">
                <Sparkles className="w-3.5 h-3.5 text-primary" />
                <span>DocFlow Architecture Inquiries</span>
              </div>
            </SpotlightCard>

            {/* Tenant Privacy Note (Clean, no banned words) */}
            <div data-cursor="card" data-qa="card" className="p-5 rounded-2xl border border-border bg-card text-[0.8125rem] text-muted-foreground space-y-1.5 shadow-xs">
              <div className="flex items-center gap-2 font-semibold text-foreground">
                <HelpCircle className="w-4 h-4 text-primary" />
                <span>Tenant Privacy Commitment</span>
              </div>
              <p className="text-[0.8125rem] leading-relaxed">
                DocFlow does not use your internal contracts, financial requests, or correspondence to train public AI foundation models.
              </p>
            </div>
          </div>
        </div>
      </Container>

      {/* Torn Edge Transition to Final CTA */}
      <div className="mt-16 sm:mt-24">
        <TornDivider fillToken="var(--background)" direction="bottom" seed="B" />
      </div>
    </section>
  );
};

export default Faq;
