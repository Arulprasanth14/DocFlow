import React, { useEffect, useState } from 'react';

/**
 * ScrollProgress — Fixed top hairline reading bar
 * Indicates overall landing page scroll depth.
 */
export const ScrollProgress: React.FC = () => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const docHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (docHeight > 0) {
        setProgress(Math.min(1, Math.max(0, scrollY / docHeight)));
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div
      className="fixed top-0 left-0 right-0 h-[3px] bg-gradient-brand z-50 transform-origin-left pointer-events-none"
      style={{
        transform: `scaleX(${progress})`,
        transformOrigin: '0% 50%',
        boxShadow: '0 0 8px var(--primary)',
      }}
      aria-hidden="true"
    />
  );
};

export default ScrollProgress;
