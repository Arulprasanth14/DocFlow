import React, { useRef, useEffect, useState } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  FileEdit,
  Send,
  Users,
  CheckCircle2,
  Archive,
  Sparkles,
  ArrowRight,
  MessageSquare,
  RefreshCw,
  Stamp,
  Calendar,
  Search,
} from 'lucide-react';
import { LANDING_CONTENT } from '../content';
import { Container } from './Container';
import { Docky, type DockyExpression, type DockyAccessory } from './Docky';
import { TornDivider } from './TornDivider';
import { FitStage } from './FitStage';
import { layoutStore } from '../hooks/useLayoutMode';
import { landingStore, useJourneyProgress } from '../store';
import { prefersReducedMotion } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger);

export const Journey: React.FC = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const pinContainerRef = useRef<HTMLDivElement>(null);

  // Synchronized stage index from store.ts
  const { stageIndex, progress } = useJourneyProgress();
  const reducedMotion = prefersReducedMotion();
  const stages = LANDING_CONTENT.journey.stages;

  // Alternate sub-state for stage 3 (Decision: Approved vs Sent Back)
  const [decisionState, setDecisionState] = useState<'approved' | 'sent-back'>('approved');

  // Mascot accessory & emotion per stage
  const dockyConfigs: { expression: DockyExpression; accessory: DockyAccessory; caption: string }[] = [
    { expression: 'thinking', accessory: 'pen', caption: 'Stage 1: Authoring with dynamic blanks' },
    { expression: 'neutral', accessory: 'none', caption: 'Stage 2: Sealing version & auto-routing' },
    { expression: 'thinking', accessory: 'glasses', caption: 'Stage 3: Review queue & @tag chat evidence' },
    { expression: 'celebrating', accessory: 'stamp', caption: 'Stage 4: Verifiable approval stamp slammed' },
    { expression: 'happy', accessory: 'badge', caption: 'Stage 5: Permanent vault indexing & retention' },
  ];

  const currentDocky = dockyConfigs[stageIndex] || dockyConfigs[0];

  useEffect(() => {
    if (prefersReducedMotion()) return;

    // Same gate as FitStage: only the 'wide' tier may pin a scene.
    if (!layoutStore.measure().canPin) return;

    const ctx = gsap.context(() => {
      // 2. Master pinned ScrollTrigger with snap to stage labels
      const st = ScrollTrigger.create({
        trigger: sectionRef.current,
        pin: pinContainerRef.current,
        start: 'top top',
        end: '+=250%',
        scrub: 0.6,
        anticipatePin: 1,
        snap: {
          snapTo: 1 / (stages.length - 1),
          duration: 0.4,
          ease: 'power1.inOut',
        },
        onUpdate: (self) => {
          const p = self.progress;

          // Compute active stage index (0 to 4) and write to store
          const index = Math.min(stages.length - 1, Math.floor(p * stages.length));
          landingStore.setJourneyProgress(index, p);
        },
      });

      return () => st.kill();
    }, sectionRef);

    return () => ctx.revert();
  }, [stages.length]);

  const selectStage = (idx: number) => {
    landingStore.setJourneyProgress(idx, idx / (stages.length - 1));
  };

  return (
    <section
      id="journey"
      aria-labelledby="journey-heading"
      ref={sectionRef}
      className="relative py-16 lg:py-24 bg-background text-foreground overflow-x-clip"
    >
      <div ref={pinContainerRef} className="relative w-full flex flex-col justify-center">
        <FitStage designWidth={1280} designHeight={660}>
          <Container wide>
            {/* Section Header */}
            <div className="text-center max-w-3xl mx-auto mb-6 sm:mb-8">
              <span className="lp-eyebrow text-primary px-3.5 py-1.5 rounded-full bg-primary/10 border border-primary/20 inline-block mb-2">
                {LANDING_CONTENT.journey.eyebrow}
              </span>
              <h2 id="journey-heading" className="lp-h2 text-foreground tracking-tight leading-tight">
                {LANDING_CONTENT.journey.heading}
              </h2>
              <p className="lp-body text-muted-foreground mt-2 leading-relaxed max-w-2xl mx-auto text-[0.9375rem] sm:text-base">
                {LANDING_CONTENT.journey.subheading}
              </p>
            </div>

            {/* ── Desktop Pinned 2-Column Experience (min-height 500px) ── */}
            <div className="hidden lg:grid grid-cols-12 gap-8 items-start">
            {/* Left Column (5 cols): Vertical Stage List with Progress Line */}
            <div className="col-span-4 relative flex flex-col gap-4 pr-4">
              {/* Self-drawing rail. A scaled div rather than an SVG path: the
                  rail's height depends on the stage list, and a hardcoded path
                  length (it was `L 1 480`) cannot follow it. */}
              <div className="absolute left-[27px] top-5 bottom-5 w-0.5 bg-border rounded-full" aria-hidden="true" />
              <div
                className="absolute left-[27px] top-5 bottom-5 w-0.5 rounded-full origin-top"
                style={{
                  background: 'linear-gradient(var(--primary), var(--ring))',
                  transform: `scaleY(${progress})`,
                  transition: 'transform 0.45s var(--lp-ease-out)',
                }}
                aria-hidden="true"
              />

              {/* Docky rides the rail as it draws */}
              <div
                className="absolute left-[6px] z-20 pointer-events-none hidden xl:block"
                style={{
                  top: `calc(20px + ${progress} * (100% - 40px))`,
                  transform: 'translateY(-50%)',
                  transition: 'top 0.45s var(--lp-ease-out)',
                }}
                aria-hidden="true"
              >
                <Docky
                  size={42}
                  expression={currentDocky.expression}
                  accessory="none"
                  animated={!reducedMotion}
                />
              </div>

              {stages.map((stage, idx) => {
                const isActive = stageIndex === idx;
                const isPassed = stageIndex > idx;

                return (
                  <button
                    key={stage.id}
                    type="button"
                    onClick={() => selectStage(idx)}
                    data-cursor="link"
                    aria-current={isActive ? 'step' : undefined}
                    className={`relative z-10 flex items-start gap-4 p-4 rounded-2xl text-left transition-all duration-300 border active:scale-[0.99] ${
                      isActive
                        ? 'bg-card border-primary/50 shadow-lg shadow-primary/10 translate-x-1.5'
                        : isPassed
                        ? 'bg-card/70 border-border hover:border-primary/40'
                        : 'bg-transparent border-transparent hover:bg-card/40'
                    }`}
                  >
                    {/* Stage Number Orb */}
                    <div
                      className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-[0.8125rem] shrink-0 transition-all ${
                        isActive
                          ? 'bg-primary text-primary-foreground shadow-md shadow-primary/30 scale-105'
                          : isPassed
                          ? 'bg-success/15 text-success border border-success/30'
                          : 'bg-secondary text-muted-foreground border border-border'
                      }`}
                    >
                      {idx + 1}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="font-heading font-bold text-[0.9375rem] text-foreground">
                          {stage.name}
                        </span>
                        <span
                          className={`text-[0.8125rem] px-2 py-0.5 rounded-full ${
                            isActive
                              ? 'bg-primary/10 text-primary border border-primary/20'
                              : 'bg-secondary text-muted-foreground'
                          }`}
                        >
                          {stage.badge}
                        </span>
                      </div>
                      <p className="text-[0.8125rem] text-muted-foreground leading-relaxed">
                        {stage.summary}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Right Column (8 cols): The Rich Scene Panel (min-height 560px) */}
            <div className="col-span-8">
              <div className="rounded-3xl lp-glass lp-elev-3 p-6 sm:p-8 flex flex-col justify-between relative overflow-hidden">
                {/* ── Top Ribbon: Docky Traveling Along The Journey ── */}
                <div className="flex items-center justify-between pb-6 border-b border-border">
                  <div className="flex items-center gap-4">
                    <Docky
                      size={64}
                      expression={currentDocky.expression}
                      accessory={currentDocky.accessory}
                      animated={true}
                    />
                    <div>
                      <div className="text-[0.8125rem] font-bold text-primary uppercase tracking-wider">
                        {currentDocky.caption}
                      </div>
                      <div className="text-[0.9375rem] font-semibold text-foreground mt-0.5">
                        Interactive Scene Demonstration
                      </div>
                    </div>
                  </div>

                  <span className="text-[0.8125rem] text-muted-foreground px-3 py-1 rounded-full bg-secondary border border-border">
                    Step {stageIndex + 1} of 5
                  </span>
                </div>

                {/* ── SCENE 0: DRAFT ── */}
                {stageIndex === 0 && (
                  <div className="py-6 space-y-4 animate-in fade-in duration-300">
                    {/* Document Header */}
                    <div className="flex items-center justify-between p-4 rounded-xl bg-secondary/40 border border-border text-[0.8125rem]">
                      <div className="flex items-center gap-3">
                        <FileEdit className="text-primary" size={18} />
                        <div>
                          <p className="font-bold text-foreground text-[0.9375rem]">
                            Annual Leave & Out of Office Request
                          </p>
                          <span className="text-muted-foreground">Author: Priya Sharma • Dept: Engineering</span>
                        </div>
                      </div>
                      <span className="text-success text-[0.8125rem] flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-success animate-pulse" />
                        Autosaved to cloud
                      </span>
                    </div>

                    {/* Form Dynamic Blanks */}
                    <div className="grid grid-cols-2 gap-4 text-[0.8125rem]">
                      <div className="p-3.5 rounded-xl bg-secondary/30 border border-border space-y-1">
                        <label className="text-muted-foreground text-[0.8125rem]">Leave Classification</label>
                        <p className="font-semibold text-foreground">Casual Leave (Paid Time Off)</p>
                      </div>
                      <div className="p-3.5 rounded-xl bg-secondary/30 border border-border space-y-1">
                        <label className="text-muted-foreground text-[0.8125rem]">Duration / Balance</label>
                        <p className="font-semibold text-foreground">4 Days (6 remaining in Q4)</p>
                      </div>
                      <div className="p-3.5 rounded-xl bg-secondary/30 border border-border space-y-1">
                        <label className="text-muted-foreground text-[0.8125rem]">Start Date</label>
                        <p className="font-semibold text-foreground">Nov 04, 2026</p>
                      </div>
                      <div className="p-3.5 rounded-xl bg-secondary/30 border border-border space-y-1">
                        <label className="text-muted-foreground text-[0.8125rem]">End Date</label>
                        <p className="font-semibold text-foreground">Nov 07, 2026</p>
                      </div>
                    </div>

                    {/* AI Suggestion Bar */}
                    <div className="p-3.5 rounded-xl bg-accent-violet/10 border border-accent-violet/20 flex items-start gap-3 text-[0.8125rem]">
                      <Sparkles size={16} className="text-accent-violet shrink-0 mt-0.5" />
                      <p className="text-foreground/90 leading-relaxed">
                        <strong className="text-accent-violet font-semibold">Docky Assistant Suggestion:</strong> All team sprint deliverables for week 45 have coverage assigned to Ananya. Policy requires 3 days advance notice for leave {'>'} 3 days.
                      </p>
                    </div>

                    {/* Submit Button */}
                    <div className="pt-2 flex justify-end">
                      <button
                        type="button"
                        onClick={() => selectStage(1)}
                        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary text-primary-foreground font-bold text-[0.8125rem] shadow-md shadow-primary/25 hover:scale-102 transition-transform cursor-pointer"
                      >
                        <span>Submit for review</span>
                        <ArrowRight size={14} />
                      </button>
                    </div>
                  </div>
                )}

                {/* ── SCENE 1: SUBMITTED ── */}
                {stageIndex === 1 && (
                  <div className="py-6 space-y-5 animate-in fade-in duration-300">
                    <div className="p-4 rounded-xl bg-secondary/40 border border-border flex items-center justify-between text-[0.8125rem]">
                      <div className="flex items-center gap-3">
                        <Send className="text-primary" size={18} />
                        <div>
                          <p className="font-bold text-foreground text-[0.9375rem]">Handoff Dispatched</p>
                          <span className="text-muted-foreground">Checksum verified & sealed</span>
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-full bg-primary/10 text-primary border border-primary/20 text-[0.8125rem]">
                        Routing Active
                      </span>
                    </div>

                    {/* 3-Avatar Routing Chain Graphic */}
                    <div className="p-6 rounded-2xl bg-secondary/30 border border-border space-y-6">
                      <div className="text-[0.8125rem] text-muted-foreground uppercase tracking-wider">
                        Peer-to-Peer Routing Chain
                      </div>

                      <div className="flex items-center justify-between relative">
                        {/* Connecting line */}
                        <div className="absolute left-10 right-10 top-1/2 -translate-y-1/2 h-0.5 bg-gradient-to-r from-success via-primary to-border z-0" />

                        {/* Node 1: Submitter */}
                        <div className="relative z-10 flex flex-col items-center gap-2">
                          <div className="w-12 h-12 rounded-2xl bg-success/20 border-2 border-success flex items-center justify-center font-bold text-success text-[0.9375rem]">
                            PS
                          </div>
                          <span className="text-[0.8125rem] font-bold text-foreground">Priya S.</span>
                          <span className="text-[0.8125rem] text-success">Submitted</span>
                        </div>

                        {/* Node 2: Current Approver */}
                        <div className="relative z-10 flex flex-col items-center gap-2">
                          <div className="w-12 h-12 rounded-2xl bg-primary/20 border-2 border-primary flex items-center justify-center font-bold text-primary text-[0.9375rem] animate-pulse">
                            KR
                          </div>
                          <span className="text-[0.8125rem] font-bold text-foreground">Karthik R.</span>
                          <span className="text-[0.8125rem] text-primary">Assigned Reviewer</span>
                        </div>

                        {/* Node 3: HR Finalizer */}
                        <div className="relative z-10 flex flex-col items-center gap-2 opacity-70">
                          <div className="w-12 h-12 rounded-2xl bg-secondary border-2 border-border flex items-center justify-center font-bold text-muted-foreground text-[0.9375rem]">
                            SM
                          </div>
                          <span className="text-[0.8125rem] font-bold text-foreground">Sunita M.</span>
                          <span className="text-[0.8125rem] text-muted-foreground">HR Operations</span>
                        </div>
                      </div>
                    </div>

                    <p className="text-[0.8125rem] text-muted-foreground text-center">
                      Assigned reviewer received instant badge counter + email dispatch with full submission payload.
                    </p>
                  </div>
                )}

                {/* ── SCENE 2: PENDING ── */}
                {stageIndex === 2 && (
                  <div className="py-6 space-y-4 animate-in fade-in duration-300">
                    <div className="p-4 rounded-xl bg-secondary/40 border border-border flex items-center justify-between text-[0.8125rem]">
                      <div className="flex items-center gap-3">
                        <Users className="text-warning" size={18} />
                        <div>
                          <p className="font-bold text-foreground text-[0.9375rem]">Approvals Queue Review</p>
                          <span className="text-muted-foreground">Step 1 of 2: Manager Sign-off</span>
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-full bg-warning/10 text-warning border border-warning/20 text-[0.8125rem]">
                        Action Required
                      </span>
                    </div>

                    {/* Contextual Discussion & Comments Thread */}
                    <div className="p-4 rounded-xl bg-secondary/30 border border-border space-y-3 font-sans text-[0.8125rem]">
                      <div className="flex items-center justify-between text-muted-foreground text-[0.8125rem] pb-2 border-b border-border">
                        <span className="flex items-center gap-1.5 text-foreground font-semibold">
                          <MessageSquare size={13} className="text-primary" />
                          Discussion Evidence Log (ACID Audit Stored)
                        </span>
                        <span>2 messages</span>
                      </div>

                      <div className="space-y-2">
                        <div className="p-2.5 rounded-lg bg-card border border-border">
                          <div className="flex items-center justify-between text-[0.8125rem] text-muted-foreground mb-1">
                            <strong className="text-primary">Karthik R. (Manager)</strong>
                            <span>10:14 UTC</span>
                          </div>
                          <p className="text-foreground leading-relaxed">
                            @priya looks good! Did you re-assign sprint task TASK-402 to Ananya before departing?
                          </p>
                        </div>

                        <div className="p-2.5 rounded-lg bg-card border border-border">
                          <div className="flex items-center justify-between text-[0.8125rem] text-muted-foreground mb-1">
                            <strong className="text-success">Priya S. (Employee)</strong>
                            <span>10:18 UTC</span>
                          </div>
                          <p className="text-foreground leading-relaxed">
                            Yes! Coverage handoff completed and tickets are tagged.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Recall Guarantee Pill */}
                    <div className="p-3 rounded-lg bg-secondary/50 border border-border flex items-center justify-between text-[0.8125rem] text-muted-foreground">
                      <span className="flex items-center gap-1.5">
                        <RefreshCw size={13} className="text-accent-violet" />
                        <span>Revoke capability enabled: approver can recall decision if an error is noticed.</span>
                      </span>
                    </div>
                  </div>
                )}

                {/* ── SCENE 3: DECISION (STAMP SLAM & REVISIONS) ── */}
                {stageIndex === 3 && (
                  <div className="py-6 space-y-5 animate-in fade-in duration-300">
                    {/* View Switcher between Approved & Sent Back */}
                    <div className="flex items-center justify-center gap-2">
                      <button
                        type="button"
                        onClick={() => setDecisionState('approved')}
                        className={`px-4 py-1.5 rounded-xl text-[0.8125rem] font-bold transition-all cursor-pointer ${
                          decisionState === 'approved'
                            ? 'bg-success/20 text-success ring-1 ring-success/50 shadow-[var(--lp-shadow-1)]'
                            : 'bg-secondary text-muted-foreground hover:text-foreground'
                        }`}
                      >
                        Approved Decision
                      </button>
                      <button
                        type="button"
                        onClick={() => setDecisionState('sent-back')}
                        className={`px-4 py-1.5 rounded-xl text-[0.8125rem] font-bold transition-all cursor-pointer ${
                          decisionState === 'sent-back'
                            ? 'bg-warning/20 text-warning ring-1 ring-warning/50 shadow-[var(--lp-shadow-1)]'
                            : 'bg-secondary text-muted-foreground hover:text-foreground'
                        }`}
                      >
                        Sent Back (Revision Round 2)
                      </button>
                    </div>

                    {decisionState === 'approved' ? (
                      /* Approved Stamp Slam Display */
                      <div className="p-8 rounded-2xl bg-card border border-success/30 flex flex-col items-center justify-center text-center space-y-4 shadow-sm">
                        {/* Embossed Stamp Emblem */}
                        <div className="w-24 h-24 rounded-full border-4 border-dashed border-success flex flex-col items-center justify-center text-success rotate-[-8deg] shadow-lg shadow-success/20">
                          <Stamp size={28} />
                          <span className="text-[0.8125rem] font-black tracking-widest uppercase mt-1">
                            APPROVED
                          </span>
                        </div>

                        <div>
                          <h4 className="font-heading font-extrabold text-lg text-foreground">
                            Cryptographic Signature Verified
                          </h4>
                          <p className="text-[0.8125rem] text-muted-foreground mt-1">
                            Approver: <strong className="text-foreground">Karthik R. (Engineering Lead)</strong> • Signed 10:42:15 UTC
                          </p>
                        </div>

                        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-success/10 text-success border border-success/20 text-[0.8125rem]">
                          <CheckCircle2 size={13} />
                          <span>Tamper-evident record sealed</span>
                        </div>
                      </div>
                    ) : (
                      /* Sent Back Revision Display */
                      <div className="p-8 rounded-2xl bg-card border border-warning/30 flex flex-col items-center justify-center text-center space-y-4 shadow-sm">
                        <div className="w-24 h-24 rounded-full border-4 border-dashed border-warning flex flex-col items-center justify-center text-warning rotate-[-6deg]">
                          <RefreshCw size={28} />
                          <span className="text-[0.8125rem] font-black tracking-widest uppercase mt-1">
                            REVISION
                          </span>
                        </div>

                        <div>
                          <h4 className="font-heading font-extrabold text-lg text-foreground">
                            Sent Back for Handoff Revision
                          </h4>
                          <p className="text-[0.8125rem] text-muted-foreground mt-1 max-w-sm">
                            Submitter receives feedback and revision notes. Earlier versions stay permanently linked in history without being overwritten.
                          </p>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* ── SCENE 4: ARCHIVED ── */}
                {stageIndex === 4 && (
                  <div className="py-6 space-y-4 animate-in fade-in duration-300">
                    <div className="p-4 rounded-xl bg-secondary/40 border border-border flex items-center justify-between text-[0.8125rem]">
                      <div className="flex items-center gap-3">
                        <Archive className="text-accent-violet" size={18} />
                        <div>
                          <p className="font-bold text-foreground text-[0.9375rem]">Archived to Tenant Vault</p>
                          <span className="text-muted-foreground">Record ID: DOC-2026-LV-094</span>
                        </div>
                      </div>
                      <span className="px-2.5 py-1 rounded-full bg-accent-violet/10 text-accent-violet border border-accent-violet/20 text-[0.8125rem]">
                        7-Year Retention
                      </span>
                    </div>

                    {/* Audit Trail Sequence Table */}
                    <div className="p-4 rounded-xl bg-secondary/30 border border-border text-[0.8125rem] space-y-2.5">
                      <div className="flex justify-between text-muted-foreground pb-2 border-b border-border text-[0.8125rem]">
                        <span>Event Step</span>
                        <span>Actor • Time</span>
                      </div>
                      <div className="flex justify-between text-foreground">
                        <span>1. Draft created & submitted</span>
                        <span className="text-muted-foreground">Priya S. • 09:14 UTC</span>
                      </div>
                      <div className="flex justify-between text-foreground">
                        <span>2. Auto-routed to manager</span>
                        <span className="text-muted-foreground">Policy Engine • 09:14 UTC</span>
                      </div>
                      <div className="flex justify-between text-foreground">
                        <span>3. Decision approved & signed</span>
                        <span className="text-success font-bold">Karthik R. • 10:42 UTC</span>
                      </div>
                      <div className="flex justify-between text-foreground">
                        <span>4. HR confirmed & archived</span>
                        <span className="text-primary font-bold">Sunita M. • 11:05 UTC</span>
                      </div>
                    </div>

                    {/* Indexed for AI discovery */}
                    <div className="p-3.5 rounded-xl bg-secondary/40 border border-border flex items-center justify-between text-[0.8125rem] text-muted-foreground">
                      <span className="flex items-center gap-2">
                        <Search size={14} className="text-primary" />
                        <span className="text-foreground">Indexed for Instant Search & Docky Tenant Policy Q&A</span>
                      </span>
                      <span className="font-mono text-success font-bold">ACID Verified</span>
                    </div>
                  </div>
                )}

                {/* Bottom Navigation Controls inside Scene Panel */}
                <div className="pt-4 border-t border-border flex items-center justify-between text-[0.8125rem] text-muted-foreground">
                  <span>Scroll down to advance stages, or click stage tabs on the left.</span>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      disabled={stageIndex === 0}
                      onClick={() => selectStage(stageIndex - 1)}
                      className="px-3 py-1.5 rounded-lg bg-secondary hover:bg-secondary/80 disabled:opacity-30 disabled:pointer-events-none text-foreground font-medium transition-colors cursor-pointer"
                    >
                      Previous
                    </button>
                    <button
                      type="button"
                      disabled={stageIndex === stages.length - 1}
                      onClick={() => selectStage(stageIndex + 1)}
                      className="px-3 py-1.5 rounded-lg bg-primary hover:bg-primary-hover disabled:opacity-30 disabled:pointer-events-none text-primary-foreground font-semibold transition-colors cursor-pointer"
                    >
                      Next stage
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* ── Mobile Vertical Stacked View (< 1024px) ── */}
          <div className="lg:hidden grid grid-cols-1 md:grid-cols-2 gap-5">
            {stages.map((stage, idx) => (
              <div
                key={stage.id}
                data-cursor="card" className="p-6 rounded-2xl lp-glass space-y-3 hover:-translate-y-1 transition-transform duration-300"
              >
                <div className="flex items-center justify-between">
                  <span className="text-[0.8125rem] font-bold uppercase tracking-wider text-primary">
                    {stage.badge}
                  </span>
                  <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center font-bold text-[0.8125rem]">
                    {idx + 1}
                  </div>
                </div>
                <h3 className="text-lg font-bold text-foreground">{stage.name}</h3>
                <p className="text-[0.8125rem] text-muted-foreground leading-relaxed">{stage.summary}</p>
                <p className="text-[0.8125rem] text-muted-foreground/80">{stage.details}</p>
              </div>
            ))}
          </div>
        </Container>
      </FitStage>
    </div>

    {/* ── Scenario A Story Strip (In-Flow beneath Pinned Scene) ── */}
    <Container wide>
      <div className="mt-16 pt-10 border-t border-border">
        <div className="p-6 sm:p-8 rounded-2xl border border-primary/30 bg-card/90 backdrop-blur-md relative overflow-hidden">
          <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
            <div className="space-y-2 max-w-2xl">
              <div className="inline-flex items-center gap-2 text-[0.8125rem] font-bold text-primary uppercase tracking-wider">
                <Calendar size={14} />
                <span>{LANDING_CONTENT.journey.scenarioSpotlight.badge}</span>
              </div>
              <h4 className="font-heading font-bold text-lg text-foreground">
                {LANDING_CONTENT.journey.scenarioSpotlight.title}
              </h4>
              <p className="text-[0.8125rem] font-semibold text-primary/90">
                Flow: {LANDING_CONTENT.journey.scenarioSpotlight.flow}
              </p>
              <p className="text-[0.8125rem] sm:text-[0.9375rem] text-muted-foreground leading-relaxed">
                {LANDING_CONTENT.journey.scenarioSpotlight.story}
              </p>
            </div>

            <div className="shrink-0 flex items-center gap-3">
              <div className="text-center p-3 rounded-xl bg-secondary/50 border border-border min-w-[90px]">
                <div className="text-[0.8125rem] font-bold text-foreground">Priya</div>
                <div className="text-[0.8125rem] text-muted-foreground">Submits</div>
              </div>
              <ArrowRight size={16} className="text-primary shrink-0" />
              <div className="text-center p-3 rounded-xl bg-secondary/50 border border-border min-w-[90px]">
                <div className="text-[0.8125rem] font-bold text-foreground">Karthik</div>
                <div className="text-[0.8125rem] text-success font-semibold">Approves</div>
              </div>
              <ArrowRight size={16} className="text-primary shrink-0" />
              <div className="text-center p-3 rounded-xl bg-secondary/50 border border-border min-w-[90px]">
                <div className="text-[0.8125rem] font-bold text-foreground">HR Ops</div>
                <div className="text-[0.8125rem] text-primary font-semibold">Archived</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Container>

      {/* Torn Edge Transition to Document Types Section */}
      <div className="mt-14">
        <TornDivider seed="C" direction="bottom" fillToken="var(--background)" />
      </div>
    </section>
  );
};

export default Journey;
