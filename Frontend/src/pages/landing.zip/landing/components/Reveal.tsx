import React, { useRef } from 'react';
import { useReveal } from '../hooks/useReveal';

interface RevealProps extends React.HTMLAttributes<HTMLDivElement> {
  children: React.ReactNode;
  delay?: number;
  duration?: number;
  y?: number;
  stagger?: number;
  className?: string;
  as?: React.ElementType;
}

export const Reveal: React.FC<RevealProps> = ({
  children,
  delay = 0,
  duration = 0.8,
  y = 28,
  stagger = 0,
  className = '',
  as: Component = 'div',
  ...props
}) => {
  const ref = useRef<HTMLDivElement>(null);
  useReveal(ref, { delay, duration, y, stagger });

  return (
    <Component ref={ref} className={className} {...props}>
      {children}
    </Component>
  );
};

export default Reveal;

