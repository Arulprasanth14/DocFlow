import { useSyncExternalStore } from 'react';
import * as THREE from 'three';

/**
 * Token Resolver & 2D Canvas Color Normalizer
 * Single source of truth for extracting CSS variable colors at runtime,
 * normalizing hsl/oklch/var() strings to standard #rrggbb format,
 * and converting to THREE.Color for procedural 3D materials & shaders.
 */

let canvasCache: HTMLCanvasElement | null = null;
let ctxCache: CanvasRenderingContext2D | null = null;

function getCanvasCtx(): CanvasRenderingContext2D | null {
  if (typeof window === 'undefined') return null;
  if (!canvasCache) {
    canvasCache = document.createElement('canvas');
    canvasCache.width = 1;
    canvasCache.height = 1;
    ctxCache = canvasCache.getContext('2d', { willReadFrequently: true });
  }
  return ctxCache;
}

/**
 * Normalizes any CSS color (hex, rgb, rgba, hsl, oklch) to a standard #rrggbb hex string
 * via an in-memory Canvas 2D fillStyle round-trip.
 */
export function normalizeCssColor(colorStr: string, fallbackHex: string = '#0284C7'): string {
  if (typeof window === 'undefined') return fallbackHex;
  const ctx = getCanvasCtx();
  if (!ctx) return fallbackHex;

  try {
    ctx.fillStyle = '#000000';
    ctx.fillStyle = colorStr.trim();
    const computed = ctx.fillStyle;

    if (computed.startsWith('#')) {
      return computed;
    }

    // If browser returned rgb/rgba, parse into hex
    const match = computed.match(/rgba?\((\d+),\s*(\d+),\s*(\d+)/i);
    if (match) {
      const r = parseInt(match[1], 10).toString(16).padStart(2, '0');
      const g = parseInt(match[2], 10).toString(16).padStart(2, '0');
      const b = parseInt(match[3], 10).toString(16).padStart(2, '0');
      return `#${r}${g}${b}`;
    }

    return computed || fallbackHex;
  } catch {
    return fallbackHex;
  }
}

/**
 * Reads a CSS variable from document.documentElement and returns normalized #rrggbb
 */
export function getCssToken(varName: string, fallbackHex: string = '#0284C7'): string {
  if (typeof window === 'undefined') return fallbackHex;
  const raw = getComputedStyle(document.documentElement).getPropertyValue(varName).trim();
  if (!raw) return fallbackHex;
  return normalizeCssColor(raw, fallbackHex);
}

/**
 * Converts a CSS variable into a Three.js Color object
 */
export function getCssTokenAsThreeColor(varName: string, fallbackHex: string = '#0284C7'): THREE.Color {
  const hex = getCssToken(varName, fallbackHex);
  return new THREE.Color(hex);
}

/**
 * Subscribes to changes on the <html> element's dark mode class
 * using useSyncExternalStore for tear-free theme reactivity.
 */
function subscribeTheme(callback: () => void) {
  if (typeof window === 'undefined') return () => {};
  const observer = new MutationObserver((mutations) => {
    for (const m of mutations) {
      if (m.type === 'attributes' && m.attributeName === 'class') {
        callback();
      }
    }
  });

  observer.observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['class'],
  });

  return () => observer.disconnect();
}

function getThemeSnapshot(): boolean {
  if (typeof window === 'undefined') return false;
  return document.documentElement.classList.contains('dark');
}

/**
 * Hook to consume live theme state and resolved token values
 * without triggering canvas remounts.
 */
export function useThemeTokenSnapshot() {
  const isDark = useSyncExternalStore(subscribeTheme, getThemeSnapshot, () => false);

  const tokens = {
    isDark,
    background: getCssToken('--background', isDark ? '#070B14' : '#FAF8F2'),
    foreground: getCssToken('--foreground', isDark ? '#E6EDF7' : '#0B1B33'),
    card: getCssToken('--card', isDark ? '#0E1626' : '#FFFFFF'),
    cardSolid: getCssToken('--card-solid', isDark ? '#0E1626' : '#FFFFFF'),
    primary: getCssToken('--primary', isDark ? '#38BDF8' : '#0369A1'),
    secondary: getCssToken('--secondary', isDark ? '#121B2E' : '#E8F4FD'),
    mutedForeground: getCssToken('--muted-foreground', isDark ? '#94A3B8' : '#5B6B82'),
    border: getCssToken('--border', isDark ? '#1E293B' : '#E2E8F0'),
    accentViolet: getCssToken('--accent-violet', isDark ? '#A78BFA' : '#7C3AED'),
  };

  return tokens;
}

