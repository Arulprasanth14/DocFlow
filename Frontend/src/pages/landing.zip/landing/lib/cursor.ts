/**
 * Cursor helper — components declare intent with data attributes only; all
 * cursor behaviour lives in <CustomCursor />. There is no per-component
 * cursor logic anywhere else on the landing page.
 *
 *   <a {...cursorProps('cta')}>Get started</a>
 *   <div {...cursorProps('card', 'Open')}>…</div>
 */

export type CursorKind =
  | 'default'
  | 'link'
  | 'cta'
  | 'card'
  | 'stamp'
  | 'drag'
  | 'canvas'
  | 'text'
  | 'native';

export interface CursorAttributes {
  'data-cursor': CursorKind;
  'data-cursor-label'?: string;
}

export function cursorProps(kind: CursorKind, label?: string): CursorAttributes {
  return label ? { 'data-cursor': kind, 'data-cursor-label': label } : { 'data-cursor': kind };
}

/** Default label shown in the ring chip when a component gives none. */
export const CURSOR_DEFAULT_LABELS: Partial<Record<CursorKind, string>> = {
  card: 'View',
  drag: 'Drag',
  canvas: 'Move',
  stamp: 'Stamp',
};
