/**
 * Lightweight seeded noise & procedural jagged path generator for TornDivider.
 * Produces deterministic, organic torn-paper edges with micro-notches.
 */

export function createRng(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

/**
 * 1D interpolated value noise
 */
export function noise1D(x: number, seed: number): number {
  const i = Math.floor(x);
  const f = x - i;
  const u = f * f * (3 - 2 * f);

  const rng1 = createRng(seed + i * 374761393);
  const rng2 = createRng(seed + (i + 1) * 374761393);

  const a = rng1();
  const b = rng2();

  return a * (1 - u) + b * u;
}

/**
 * Fractal Brownian Motion (fBm) with 3 octaves
 */
export function fbm1D(
  x: number,
  seed: number,
  octaves = 3,
  lacunarity = 2.0,
  gain = 0.5
): number {
  let total = 0;
  let frequency = 1.0;
  let amplitude = 1.0;
  let maxValue = 0;

  for (let i = 0; i < octaves; i++) {
    total += noise1D(x * frequency, seed + i * 1013) * amplitude;
    maxValue += amplitude;
    frequency *= lacunarity;
    amplitude *= gain;
  }

  return total / maxValue;
}

export interface TornPoint {
  x: number;
  y: number;
}

/**
 * Generates SVG path strings for a realistic torn paper edge across `width`.
 * Height of canvas is typically 56-64px.
 * Returns:
 * - `silhouetteD`: polygon filling from the torn edge down to canvas bottom (height)
 * - `fiberBandD`: ribbon polygon (3-5px width) representing the exposed torn paper pulp core
 */
export function generateTornEdge(
  width = 1440,
  baseY = 28,
  amplitude = 12,
  seed = 42,
  steps = 160,
  canvasHeight = 56
): { silhouetteD: string; fiberBandD: string } {
  const rng = createRng(seed);
  const stepX = width / steps;
  const points: TornPoint[] = [];
  const fiberPoints: TornPoint[] = [];

  for (let i = 0; i <= steps; i++) {
    const x = i * stepX;
    const nx = x / 55;
    // Multi-octave displacement (-0.5 to +0.5)
    let displacement = (fbm1D(nx, seed, 3, 2.1, 0.45) - 0.5) * amplitude * 2;

    // Organic micro-notches (torn fiber catch)
    if (rng() < 0.09 && i > 2 && i < steps - 2) {
      displacement += (rng() > 0.5 ? 1 : -1) * (amplitude * 0.4);
    }

    const y = baseY + displacement;
    points.push({ x: Number(x.toFixed(1)), y: Number(y.toFixed(1)) });
    // Exposed pulp core sits 3-4px above the clean break
    fiberPoints.push({ x: Number(x.toFixed(1)), y: Number((y - 3.8).toFixed(1)) });
  }

  // 1. Silhouette path: from torn line downwards to fill the bottom section
  let silhouetteD = `M 0 ${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    silhouetteD += ` L ${points[i].x} ${points[i].y}`;
  }
  silhouetteD += ` L ${width} ${canvasHeight} L 0 ${canvasHeight} Z`;

  // 2. Paper fiber pulp band: ribbon between fiberPoints and points
  let fiberBandD = `M ${points[0].x} ${points[0].y}`;
  for (let i = 1; i < points.length; i++) {
    fiberBandD += ` L ${points[i].x} ${points[i].y}`;
  }
  for (let i = fiberPoints.length - 1; i >= 0; i--) {
    fiberBandD += ` L ${fiberPoints[i].x} ${fiberPoints[i].y}`;
  }
  fiberBandD += ' Z';

  return { silhouetteD, fiberBandD };
}
