/**
 * placeInRect — seeded scatter placement with collision relaxation.
 *
 * Places scattered / orbiting items (Problem chaos cards, hero orbit chips,
 * floating badges) so they never overlap each other, never enter an avoid zone
 * (headings, CTAs, the mascot) and never cross the container edge.
 *
 * Deterministic for a given (items, rect, seed), recalculated by the caller
 * whenever the container resizes — see usePlaceInRect.
 *
 * If relaxation cannot separate everything (container too small for the item
 * set), it reports ok:false and returns a tidy grid instead of a messy pile.
 */

export interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

export type Quadrant =
  | 'top-left'
  | 'top-right'
  | 'bottom-left'
  | 'bottom-right'
  | 'mid-left'
  | 'mid-right';

export interface PlacedItemInput {
  id: string;
  width: number;
  height: number;
  preferredQuadrant?: Quadrant;
}

export interface PlacedItemOutput {
  id: string;
  x: number;
  y: number;
  width: number;
  height: number;
  /** Percentages kept for callers that position with left/top percentages. */
  leftPct: string;
  topPct: string;
}

export interface PlaceInRectOptions {
  padding?: number;
  gap?: number;
  avoid?: Rect[];
  maxIterations?: number;
  seed?: number;
}

export interface PlaceInRectResult {
  items: Record<string, PlacedItemOutput>;
  /** false when the scatter failed and the tidy-grid fallback was used. */
  ok: boolean;
  strategy: 'scatter' | 'grid';
}

/* Seeded PRNG (Lehmer / Park-Miller) so layouts are stable across renders. */
function createPrng(seed = 42) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return () => {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

function overlaps(a: Rect, b: Rect, gap: number): boolean {
  return (
    a.x < b.x + b.width + gap &&
    a.x + a.width + gap > b.x &&
    a.y < b.y + b.height + gap &&
    a.y + a.height + gap > b.y
  );
}

function toOutput(positions: (Rect & { id: string })[], W: number, H: number) {
  const items: Record<string, PlacedItemOutput> = {};
  for (const p of positions) {
    items[p.id] = {
      id: p.id,
      x: Math.round(p.x),
      y: Math.round(p.y),
      width: p.width,
      height: p.height,
      leftPct: `${((p.x / W) * 100).toFixed(3)}%`,
      topPct: `${((p.y / H) * 100).toFixed(3)}%`,
    };
  }
  return items;
}

/** Evenly spaced rows/columns that are guaranteed not to overlap. */
function tidyGrid(
  items: PlacedItemInput[],
  W: number,
  H: number,
  padding: number,
  gap: number
): (Rect & { id: string })[] {
  const maxItemW = Math.max(...items.map((i) => i.width), 1);
  const maxItemH = Math.max(...items.map((i) => i.height), 1);
  const usableW = Math.max(1, W - padding * 2);
  const cols = Math.max(1, Math.min(items.length, Math.floor((usableW + gap) / (maxItemW + gap))));
  const rows = Math.ceil(items.length / cols);
  const cellW = usableW / cols;
  const cellH = Math.max(maxItemH + gap, (H - padding * 2) / rows);

  return items.map((item, idx) => {
    const col = idx % cols;
    const row = Math.floor(idx / cols);
    return {
      id: item.id,
      width: item.width,
      height: item.height,
      x: padding + col * cellW + Math.max(0, (cellW - gap - item.width) / 2),
      y: padding + row * cellH,
    };
  });
}

export function placeInRectDetailed(
  items: PlacedItemInput[],
  container: { width: number; height: number },
  options: PlaceInRectOptions = {}
): PlaceInRectResult {
  const { padding = 16, gap = 14, avoid = [], maxIterations = 160, seed = 1234 } = options;
  const rand = createPrng(seed);

  const W = Math.max(1, container.width);
  const H = Math.max(1, container.height);

  const clampX = (x: number, w: number) => Math.min(W - w - padding, Math.max(padding, x));
  const clampY = (y: number, h: number) => Math.min(H - h - padding, Math.max(padding, y));

  const halfW = W / 2;
  const halfH = H / 2;

  const positions: (Rect & { id: string })[] = items.map((item, idx) => {
    const quad: Quadrant = item.preferredQuadrant ?? (idx % 2 === 0 ? 'top-left' : 'top-right');
    const leftBand = () => padding + rand() * Math.max(10, halfW - item.width - padding);
    const rightBand = () => halfW + rand() * Math.max(10, halfW - item.width - padding);

    let x: number;
    let y: number;

    switch (quad) {
      case 'top-left':
        x = leftBand();
        y = padding + rand() * Math.max(10, halfH * 0.7 - item.height);
        break;
      case 'top-right':
        x = rightBand();
        y = padding + rand() * Math.max(10, halfH * 0.7 - item.height);
        break;
      case 'mid-left':
        x = leftBand();
        y = halfH * 0.35 + rand() * Math.max(10, halfH * 0.5 - item.height);
        break;
      case 'mid-right':
        x = rightBand();
        y = halfH * 0.35 + rand() * Math.max(10, halfH * 0.5 - item.height);
        break;
      case 'bottom-left':
        x = leftBand();
        y = halfH + rand() * Math.max(10, halfH - item.height - padding);
        break;
      case 'bottom-right':
      default:
        x = rightBand();
        y = halfH + rand() * Math.max(10, halfH - item.height - padding);
        break;
    }

    return {
      id: item.id,
      width: item.width,
      height: item.height,
      x: clampX(x, item.width),
      y: clampY(y, item.height),
    };
  });

  for (let iter = 0; iter < maxIterations; iter++) {
    let moved = false;
    // Push decays so the system settles instead of jittering between two states.
    const push = 12 * (1 - iter / maxIterations) + 2;

    for (const pos of positions) {
      for (const zone of avoid) {
        if (!overlaps(pos, zone, gap)) continue;
        moved = true;
        const dx = pos.x + pos.width / 2 - (zone.x + zone.width / 2);
        const dy = pos.y + pos.height / 2 - (zone.y + zone.height / 2);
        const dist = Math.hypot(dx, dy) || 1;
        pos.x += (dx / dist) * push * 1.4;
        pos.y += (dy / dist) * push * 1.4;
      }
    }

    for (let i = 0; i < positions.length; i++) {
      for (let j = i + 1; j < positions.length; j++) {
        const a = positions[i];
        const b = positions[j];
        if (!overlaps(a, b, gap)) continue;
        moved = true;

        let dx = b.x + b.width / 2 - (a.x + a.width / 2);
        let dy = b.y + b.height / 2 - (a.y + a.height / 2);
        if (Math.abs(dx) < 0.1 && Math.abs(dy) < 0.1) {
          dx = rand() - 0.5;
          dy = rand() - 0.5;
        }
        const dist = Math.hypot(dx, dy) || 1;
        a.x -= (dx / dist) * push;
        a.y -= (dy / dist) * push;
        b.x += (dx / dist) * push;
        b.y += (dy / dist) * push;
      }
    }

    for (const pos of positions) {
      pos.x = clampX(pos.x, pos.width);
      pos.y = clampY(pos.y, pos.height);
    }

    if (!moved) break;
  }

  // Verify: anything still overlapping (or an item too big for the box) means
  // the scatter failed and a tidy grid is the honest answer.
  let ok = true;
  for (let i = 0; i < positions.length && ok; i++) {
    const a = positions[i];
    if (a.width + padding * 2 > W || a.height + padding * 2 > H) ok = false;
    for (let j = i + 1; j < positions.length && ok; j++) {
      if (overlaps(a, positions[j], Math.min(gap, 6))) ok = false;
    }
    for (const zone of avoid) {
      if (overlaps(a, zone, 2)) ok = false;
    }
  }

  if (ok) {
    return { items: toOutput(positions, W, H), ok: true, strategy: 'scatter' };
  }

  return {
    items: toOutput(tidyGrid(items, W, H, padding, gap), W, H),
    ok: false,
    strategy: 'grid',
  };
}

/** Back-compatible shape: just the placement map. */
export function placeInRect(
  items: PlacedItemInput[],
  container: { width: number; height: number },
  options: PlaceInRectOptions = {}
): Record<string, PlacedItemOutput> {
  return placeInRectDetailed(items, container, options).items;
}

export default placeInRect;
