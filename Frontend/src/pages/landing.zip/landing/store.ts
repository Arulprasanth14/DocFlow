/**
 * DocFlow Landing Store — Single Source of Truth
 * Implemented using React's native useSyncExternalStore (0 kB external bundle).
 * Synchronizes activeSectionId, journeyStageIndex, and journeyProgress across
 * the Lifecycle Tracker, Navbar, ScrollProgressBar, and Journey scene.
 */

import { useSyncExternalStore } from 'react';

export interface LandingState {
  activeSectionId: string;
  journeyStageIndex: number;
  journeyProgress: number; // 0 to 1
  isMobileDrawerOpen: boolean;
}

let state: LandingState = {
  activeSectionId: 'hero',
  journeyStageIndex: 0,
  journeyProgress: 0,
  isMobileDrawerOpen: false,
};

const listeners = new Set<() => void>();

function notify() {
  for (const listener of listeners) {
    listener();
  }
}

export const landingStore = {
  getState(): LandingState {
    return state;
  },

  setActiveSection(sectionId: string) {
    if (state.activeSectionId === sectionId) return;
    state = { ...state, activeSectionId: sectionId };
    notify();
  },

  setJourneyProgress(stageIndex: number, progress: number) {
    const clampedIndex = Math.max(0, Math.min(4, stageIndex));
    const clampedProgress = Math.max(0, Math.min(1, progress));
    if (state.journeyStageIndex === clampedIndex && Math.abs(state.journeyProgress - clampedProgress) < 0.005) {
      return;
    }
    state = {
      ...state,
      journeyStageIndex: clampedIndex,
      journeyProgress: clampedProgress,
    };
    notify();
  },

  setMobileDrawerOpen(open: boolean) {
    if (state.isMobileDrawerOpen === open) return;
    state = { ...state, isMobileDrawerOpen: open };
    notify();
  },

  subscribe(listener: () => void): () => void {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },
};

/**
 * Hook to consume the whole landing state
 */
export function useLandingStore(): LandingState {
  return useSyncExternalStore(landingStore.subscribe, landingStore.getState, landingStore.getState);
}

/**
 * Hook to read only activeSectionId
 */
export function useActiveSection(): string {
  const s = useLandingStore();
  return s.activeSectionId;
}

/**
 * Hook to read journey progress
 */
export function useJourneyProgress(): { stageIndex: number; progress: number } {
  const s = useLandingStore();
  return { stageIndex: s.journeyStageIndex, progress: s.journeyProgress };
}

