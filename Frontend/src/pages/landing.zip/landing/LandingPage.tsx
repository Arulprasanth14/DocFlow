import React, { useEffect } from 'react';
import { useLenis } from './hooks/useLenis';
import { useLayoutState } from './hooks/useLayoutMode';
import { useSectionTracker } from './hooks/useSectionTracker';
import { ScrollProgress } from './components/ScrollProgress';
import { LifecycleTracker } from './components/LifecycleTracker';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { MarqueeStrip } from './components/MarqueeStrip';
import { Problem } from './components/Problem';
import { Journey } from './components/Journey';
import { DocumentTypes } from './components/DocumentTypes';
import { Roles } from './components/Roles';
import { Approvals } from './components/Approvals';
import { Signatures } from './components/Signatures';
import { AiAssistant } from './components/AiAssistant';
import { Analytics } from './components/Analytics';
import { Tenants } from './components/Tenants';
import { Comparison } from './components/Comparison';
import { Trust } from './components/Trust';
import { Faq } from './components/Faq';
import { FinalCta } from './components/FinalCta';
import { Footer } from './components/Footer';
import { CustomCursor } from './components/CustomCursor';
import './landing.css';

/**
 * DocFlow Public Marketing Landing Page
 * Scrollytelling journey following Docky down the lifecycle stages.
 */
export const LandingPage: React.FC = () => {
  // Set descriptive landing page document title
  useEffect(() => {
    document.title = 'DocFlow — The Journey of a Document | Multi-Tenant Approval Platform';
  }, []);

  // Initialize Lenis smooth scroll with GSAP ticker
  useLenis();

  // Single source of truth for the responsive layout tier (width AND height).
  // Every pinned scene and FitStage reads this same decision.
  const { mode } = useLayoutState();

  // Track active visible section and synchronize with landing store
  useSectionTracker();

  return (
    <div
      id="top"
      data-layout={mode}
      className="landing-scope flex flex-col font-sans"
    >
      {/* Desktop Fine Pointer Custom Cursor */}
      <CustomCursor />

      {/* Scroll Progress Bar */}
      <ScrollProgress />

      {/* Floating Lifecycle Tracker on Desktop */}
      <LifecycleTracker />

      {/* Sticky Translucent Navbar */}
      <Navbar />

      <main className="flex-1">
        {/* Section 1: Hero */}
        <Hero />

        {/* Marquee Strip of Standard Document Workflows */}
        <MarqueeStrip />

        {/* Section 2: Problem ("Sound familiar?") */}
        <Problem />

        {/* Section 3: The Document Journey */}
        <Journey />

        {/* Section 4: Document Types & Template Studio Teaser */}
        <DocumentTypes />

        {/* Section 5: Roles & Peer-to-Peer Routing */}
        <Roles />

        {/* Section 6: Approvals Queue & Interactive Decision Demo */}
        <Approvals />

        {/* Section 7: Cryptographic Digital Signatures & Audit Trail */}
        <Signatures />

        {/* Section 8: Tenant-Grounded Docky AI Assistant */}
        <AiAssistant />

        {/* Section 9: Operational Analytics & Bottleneck Detection */}
        <Analytics />

        {/* Section 10: Multi-Tenant Organization Isolation */}
        <Tenants />

        {/* Section 11: Why DocFlow (Comparison Matrix) */}
        <Comparison />

        {/* Section 12: Architectural Trust & Foundation */}
        <Trust />

        {/* Section 13: Frequently Asked Questions (Accordion) */}
        <Faq />

        {/* Section 14: Final Call to Action */}
        <FinalCta />
      </main>

      {/* Section 15: Global Footer */}
      <Footer />
    </div>
  );
};

export default LandingPage;
