/**
 * DocFlow Landing Page Content
 * Source of truth for all copy, features, statuses, roles, FAQs, navigation, and CTA links.
 * STRICT RULE: No hardcoded copy in landing components.
 *
 * WRITING STYLE (keep this when you edit):
 * - Short, friendly sentences. Talk to the reader ("you", "your team").
 * - Plain words first. Avoid jargon like "tenant", "ACID", "row-level", "cryptographic".
 * - Only claim what is true today. Planned features must say "coming soon" or "planned".
 * - Lines marked "CONFIRM" describe behaviour that must be checked against the real product.
 */

export type FeatureStatus = 'Live' | 'In progress' | 'Coming soon';

export interface FeatureItem {
  id: string;
  name: string;
  description: string;
  status: FeatureStatus;
  category: 'core' | 'workflow' | 'intelligence' | 'governance';
}

export interface RoleDetail {
  id: string;
  title: string;
  badge: string;
  can: string[];
  cannot: string[];
  costume: 'employee' | 'manager' | 'deptAdmin' | 'hr' | 'admin' | 'intern';
  tagline: string;
}

export interface ScenarioStory {
  id: string;
  code: string;
  title: string;
  description: string;
  characters: string;
  outcome: string;
}

export interface FaqItem {
  question: string;
  answer: string;
}

export interface ComparisonRow {
  capability: string;
  typicalTools: string;
  docFlow: string;
  isHighlight?: boolean;
}

export const LANDING_CONTENT = {
  meta: {
    title: 'DocFlow | Send, approve and track documents in one place',
    description:
      'Paperwork, minus the paper chase. Send documents to the right people, get them approved, and track every step in one simple place. Digital signatures, a full history and a helpful AI assistant are on the way.',
  },

  brand: {
    name: 'DocFlow',
    tagline: 'Paperwork, minus the paper chase.',
    subhead:
      'Leave requests, purchase orders, claims, contracts, HR letters. DocFlow takes each one from draft to done. It reaches the right people, gets approved, and stays tracked in one place.',
    valuePillars: [
      'The right person approves',
      'Documents go person to person',
      'Digital signatures (coming soon)',
      'A full history of every step (coming soon)',
      'An AI that knows your policies (coming soon)',
    ],
    creatorCredit: 'Built by Arul Prasanth K',
    copyright: `© ${new Date().getFullYear()} DocFlow. All rights reserved.`,
  },

  links: {
    nav: [
      { label: 'How it works', href: '#journey' },
      { label: 'Features', href: '#features' },
      { label: 'Roles', href: '#roles' },
      { label: 'AI Assistant', href: '#ai' },
      { label: 'Security', href: '#security' },
      { label: 'FAQ', href: '#faq' },
    ],
    cta: {
      getStarted: '/register',
      login: '/login',
      // CONFIRM: replace with your real demo or contact email.
      bookDemo: 'mailto:demo@docflow.app?subject=DocFlow%20Demo%20Request',
    },
  },

  problem: {
    eyebrow: 'SOUND FAMILIAR?',
    heading: 'Paperwork gets messy fast.',
    subheading: 'It is rarely the document that is the problem. It is the handoff.',
    quotes: [
      { text: 'Who has the latest version?', sender: 'Finance team' },
      { text: 'Still waiting since last week…', sender: 'Project lead' },
      { text: 'Where is the signed copy?', sender: 'Legal team' },
      { text: 'Can you send that attachment again?', sender: 'Operations' },
    ],
    painPoints: [
      'Documents get lost in emails and chats. Nobody knows who has them.',
      'Everyone has a different version saved on their own computer.',
      'Approvals sit unseen while people keep chasing their managers.',
      'There is no clear proof of who approved what, and when.',
      'Signed copies end up scattered, and are hard to find later.',
      'Simple requests have to climb a long ladder of bosses.',
      'Teams rebuild the same forms again and again.',
    ],
    resolution: 'One flow. Every step visible. No more guessing.',
  },

  journey: {
    eyebrow: 'HOW IT WORKS',
    heading: 'Follow a document from first draft to final archive.',
    subheading: 'See where it goes, who checks it, and what happens at every step.',
    stages: [
      {
        id: 'draft',
        name: 'Draft',
        badge: 'Step 1',
        summary: 'Start from a template, or let AI help you write the first draft.',
        details:
          'Pick a ready-made template and fill in the blanks. Your work is saved as you go.',
      },
      {
        id: 'submitted',
        name: 'Submitted',
        badge: 'Step 2',
        summary: 'Send it off. DocFlow finds the right people.',
        details:
          'Your document goes to the right approvers, and shows up in their queue straight away.',
      },
      {
        id: 'pending',
        name: 'Pending',
        badge: 'Step 3',
        summary: 'Reviewers check it, chat about it, and ask for changes if needed.',
        details:
          'Each reviewer can see who approved before them. If changes are needed, the document comes back to you with notes, and your earlier versions are kept.',
      },
      {
        id: 'decision',
        name: 'Decision',
        badge: 'Step 4',
        summary: 'Approved, rejected, or sent back for changes.',
        details: 'Every decision is saved with who made it and when.',
      },
      {
        id: 'archived',
        name: 'Archived',
        badge: 'Step 5',
        summary: 'Finished documents are stored safely and are easy to find.',
        details:
          'Look back at any past document and see its full history whenever you need it.',
      },
    ],
    scenarioSpotlight: {
      badge: 'A real example',
      title: 'A leave request, start to finish',
      flow: 'Priya (Employee) → Karthik (Manager) → HR',
      story:
        'Priya picks the Leave Request template, fills in her dates, and sends it. Her manager Karthik sees it in his queue, adds a comment, and approves. HR is next in line and can see Karthik’s approval and comment.',
    },
  },

  documentTypes: {
    eyebrow: 'ALL YOUR DOCUMENTS',
    heading: 'Every kind of document. One place.',
    subheading:
      'Stop juggling emails, chats and folders. Keep all your paperwork in one home.',
    items: [
      {
        title: 'Leave Requests',
        category: 'HR & People',
        description: 'Ask for time off and follow the answer.',
        icon: 'CalendarDays',
      },
      {
        title: 'Purchase Orders',
        category: 'Buying',
        description: 'Ask to buy something and get it approved.',
        icon: 'ReceiptText',
      },
      {
        title: 'Reimbursement Claims',
        category: 'Finance',
        description: 'Claim back what you spent, with a clear approval trail.',
        icon: 'CreditCard',
      },
      {
        title: 'Contracts & NDAs',
        category: 'Legal',
        description: 'Send agreements to the right people for review and sign-off.',
        icon: 'FileSignature',
      },
      {
        title: 'Vendor Invoices',
        category: 'Accounts',
        description: 'Check supplier bills and send them for approval.',
        icon: 'Receipt',
      },
      {
        title: 'HR & Promotion Letters',
        category: 'HR',
        description: 'Share sensitive letters only with the people who should see them.',
        icon: 'MailCheck',
      },
    ],
    moreTypesNote:
      'Also great for architecture reviews, signature collection, budget changes and everyday team approvals.',
    templateStudio: {
      status: 'In progress' as FeatureStatus,
      badge: 'Template Studio',
      title: 'Make a document in minutes with ready-made templates.',
      description:
        'Build a template once, with fixed text and fill-in blanks. Everyone else only fills in what matters. AI can help write the first draft.',
    },
  },

  roles: {
    eyebrow: 'WHO CAN DO WHAT',
    heading: 'The right person. The right access.',
    subheading:
      'Everyone in your organization gets only the access their role needs.',
    // CONFIRM: the "cannot" lists below are kept short and follow from each role's limits.
    items: [
      {
        id: 'employee',
        title: 'Employee / Member',
        badge: 'Everyone',
        tagline: 'Sends documents and acts on the ones sent to them, all in one screen.',
        can: [
          'Create and send documents from templates',
          'Track where your document is right now',
          'Act on documents sent to you',
          'Ask the AI assistant about company policy (coming soon)',
        ],
        cannot: ['Create company-wide templates', 'Change anyone’s role'],
        costume: 'employee',
      },
      {
        id: 'manager',
        title: 'Manager / Approver',
        badge: 'Reviewer',
        tagline: 'Reviews documents and makes the call.',
        can: [
          'Approve, reject, or send documents back',
          'Take back an approval before the document is closed',
          'See who approved before you',
          'Sign documents (coming soon)',
        ],
        cannot: ['Add or remove team members', 'Change organization settings'],
        costume: 'manager',
      },
      {
        id: 'deptAdmin',
        title: 'Department Admin',
        badge: 'Team lead',
        tagline: 'Looks after their own department.',
        can: [
          'Manage the people in your department',
          'Create and manage your department’s templates',
          'Send and track documents like any member',
        ],
        cannot: ['See other departments’ settings', 'Change organization settings'],
        costume: 'deptAdmin',
      },
      {
        id: 'hr',
        title: 'HR',
        badge: 'People team',
        tagline: 'Sets up departments, people and roles.',
        can: [
          'Set up departments',
          'Add workers and trainees',
          'Manage roles and permissions',
          'Add new templates',
        ],
        cannot: ['Add other HR people', 'Delete users'],
        costume: 'hr',
      },
      {
        id: 'admin',
        title: 'Main Admin / Super Admin',
        badge: 'Full control',
        tagline: 'Looks after the whole organization.',
        can: [
          'Everything HR can do',
          'Add HR people',
          'Delete users',
          'Upload company documents for the AI assistant',
          'Manage organization settings',
        ],
        cannot: ['See any other organization’s data'],
        costume: 'admin',
      },
      {
        id: 'intern',
        title: 'Intern / Trainee',
        badge: 'Limited access',
        tagline: 'Can send documents, with a safe set of limits.',
        can: ['Create and send documents', 'Track your own documents'],
        cannot: ['Open the Approvals queue', 'Approve or sign anything'],
        costume: 'intern',
      },
    ],
    routingConcept: {
      eyebrow: 'Person to person, not up a ladder',
      title: 'Documents go to the right person, not up a ladder.',
      description:
        'Many tools push every request up a fixed chain of bosses. DocFlow sends it to the person who can actually approve it, based on roles and workflow steps.',
    },
  },

  approvals: {
    eyebrow: 'APPROVALS',
    heading: 'Approvals that do not get stuck.',
    subheading:
      'One place to see what is waiting, what needs changes, and what is done.',
    features: [
      {
        title: 'See who approved before you',
        desc: 'Every reviewer can see who approved earlier and what they said.',
      },
      {
        title: 'Changed your mind? Take it back.',
        desc: 'If you spot a mistake after approving, you can revoke your approval. The document stays open until you approve it again.',
      },
      {
        title: 'Send it back with notes',
        desc: 'Ask for changes with clear feedback. A new version is made, and the old ones are kept.',
      },
      {
        title: 'Know when something needs you',
        desc: 'A badge shows what is waiting for you. Email, SMS and push alerts are coming soon.',
      },
    ],
    interactiveDemoPrompt: 'Try the buttons below to see how a decision works:',
  },

  signatures: {
    eyebrow: 'SIGNED AND TRACKED',
    heading: 'Sign off with confidence.',
    subheading:
      'Digital signatures and a full history of every step are on the way. They will go well beyond a pasted picture of a signature.',
    status: 'Coming soon' as FeatureStatus,
    highlights: [
      {
        title: 'Digital signatures',
        desc: 'Planned: a signature that is tied to who signed, which version they signed, and when.',
      },
      {
        title: 'Spot changes after approval',
        desc: 'Planned: DocFlow will flag a document that was changed after it was approved.',
      },
      {
        title: 'Chats saved with the document',
        desc: 'Comments and decisions are stored safely, so you can look back at what was said.',
      },
      {
        title: 'See the full chain',
        desc: 'See who reviewed and approved each step before the document was closed.',
      },
    ],
  },

  aiAssistant: {
    eyebrow: 'MEET DOCKY',
    heading: 'Meet Docky, the assistant that knows your company’s policies.',
    subheading:
      'Ask a question and Docky answers from your own company documents.',
    status: 'Coming soon' as FeatureStatus,
    keyTruth: 'Answers only from your company’s own documents and policies.',
    diagramNotes: [
      'Your company documents',
      'Your private knowledge base',
      'Docky answers you',
      'Only your organization',
    ],
    samplePrompts: [
      'How many leave days do I have this quarter?',
      'Summarize the key points of this contract.',
      'Help me write a travel reimbursement request.',
    ],
    safetyNote:
      'The AI is an extra helper. If it is ever unavailable, routing and approvals keep working as usual.',
  },

  analytics: {
    eyebrow: 'INSIGHTS',
    heading: 'See where things slow down.',
    subheading: 'Spot slow steps early and keep approvals moving.',
    status: 'Coming soon' as FeatureStatus,
    metrics: [
      { label: 'Documents handled', value: '1,420+', sample: 'sample data' },
      { label: 'Average time to approve', value: '3.4 hrs', sample: 'sample data' },
      { label: 'Documents in progress', value: '86', sample: 'sample data' },
      { label: 'Waiting for review', value: '12', sample: 'sample data' },
    ],
  },

  tenants: {
    eyebrow: 'PRIVATE BY DESIGN',
    heading: 'Every company gets its own private space.',
    subheading:
      'Your people and documents are kept separate from every other company.',
    tenantsMock: ['Acme Corporation', 'Nexus Logistics', 'Starlight Technologies'],
    callouts: [
      'Each company’s data is kept apart',
      'Files are kept in S3-compatible storage',
      'Each company has its own people and roles',
      'Each company has its own templates',
    ],
  },

  comparison: {
    eyebrow: 'WHY DOCFLOW',
    heading: 'Simple to use. Built for serious work.',
    subheading: 'How DocFlow compares with typical workflow tools.',
    rows: [
      {
        capability: 'Where documents go',
        typicalTools: 'Up a fixed ladder of bosses',
        docFlow: 'Straight to the right person',
        isHighlight: true,
      },
      {
        capability: 'Templates',
        typicalTools: 'Basic forms or custom code',
        docFlow: 'Reusable templates with AI help',
      },
      {
        capability: 'Signatures',
        typicalTools: 'Pasted signature pictures or paid add-ons',
        docFlow: 'Built-in digital signatures (coming soon)',
        isHighlight: true,
      },
      {
        capability: 'History',
        typicalTools: 'A “last edited” date in a spreadsheet',
        docFlow: 'A step-by-step history, with chats saved as records',
      },
      {
        capability: 'AI help',
        typicalTools: 'A generic public AI, or none at all',
        docFlow: 'An AI that answers only from your company’s documents',
        isHighlight: true,
      },
      {
        capability: 'Ease of use',
        typicalTools: 'Separate screens for requesters and approvers',
        docFlow: 'One simple screen for everyone',
      },
    ],
  },

  trust: {
    eyebrow: 'SECURITY',
    heading: 'Built on solid, honest foundations.',
    subheading:
      'No big certification claims. Just clear facts about how DocFlow is built.',
    pillars: [
      {
        title: 'Secure sign-in',
        desc: 'Sign-in is handled by Firebase Authentication.',
      },
      {
        title: 'Separate company data',
        desc: 'PostgreSQL keeps each company’s data apart, right at the database level.',
      },
      {
        title: 'Safe file storage',
        desc: 'Documents and files are kept in S3-compatible storage.',
      },
      {
        title: 'Dependable records',
        desc: 'Approvals, revisions and chats are saved in a database built for reliable records (ACID).',
      },
      {
        title: 'AI that stays optional',
        desc: 'If the AI is ever offline, your documents and approvals keep working.',
      },
      {
        title: 'Access by role',
        desc: 'Each person sees and does only what their role allows.',
      },
    ],
  },

  faq: {
    eyebrow: 'QUESTIONS',
    heading: 'Frequently asked questions',
    subheading: 'Quick answers about how DocFlow works.',
    items: [
      {
        question: 'What kinds of documents can I use DocFlow for?',
        answer:
          'Almost anything that needs writing, review or approval: leave requests, purchase orders, claims, contracts, invoices, HR letters, architecture reviews and everyday approvals.',
      },
      {
        question: 'Who can approve a document?',
        answer:
          'Managers and other approvers can approve, reject or send documents back. Interns and trainees can send documents, but they cannot approve them.',
      },
      {
        question: 'Can I take back an approval?',
        answer:
          'Yes. If you spot a mistake after approving, you can take your approval back before the document is closed. The document stays open until you approve it again.',
      },
      {
        question: 'What happens when a document is sent back?',
        answer:
          'The person who sent it gets your notes and can make changes. A new version is created, and the old versions are kept, so nothing is lost.',
      },
      {
        question: 'Is my company data private when I use the AI assistant?',
        answer:
          'Docky is designed to answer only from the documents and policies your own organization uploads. Other organizations never see your documents. The AI assistant is coming soon.',
      },
      {
        question: 'What roles are there?',
        answer:
          'Employee or Member, Manager or Approver, Department Admin, HR, Main Admin or Super Admin, and Intern or Trainee. Each role has its own limits.',
      },
      {
        question: 'Can interns or trainees approve documents?',
        answer:
          'No. Interns and trainees can create and send documents, but they cannot open the Approvals queue or sign anything.',
      },
      {
        question: 'How do I get started?',
        // CONFIRM: check this matches the real sign-up and onboarding flow.
        answer:
          'Click Get started. Then set up your departments, add your team, give people their roles, and pick a template to send your first document.',
      },
    ],
  },

  finalCta: {
    heading: 'Ready to end the paper chase?',
    subheading: 'Send, approve and track every document in one simple place.',
    primaryButton: 'Get started',
    secondaryButton: 'Book a demo',
    footnote: 'One simple portal · A private space for every company',
  },

  footer: {
    blurb:
      'DocFlow helps your team move paperwork from draft to done, with clear steps, the right people, and a record of what happened.',
    sections: [
      {
        title: 'Product',
        links: [
          { label: 'How it works', href: '#journey' },
          { label: 'Document templates', href: '#features' },
          { label: 'Approvals', href: '#approvals' },
          { label: 'Digital signatures', href: '#signatures' },
          { label: 'AI assistant', href: '#ai' },
        ],
      },
      {
        title: 'Control',
        links: [
          { label: 'Roles and access', href: '#roles' },
          { label: 'Step-by-step history', href: '#security' },
          { label: 'Separate company spaces', href: '#tenants' },
          { label: 'Security', href: '#security' },
        ],
      },
      {
        title: 'Resources',
        links: [
          { label: 'FAQ', href: '#faq' },
          { label: 'How it is built', href: '#trust' },
          { label: 'What is live and what is coming', href: '#features' },
          { label: 'Contact us', href: 'mailto:demo@docflow.app' },
        ],
      },
      {
        title: 'Company',
        links: [
          { label: 'About DocFlow', href: '#top' },
          { label: 'Built By Arul Prasanth K', href: '#top' },
          { label: 'Privacy Policy', href: '#' },
          { label: 'Terms of Service', href: '#' },
        ],
      },
    ],
  },

  featuresWithStatus: [
    {
      id: 'f-auth',
      name: 'Secure sign-in and roles',
      description: 'Sign in safely, and give each person the right access.',
      status: 'Live',
      category: 'core',
    },
    {
      id: 'f-dash',
      name: 'Dashboard and one simple portal',
      description: 'One screen to send documents and act on the ones sent to you.',
      status: 'Live',
      category: 'core',
    },
    {
      id: 'f-repo',
      name: 'Documents and templates',
      description: 'Browse, upload, or start from a template. Your work is saved as you go.',
      status: 'In progress',
      category: 'workflow',
    },
    {
      id: 'f-studio',
      name: 'Template Studio',
      description: 'Build reusable templates with fixed text and fill-in blanks.',
      status: 'In progress',
      category: 'workflow',
    },
    {
      id: 'f-workflow',
      name: 'Smart routing',
      description: 'Documents go person to person, based on roles and workflow steps.',
      status: 'In progress',
      category: 'workflow',
    },
    {
      id: 'f-approvals',
      name: 'Approvals queue',
      description: 'See what is pending, approved or rejected, with a count badge.',
      status: 'In progress',
      category: 'workflow',
    },
    {
      id: 'f-chat',
      name: 'Comments and chat',
      description: 'Talk about a document right where it lives, and tag teammates with @.',
      status: 'In progress',
      category: 'governance',
    },
    {
      id: 'f-revoke',
      name: 'Take back an approval',
      description: 'Revoke an approval, and see who approved before you.',
      status: 'In progress',
      category: 'governance',
    },
    {
      id: 'f-ai-draft',
      name: 'AI drafting',
      description: 'Let AI write a first draft from a template.',
      status: 'In progress',
      category: 'intelligence',
    },
    {
      id: 'f-ai-agent',
      name: 'AI assistant',
      description: 'Ask questions and get answers from your own company documents.',
      status: 'Coming soon',
      category: 'intelligence',
    },
    {
      id: 'f-signatures',
      name: 'Digital signatures',
      description: 'Sign documents digitally, tied to who signed and which version.',
      status: 'Coming soon',
      category: 'governance',
    },
    {
      id: 'f-notif',
      name: 'Notifications',
      description: 'Get alerts by email, in the app, by SMS and by push.',
      status: 'Coming soon',
      category: 'core',
    },
    {
      id: 'f-audit',
      name: 'Step-by-step history',
      description: 'A full record of every action taken on a document.',
      status: 'Coming soon',
      category: 'governance',
    },
    {
      id: 'f-analytics',
      name: 'Search and insights',
      description: 'Find any document fast, and see how quickly approvals move.',
      status: 'Coming soon',
      category: 'governance',
    },
  ] as FeatureItem[],
} as const;