import { useEffect, useRef } from 'react';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { prefersReducedMotion } from '@/lib/motion';
import { useLandingStore } from '../store';

gsap.registerPlugin(ScrollTrigger);

export function useLenis() {
  const lenisRef = useRef<Lenis | null>(null);
  const { isMobileDrawerOpen } = useLandingStore();

  useEffect(() => {
    // Anchor offset must equal the CSS scroll-margin-top in landing.css
    // (--lp-nav-h + 16px), so smooth and native jumps land identically.
    const anchorOffset = () => {
      const navH = Number.parseFloat(
        getComputedStyle(document.documentElement).getPropertyValue('--lp-nav-h')
      );
      return -((Number.isFinite(navH) ? navH : 72) + 16);
    };

    if (prefersReducedMotion()) {
      // No Lenis under reduced motion; the browser handles the jump using the
      // same scroll-margin-top, so nothing further is needed here.
      return;
    }

    const lenis = new Lenis({
      duration: 1.15,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 0.95,
      touchMultiplier: 1.4,
    });

    lenisRef.current = lenis;

    // Connect Lenis to GSAP ScrollTrigger
    lenis.on('scroll', ScrollTrigger.update);

    const tickerCb = (time: number) => {
      lenis.raf(time * 1000);
    };

    gsap.ticker.add(tickerCb);
    gsap.ticker.lagSmoothing(0);

    // Intercept internal hash links to apply accurate navbar offset
    const handleAnchorClick = (e: MouseEvent) => {
      const target = (e.target as HTMLElement).closest('a');
      if (!target) return;
      const href = target.getAttribute('href');
      if (href && href.startsWith('#') && href.length > 1) {
        const el = document.querySelector(href);
        if (el) {
          e.preventDefault();
          lenis.scrollTo(el as HTMLElement, {
            offset: anchorOffset(),
            duration: 1.2,
          });
        }
      }
    };

    document.addEventListener('click', handleAnchorClick);

    return () => {
      document.removeEventListener('click', handleAnchorClick);
      gsap.ticker.remove(tickerCb);
      lenis.destroy();
      lenisRef.current = null;
    };
  }, []);

  // Pause Lenis when mobile drawer is open
  useEffect(() => {
    if (!lenisRef.current) return;
    if (isMobileDrawerOpen) {
      lenisRef.current.stop();
    } else {
      lenisRef.current.start();
    }
  }, [isMobileDrawerOpen]);

  return lenisRef;
}

export default useLenis;
