import { useCallback, useEffect, useRef, useState } from 'react';
import {
  placeInRectDetailed,
  type PlaceInRectOptions,
  type PlaceInRectResult,
  type PlacedItemInput,
  type Rect,
} from '../lib/placeInRect';

export interface UsePlaceInRectOptions extends Omit<PlaceInRectOptions, 'avoid'> {
  /** Avoid zones as fractions of the container (0-1), so they scale with it. */
  avoidRatio?: { x: number; y: number; width: number; height: number }[];
  avoid?: Rect[];
}

/**
 * Runtime placement driven by the real container size.
 *
 * Returns a ref to attach to the container and the current placements.
 * Placement is recalculated by a ResizeObserver whenever that container
 * changes size, so scattered items never overlap or escape the box at any
 * viewport — which a one-off useMemo against a hardcoded rect cannot do.
 */
export function usePlaceInRect(items: PlacedItemInput[], options: UsePlaceInRectOptions = {}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [result, setResult] = useState<PlaceInRectResult>({
    items: {},
    ok: true,
    strategy: 'scatter',
  });

  const { padding, gap, maxIterations, seed, avoid, avoidRatio } = options;

  // Keep a stable identity for the inputs so the observer effect does not
  // re-subscribe on every parent render.
  const itemsKey = items.map((i) => `${i.id}:${i.width}x${i.height}:${i.preferredQuadrant ?? ''}`).join('|');
  const avoidKey = JSON.stringify(avoidRatio ?? avoid ?? []);
  const itemsRef = useRef(items);
  itemsRef.current = items;

  const recalculate = useCallback(() => {
    const el = containerRef.current;
    if (!el) return;

    const width = el.clientWidth;
    const height = el.clientHeight;
    if (width < 1 || height < 1) return;

    // Prefer each item's REAL rendered box over its declared size. Text rewraps,
    // fonts load and the stage type floor can grow a card past its constant, and
    // placing against a stale size is what produces overlap.
    const measured = itemsRef.current.map((item) => {
      const node = el.querySelector<HTMLElement>(`[data-place-id="${item.id}"]`);
      if (!node) return item;
      const w = node.offsetWidth;
      const h = node.offsetHeight;
      return w > 0 && h > 0 ? { ...item, width: w, height: h } : item;
    });

    const zones: Rect[] = [
      ...(avoid ?? []),
      ...(avoidRatio ?? []).map((z) => ({
        x: z.x * width,
        y: z.y * height,
        width: z.width * width,
        height: z.height * height,
      })),
    ];

    setResult(
      placeInRectDetailed(measured, { width, height }, {
        padding,
        gap,
        maxIterations,
        seed,
        avoid: zones,
      })
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [padding, gap, maxIterations, seed, avoidKey, itemsKey]);

  useEffect(() => {
    const el = containerRef.current;
    if (!el || typeof window === 'undefined') return;

    recalculate();

    // Observe the container AND each item: an item growing (rewrapped text, a
    // raised type floor inside a scaled stage) changes the required layout just
    // as much as the container resizing does. Positions are applied with
    // left/top, which cannot change an item's size, so this cannot loop.
    const ro = new ResizeObserver(recalculate);
    ro.observe(el);
    for (const node of el.querySelectorAll('[data-place-id]')) ro.observe(node);

    return () => ro.disconnect();
  }, [recalculate]);

  return { containerRef, ...result };
}

export default usePlaceInRect;
