import { useEffect, type RefObject } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { prefersReducedMotion } from '@/lib/motion';

gsap.registerPlugin(ScrollTrigger);

interface UseRevealOptions {
  y?: number;
  opacity?: number;
  duration?: number;
  delay?: number;
  stagger?: number;
  start?: string;
  trigger?: RefObject<HTMLElement | null>;
}

export function useReveal<T extends HTMLElement>(
  targetRef: RefObject<T | null>,
  options: UseRevealOptions = {}
) {
  const {
    y = 28,
    opacity = 0,
    duration = 0.8,
    delay = 0,
    stagger = 0,
    start = 'top 85%',
    trigger,
  } = options;

  const triggerEl = trigger?.current || targetRef.current;

  useEffect(() => {
    const el = targetRef.current;
    if (!el || prefersReducedMotion()) return;

    const ctx = gsap.context(() => {
      const targets = el.children.length > 0 && stagger > 0 ? Array.from(el.children) : el;

      gsap.from(targets, {
        y,
        opacity,
        duration,
        delay,
        stagger: stagger > 0 ? stagger : undefined,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: triggerEl || el,
          start,
          toggleActions: 'play none none none',
          once: true,
        },
      });
    }, el);

    return () => ctx.revert();
  }, [y, opacity, duration, delay, stagger, start, triggerEl, targetRef]);
}
