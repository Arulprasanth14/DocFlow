import { useState, useEffect } from 'react';
import { prefersReducedMotion } from '@/lib/motion';

export type PerformanceTier = 'high' | 'medium' | 'low' | 'static';

export interface PerformanceConfig {
  tier: PerformanceTier;
  dpr: number;
  particleCount: number;
  isSupported: boolean;
  isReducedMotion: boolean;
}

function detectWebGL(): boolean {
  if (typeof window === 'undefined') return false;
  try {
    const canvas = document.createElement('canvas');
    return Boolean(
      window.WebGLRenderingContext &&
        (canvas.getContext('webgl2') || canvas.getContext('webgl') || canvas.getContext('experimental-webgl'))
    );
  } catch {
    return false;
  }
}

function resolveTier(): PerformanceConfig {
  if (typeof window === 'undefined') {
    return {
      tier: 'medium',
      dpr: 1.5,
      particleCount: 1400,
      isSupported: true,
      isReducedMotion: false,
    };
  }

  const isReduced = prefersReducedMotion();
  const hasWebGL = detectWebGL();

  if (isReduced || !hasWebGL) {
    return {
      tier: 'static',
      dpr: 1.0,
      particleCount: 0,
      isSupported: hasWebGL,
      isReducedMotion: isReduced,
    };
  }

  const concurrency = navigator.hardwareConcurrency || 4;
  const isMobile = window.innerWidth < 768 || (navigator.maxTouchPoints > 1 && window.innerWidth < 1024);
  const rawDpr = window.devicePixelRatio || 1;

  if (!isMobile && concurrency >= 8) {
    return {
      tier: 'high',
      dpr: Math.min(rawDpr, 1.75),
      particleCount: 2400,
      isSupported: true,
      isReducedMotion: false,
    };
  }

  if (concurrency >= 4 && !isMobile) {
    return {
      tier: 'medium',
      dpr: Math.min(rawDpr, 1.5),
      particleCount: 1400,
      isSupported: true,
      isReducedMotion: false,
    };
  }

  return {
    tier: 'low',
    dpr: Math.min(rawDpr, 1.25),
    particleCount: 750,
    isSupported: true,
    isReducedMotion: false,
  };
}

export function usePerformanceTier(): PerformanceConfig {
  const [config, setConfig] = useState<PerformanceConfig>(resolveTier);

  useEffect(() => {
    const update = () => setConfig(resolveTier());

    const motionQuery = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    motionQuery?.addEventListener?.('change', update);
    window.addEventListener('resize', update);

    return () => {
      motionQuery?.removeEventListener?.('change', update);
      window.removeEventListener('resize', update);
    };
  }, []);

  return config;
}

