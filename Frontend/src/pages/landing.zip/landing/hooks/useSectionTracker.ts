import { useEffect } from 'react';
import { landingStore } from '../store';

/**
 * useSectionTracker — Observes landing sections and writes the activeSectionId to landingStore.
 * Ensures the Navbar, LifecycleTracker, and Progress markers stay in 100% synchronization.
 */
export function useSectionTracker() {
  useEffect(() => {
    const sections = Array.from(document.querySelectorAll<HTMLElement>('.landing-scope section[id]'));
    if (sections.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        // Find visible section with highest intersection ratio
        const visible = entries.filter((e) => e.isIntersecting);
        if (visible.length > 0) {
          // Sort by intersection ratio or top bounding rect
          visible.sort((a, b) => b.intersectionRatio - a.intersectionRatio);
          const topVisible = visible[0];
          if (topVisible.target.id) {
            landingStore.setActiveSection(topVisible.target.id);
          }
        }
      },
      {
        root: null,
        rootMargin: '-15% 0px -40% 0px', // active when section covers central reading zone
        threshold: [0.1, 0.3, 0.6],
      }
    );

    sections.forEach((sec) => observer.observe(sec));

    return () => observer.disconnect();
  }, []);
}

export default useSectionTracker;

