import { useSyncExternalStore } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export type LayoutMode = 'wide' | 'compact' | 'tablet' | 'mobile';

export interface LayoutState {
  mode: LayoutMode;
  width: number;
  height: number;
  /** Only 'wide' may pin a scrollytelling scene. Single gate for ScrollTrigger
   *  AND FitStage, so the two can never disagree (that disagreement was the
   *  cause of clipped, unreachable content at e.g. 1024x600). */
  canPin: boolean;
}

/**
 * Layout tiers (width AND height):
 * - 'wide'    : w >= 1280 and h >= 700 → full pinned scrollytelling
 * - 'compact' : w >= 1024 and (h < 700 or w < 1280) → same content, unpinned
 * - 'tablet'  : 768 <= w < 1024 → stacked blocks, unpinned
 * - 'mobile'  : w < 768 → single column, swipe carousels, 3D reduced
 */
export function computeLayoutMode(width: number, height: number): LayoutMode {
  if (width < 768) return 'mobile';
  if (width < 1024) return 'tablet';
  if (width < 1280 || height < 700) return 'compact';
  return 'wide';
}

function readViewport(): { width: number; height: number } {
  if (typeof window === 'undefined') return { width: 1440, height: 900 };
  return {
    width: window.innerWidth,
    // visualViewport tracks mobile browser chrome; innerHeight is the fallback.
    height: Math.round(window.visualViewport?.height ?? window.innerHeight),
  };
}

function buildState(): LayoutState {
  const { width, height } = readViewport();
  const mode = computeLayoutMode(width, height);
  return { mode, width, height, canPin: mode === 'wide' };
}

/* ── Singleton store: one measurement, one decision, shared by every consumer ─ */

let state: LayoutState = buildState();
const listeners = new Set<() => void>();

const ROOT_SELECTOR = '.landing-scope';

function writeRootAttribute() {
  if (typeof document === 'undefined') return;
  const root = document.querySelector(ROOT_SELECTOR);
  if (root) root.setAttribute('data-layout', state.mode);
}

function recompute() {
  const next = buildState();
  const modeChanged = next.mode !== state.mode;
  const sizeChanged = next.width !== state.width || next.height !== state.height;
  if (!modeChanged && !sizeChanged) return;

  state = next;
  if (modeChanged) writeRootAttribute();

  for (const listener of listeners) listener();

  // Pin distances and start/end positions depend on viewport height, so they
  // must be recalculated after the DOM has settled into the new mode.
  requestAnimationFrame(() => ScrollTrigger.refresh());
}

let debounceId: number | undefined;
let bound = false;

function onViewportChange() {
  window.clearTimeout(debounceId);
  debounceId = window.setTimeout(recompute, 120);
}

function bindOnce() {
  if (bound || typeof window === 'undefined') return;
  bound = true;
  window.addEventListener('resize', onViewportChange, { passive: true });
  window.addEventListener('orientationchange', onViewportChange, { passive: true });
  window.visualViewport?.addEventListener('resize', onViewportChange, { passive: true });
}

function subscribe(listener: () => void): () => void {
  bindOnce();
  listeners.add(listener);
  // Re-read on first subscribe: the module may have been evaluated before the
  // landing root existed, or the viewport may have changed since.
  recompute();
  writeRootAttribute();
  return () => {
    listeners.delete(listener);
  };
}

function getSnapshot(): LayoutState {
  return state;
}

function getServerSnapshot(): LayoutState {
  return { mode: 'wide', width: 1440, height: 900, canPin: true };
}

export const layoutStore = {
  subscribe,
  getState: getSnapshot,
  /** Imperative read for non-React code (GSAP setup, measurement helpers). */
  measure(): LayoutState {
    recompute();
    return state;
  },
};

/** Full layout state. Mount once near the landing root; safe to call anywhere. */
export function useLayoutState(): LayoutState {
  return useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
}

/** Convenience: just the tier name. */
export function useLayoutMode(): LayoutMode {
  return useLayoutState().mode;
}

/** Convenience: may this viewport pin a scene? */
export function useCanPin(): boolean {
  return useLayoutState().canPin;
}

export default useLayoutMode;
