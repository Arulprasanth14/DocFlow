import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { prefersReducedMotion } from '@/lib/motion';

/**
 * Magnetic pull for a CTA: the element leans toward the pointer, up to `max`
 * pixels, and springs back on leave. Disabled under reduced motion.
 *
 * Returns a ref to attach to the element.
 */
export function useMagnetic<T extends HTMLElement>(max = 12, strength = 0.32) {
  const ref = useRef<T>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el || prefersReducedMotion()) return;

    const xTo = gsap.quickTo(el, 'x', { duration: 0.4, ease: 'power3.out' });
    const yTo = gsap.quickTo(el, 'y', { duration: 0.4, ease: 'power3.out' });
    const clamp = (v: number) => Math.max(-max, Math.min(max, v));

    const onMove = (e: MouseEvent) => {
      const r = el.getBoundingClientRect();
      xTo(clamp((e.clientX - r.left - r.width / 2) * strength));
      yTo(clamp((e.clientY - r.top - r.height / 2) * strength * 1.3));
    };
    const onLeave = () => {
      gsap.to(el, { x: 0, y: 0, duration: 0.5, ease: 'elastic.out(1, 0.5)' });
    };

    el.addEventListener('mousemove', onMove);
    el.addEventListener('mouseleave', onLeave);
    return () => {
      el.removeEventListener('mousemove', onMove);
      el.removeEventListener('mouseleave', onLeave);
      gsap.killTweensOf(el);
    };
  }, [max, strength]);

  return ref;
}

export default useMagnetic;
